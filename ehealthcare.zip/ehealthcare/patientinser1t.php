<?php
$conn=mysql_connect("localhost","root","");
mysql_select_db("ehealthcare",$conn);
//$id=$_POST['id'];
$patient=$_POST['firstname'];
$address=$_POST['address'];
$gender=$_POST['gender'];
$Specialist=$_POST['Specialist'];
$BloodGroup=$_POST['BloodGroup'];
$Phoneno=$_POST['phoneno'];
$age=$_POST['age'];
$email=$_POST['email'];
$password=$_POST['password'];
$insert="INSERT INTO patient(patient,address,gender,BloodGroup,Specialist,phoneno,age,email,password) VALUES ('$patient','$address','$gender','$BloodGroup','$Specialist','$Phoneno','$age','$email','$password')";
$query=mysql_query($insert,$conn);
if($query)
{
	 echo "<script>alert('success')</script>";
	 }
header("location:userpatient.php");
?>