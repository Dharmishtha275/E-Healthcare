<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
  <head>
    <!-- Basic meta tags -->
   
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- CSS Styles -->
    <link rel="stylesheet" type="text/css" href="css/prettyPhoto.css"/>
    <link href="css/style.css" rel="stylesheet">
      
    <!-- Google Web font 'PT Sans and Yanone Kaffeesatz' -->  
    <link href='http://fonts.googleapis.com/css?family=PT+Sans+Narrow|Yanone+Kaffeesatz:400,300,700' rel='stylesheet' type='text/css'>
     
    <!-- Jquery Library -->
    <script src="js/jquery-1.7.1.min.js"></script>
    
    <!-- For IE6-8 support of HTML5 elements & Seperate CSS for ie-8-7 -->
    <!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
      <link href="css/ie8-7.css" rel="stylesheet">
    <![endif]-->
    
  </head>

  <body>
    
    <!-- Header -->
    <header>
      <div class="container">
        <div class="row-fluid">
	  <!-- logo -->
          <div class="span6 logo">
            <a href="index.html"><img src="img/plo.jpg" alt=""/></a>
          </div>
	  <!-- End Logo -->
          
          <!-- Social menu -->
	  <div class="span6" id="social">
            <ul class="social">
              <li class="twitter">
		<a target="_blank" href="#">&nbsp;</a>
              </li>
	      <li class="facebook">
		<a target="_blank" href="#">&nbsp;</a>
	      </li>
            </ul>
          </div>
          <!-- End Social Menu -->
        </div> <!--/.row-fluid -->
      </div> <!--/.container -->
    </header>
    <!-- End Header -->
    
    <!-- Section Top -->
    <section id="top">
      <div class="container">
	<!-- Main Menu -->
        <div class="navbar">
          <div class="navbar-inner">
            <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
	   
       
        Main Menu
            </a>
            <div class="nav-collapse">
              <ul class="nav">
                <li><a href="index.php">Home</a></li>
               <!-- 
                 <li class="dropdown">
                  <a href="doctorlogin.php">DoctorAdmin</a></li>
                  
                   -->
                   
                   <li class="dropdown">
                  <a href="userpatient.php">Registration</a></li>
                  
               
                   <li class="dropdown">
                  <a href="medicine.php">medicine</a></li>

                
                <li class="active">
		  <a href="newabout.php">About us</a></li>
           
                <li><a href="contact-us.php">Contact Us</a></li>
              </ul>
            </div> <!--/.nav-collapse -->
          </div> <!--/.navbar-inner -->
        </div> <!--/.navbar -->
        <!-- End Main Menu -->
	
      </div> <!--/.container -->
    </section> <!--/#top --> 
    <!--  End Section Top -->
    
    <!-- Section Breadcrumbs-->
    <section id="breadcrumb">
      <div class="b-c">
	<div class="container">
	  <ul class="breadcrumb">
	    
	 
	  </ul>
	</div> <!--/.container -->
      </div> <!--/.b-c -->
    </section> <!--#breadcrumb -->
    <!-- End Section Breadcrumb -->
    
    <!-- Section content -->
    <section id="content">
      <div class="container">
	<div class="row-fluid">
	  <div class="span12">  
	  
	    <!-- Category Filter -->
	    <ul class="filter group"> 
	      <li class="current all"><a href="#">All</a></li> 
	      <li class="Category-1"><a href="#">Category-1</a></li> 
	      <li class="Category-2"><a href="#">Category-2</a></li> 
	      <li class="Category-3"><a href="#">Category-3</a></li> 
	      <li class="Category-4"><a href="#">Category-4</a></li> 
	      <li class="Category-5"><a href="#">Category-5</a></li> 
	      <li class="Category-6"><a href="#">Category-6</a></li> 
	    </ul>
	    <!-- End Category Filter -->
  
	    <!-- Gallery Items -->
	    <ul class="gallery group 3-col"> 
	      <li class="item span3" data-id="id-1" data-type="Category-1">
		<a href="img/gallery/1.jpg" data-rel="prettyPhoto[portfolio]"><img src="img/gallery/1.jpg" alt="Yulia Gorbachenko, Hannah 1" /></a>
	      </li> 
	      <li class="item span3" data-id="id-2" data-type="Category-3">
		<a href="img/gallery/2.jpg" data-rel="prettyPhoto[portfolio]"><img src="img/gallery/2.jpg" alt="Yulia Gorbachenko, Hair 1" /></a>
	      </li>
	      <li class="item span3" data-id="id-3" data-type="Category-5">
		<a href="img/gallery/3.jpg" data-rel="prettyPhoto[portfolio]"><img src="img/gallery/3.jpg" alt="Yulia Gorbachenko, Hair 2" /></a>
	      </li>
	      <li class="item span3" data-id="id-4" data-type="Category-1">
		<a href="img/gallery/4.jpg" data-rel="prettyPhoto[portfolio]"><img src="img/gallery/4.jpg"  alt="Yulia Gorbachenko, Traction 1" /></a>
	      </li>
	      <li class="item span3" data-id="id-5" data-type="Category-3">
		<a href="img/gallery/5.jpg" data-rel="prettyPhoto[portfolio]"><img src="img/gallery/5.jpg" alt="Yulia Gorbachenko, Traction 1" /></a>
	      </li>
	      <li class="item span3" data-id="id-6" data-type="Category-4">
		<a href="img/gallery/6.jpg" data-rel="prettyPhoto[portfolio]"><img src="img/gallery/6.jpg" alt="Yulia Gorbachenko, Beauty 2" /></a>
	      </li>
	      <li class="item span3" data-id="id-7" data-type="Category-1">
		<a href="img/gallery/7.jpg" data-rel="prettyPhoto[portfolio]"><img src="img/gallery/7.jpg"  alt="Yulia Gorbachenko, Wavelength 1" /></a>
	      </li>
	      <li class="item span3" data-id="id-8" data-type="Category-6">
		<a href="img/gallery/8.jpg" data-rel="prettyPhoto[portfolio]"><img src="img/gallery/8.jpg" alt="Yulia Gorbachenko, On Fire 1" /></a>
	      </li>
	      <li class="item span3" data-id="id-9" data-type="Category-1">
		<a href="img/gallery/9.jpg" data-rel="prettyPhoto[portfolio]"><img src="img/gallery/9.jpg" alt="Yulia Gorbachenko, On Fire 2" /></a>
	      </li>
	      <li class="item span3" data-id="id-10" data-type="Category-3">
		<a href="img/gallery/10.jpg" data-rel="prettyPhoto[portfolio]"><img src="img/gallery/10.jpg" alt="Yulia Gorbachenko, Hair 3" /></a>
	      </li>
	      <li class="item span3" data-id="id-11" data-type="Category-2">
		<a href="img/gallery/11.jpg" data-rel="prettyPhoto[portfolio]"><img src="img/gallery/11.jpg" alt="Yulia Gorbachenko, On Fire 3" /></a>
	      </li>
	      <li class="item span3" data-id="id-12" data-type="Category-6">
		<a href="img/gallery/12.jpg" data-rel="prettyPhoto[portfolio]"><img src="img/gallery/12.jpg" alt="Yulia Gorbachenko, Wavelength 2" /></a>
	      </li>
	    </ul>
	    <!-- End Gallery Items -->
	    
	  </div> <!--/.span12 -->
	</div> <!--/.row-fluid -->
      </div> <!--/.Container  -->
    </section>
    <!-- End Section content -->
    
    <!-- Footer -->
    <footer>
      <div class="container">
        <div class="row-fluid">
          <div class="span3">
            <ul class="nav nav-list">
              <li class="nav-header">Contact Us</li>
              <li><span class="label label-inverse">Telephone</span></li>
              <li><span class="label label-inverse">Fax</span> </li>
              <li><span class="label label-inverse">Mobile</span> </li>
              <li><span class="label label-inverse">Email</span> </li>
              <li><span class="label label-inverse">Location</span> </li>
            </ul>
          </div> <!--/.span3 -->

          <div class="span3">
           <ul class="nav nav-list">
              <li class="nav-header">WEBSITE NAVIGATION</li>
              <li><a href="index.php">Home Page</a></li>
              <li><a href="about1.php">About us</a></li>
              <li><a href="contact-us.php">Contact Us</a></li>
              
            </ul>
          </div> <!--/.span3 -->
        
          
          <div class="span12 copyright">
           
          </div><!--/.span12 -->
        </div><!--/.row-fluid -->
      </div><!--/.container -->
    </footer>
    <!-- End Footer -->
    
    <!-- Javascript Placed at the end of the document so the pages load faster -->
    
    <!-- For Photo Gallery and Image Popups -->	
    <script type="text/javascript" src="js/photo-gallery/jquery.prettyPhoto.js"></script> 
    <script type="text/javascript" src="js/photo-gallery/jquery.quicksand.js"></script> 
    <script type="text/javascript" src="js/photo-gallery/jquery.easing.1.3.js"></script> 
    <script type="text/javascript" src="js/photo-gallery/script.js"></script>
    <script type="text/javascript">
      $(document).ready(function() {
	$("a[data-rel^='prettyPhoto']").prettyPhoto();
      });
    </script>
    
    <!-- Twitter Bootstrap -->
    <script src="js/bootstrap/bootstrap.js"></script>
		
  </body>
</html>


