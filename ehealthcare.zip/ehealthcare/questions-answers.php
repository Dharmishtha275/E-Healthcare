<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
  <head>
    <!-- Basic meta tags -->
   
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Ehealthcare - Bootstrap Responsive Template</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- CSS styles -->
    <link href="css/style.css" rel="stylesheet">
    <link href="css/validationengine.css" rel="stylesheet">

    <!-- Google Web font 'PT Sans and Yanone Kaffeesatz' -->  
    <link href='http://fonts.googleapis.com/css?family=PT+Sans+Narrow|Yanone+Kaffeesatz:400,300,700' rel='stylesheet' type='text/css'>
     
    <!-- Jquery Library -->
    <script src="js/jquery-1.7.1.min.js"></script>
 
    <!-- For IE6-8 support of HTML5 elements & Seperate CSS for ie-8-7 -->
    <!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
      <link href="css/ie8-7.css" rel="stylesheet">
    <![endif]-->
  </head>

  <body>
    <!-- Header -->
    <header>
      <div class="container">
        <div class="row-fluid">
	  <!-- logo -->
          <div class="span6 logo">
            <a href="index.php"><img src="img/plo.jpg" /></a>
          </div>
	  <!-- End Logo -->
          
          <!-- Social menu -->
	  <div class="span6" id="social">
            <ul class="social">
              <li class="twitter">
		<a target="_blank" href="#">&nbsp;</a>
              </li>
	      <li class="facebook">
		<a target="_blank" href="#">&nbsp;</a>
	      </li>
            </ul>
          </div>
          <!-- End Social Menu -->
        </div> <!--/.row-fluid -->
      </div> <!--/.container -->
    </header>
    <!-- End Header -->
    
    <!-- Section Top -->
    <section id="top">
      <div class="container">
	<!-- Main Menu -->
        <div class="navbar">
          <div class="navbar-inner">
            <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">

	      Main Menu
            </a>
            <div class="nav-collapse">
              <ul class="nav">
                <li><a href="userpatient.php">Patient</a></li>
                
                                <li class="dropdown">
                  <a href="medicine.php">medicine</a></li>

                
                 
                  
                                    
                                  <li class="dropdown">
                  <a href="answer.php">Question</a></li>
              </ul>
            </div> <!--/.nav-collapse -->
          </div> <!--/.navbar-inner -->
        </div> <!--/.navbar -->
        <!-- End Main Menu -->
	
      </div> <!--/.container -->
    </section> <!--/#top --> 
    <!--  End Section Top -->
    
    <!-- Section Breadcrumbs-->
    <section id="breadcrumb">
      <div class="b-c">
	<div class="container">
	  <ul class="breadcrumb">
	    <li class="title">You are here</li>
	    <li><a href="#">Home</a> <span class="divider"><img src="img/br-arrow.png" alt="" /></span></li>
	    <li><a href="#">Web Pages</a> <span class="divider"><img src="img/br-arrow.png" alt="" /></span></li>
	    <li><a href="#">Questions and Answers</a></li>
	  </ul>
	</div> <!--/.container -->
      </div> <!--/.b-c -->
    </section> <!--#breadcrumb -->
    <!-- End Section Breadcrumb -->
    
    <!-- Section content -->
    <section id="content">
      <div class="container">
        <div class="row-fluid">
	  <div class="page clearfix">
	    <img src="img/sample.jpg" alt="" />
	    <p>In hac habitasse platea dictumst. In convallis volutpat lobortis. Phasellus porta, ante eget blandit pellentesque, justo dui euismod elit, nec accumsan eros neque non odio. In nisl nibh, suscipit eget venenatis eget, euismod tincidunt sapien. Phasellus vulputate commodo dolor dictum porta. Quisque quis diam leo, ut interdum quam. Mauris nec ipsum ac ipsum adipiscing mattis non a dui. Donec mollis sagittis posuere. Donec risus mi, tincidunt vel tempus quis, facilisis et leo.</p>
	    <h3 class="marg-top-med">In nisl nibh suscipit eget venenatis ege euismod</h3>
	    
	    <div class="span8 no-marg-left">
	      <div class="accordion" id="accordion2">
		<div class="accordion-group">
		  <div class="accordion-heading">
		    <a class="accordion-toggle" data-toggle="collapse" data-parent=".accordion" href="#collapseOne">
		      Sample Question 1
	  	    </a>
		  </div>
		  
		  <div id="collapseOne" class="accordion-body collapse" style="height: 0px; ">
		    <div class="accordion-inner">
		      <p>Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.</p>
		    </div>
		  </div>
		</div> <!--/.accordion-group -->
		
		<div class="accordion-group">
		  <div class="accordion-heading">
		    <a class="accordion-toggle" data-toggle="collapse" data-parent=".accordion" href="#collapseTwo">
		      Sample Question 2
		    </a>
		  </div>
		  <div id="collapseTwo" class="accordion-body collapse" style="height: 0px; ">
		    <div class="accordion-inner">
		      <p>Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.</p>
		    </div>
		  </div>
		</div> <!--/.accordion-group -->
		
		<div class="accordion-group">
		  <div class="accordion-heading">
		    <a class="accordion-toggle" data-toggle="collapse" data-parent=".accordion" href="#collapseThree">
		      Sample Question 3
		    </a>
		  </div>
		  <div id="collapseThree" class="accordion-body collapse">
		    <div class="accordion-inner">
		      <p>Nhil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.</p>
		    </div>
		  </div>
		</div> <!--/.accordion-group -->
		
		<div class="accordion-group">
		  <div class="accordion-heading">
		    <a class="accordion-toggle" data-toggle="collapse" data-parent=".accordion" href="#collapseFour">
		      Sample Question 4
		    </a>
		  </div>
		  <div id="collapseFour" class="accordion-body collapse">
		    <div class="accordion-inner">
		      <p>Nhil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.</p>
		    </div>
		  </div>
		</div> <!--/.accordion-group -->
		
		<div class="accordion-group">
		  <div class="accordion-heading">
		    <a class="accordion-toggle" data-toggle="collapse" data-parent=".accordion" href="#collapseFive">
		      Sample Question 5
		    </a>
		  </div>
		  <div id="collapseFive" class="accordion-body collapse">
		    <div class="accordion-inner">
		      <p>Nhil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.</p>
		    </div>
		  </div>
		</div> <!--/.accordion-group -->
		
		<div class="accordion-group">
		  <div class="accordion-heading">
		    <a class="accordion-toggle" data-toggle="collapse" data-parent=".accordion" href="#collapseSix">
		      Sample Question 6
		    </a>
		  </div>
		  <div id="collapseSix" class="accordion-body collapse">
		    <div class="accordion-inner">
		      <p>Nhil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.</p>
		    </div>
		  </div>
		</div> <!--/.accordion-group -->
		
		<div class="accordion-group">
		  <div class="accordion-heading">
		    <a class="accordion-toggle" data-toggle="collapse" data-parent=".accordion" href="#collapseSeven">
		      Sample Question 7
		    </a>
		  </div>
		  <div id="collapseSeven" class="accordion-body collapse">
		    <div class="accordion-inner">
		      <p>Nhil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.</p>
		    </div>
		  </div>
		</div> <!--/.accordion-group -->
		
		<div class="accordion-group">
		  <div class="accordion-heading">
		    <a class="accordion-toggle" data-toggle="collapse" data-parent=".accordion" href="#collapseEight">
		      Sample Question 8
		    </a>
		  </div>
		  <div id="collapseEight" class="accordion-body collapse">
		    <div class="accordion-inner">
		      <p>Nhil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.</p>
		    </div>
		  </div>
		</div> <!--/.accordion-group -->
		
		<div class="accordion-group">
		  <div class="accordion-heading">
		    <a class="accordion-toggle" data-toggle="collapse" data-parent=".accordion" href="#collapseNine">
		      Sample Question 9
		    </a>
		  </div>
		  <div id="collapseNine" class="accordion-body collapse">
		    <div class="accordion-inner">
		      <p>Nhil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.</p>
		    </div>
		  </div>
		</div> <!--/.accordion-group -->
		
		<div class="accordion-group">
		  <div class="accordion-heading">
		    <a class="accordion-toggle" data-toggle="collapse" data-parent=".accordion" href="#collapseTen">
		      Sample Question 10
		    </a>
		  </div>
		  <div id="collapseTen" class="accordion-body collapse">
		    <div class="accordion-inner">
		      <p>Nhil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.</p>
		    </div>
		  </div>
		</div> <!--/.accordion-group -->
	      </div> <!--/.accordion -->
	    </div> <!--/.span9 -->
	    
	    <div class="span4">
	      <div class="page dark">
		<h3 class="snow">Write to us</h3>
		<p>Have a Question? Simply send us a message. We'll give you the perfect answers.</p>
		<form id="formID" method="post" action="#">
		  <label>Name</label>
		  <input name="name" class="validate[required] text-input span12" type="text" data-prompt-position="topRight:-70">
  
		  <label>Email</label>
		  <input name="email" class="validate[required,custom[email]] text-input span12" type="text" data-prompt-position="topRight:-70">
  
		  <label>Question</label>
		  <textarea class="validate[required] text-input span12"></textarea>
		  <input type="submit" class="btn-green" value="SUBMIT" />
		</form>
	      </div> <!--/.page .dark -->
	    </div> <!--/.span3 -->
	  </div> <!--/.page -->  
        </div> <!--/.row-fluid -->
      </div> <!--/.Container -->
    </section> <!--#content -->
    <!-- End Section content-->
    
    <!-- Footer -->
    <footer>
      <div class="container">
        <div class="row-fluid">
          <div class="span3">
            <ul class="nav nav-list">
              <li class="nav-header">Contact Us</li>
               <li><span class="label label-inverse">Mobile</span></li>
              <li><span class="label label-inverse">Mobile</span></li>
              <li><span class="label label-inverse">Email</span></li>
             <li><span class="label label-inverse">Email</span></li>

              
            </ul>
          </div> <!--/.span3 -->

          <div class="span3">
           <ul class="nav nav-list">
              <li class="nav-header">WEBSITE NAVIGATION</li>
              <li><a href="#">Home Page</a></li>
              <li><a href="#">Doctor</a></li>
              <li><a href="registration.php">Registration</a></li>
              <li><a href="patient.php">Patient</a></li>
              <li><a href="about1.php">About us</a></li>
              <li><a href="contact-us.php">Contact Us</a></li>
            </ul>
          </div> <!--/.span3 -->
        
          
          <div class="span12 copyright">
        
          </div><!--/.span12 -->
        </div><!--/.row-fluid -->
      </div><!--/.container -->
    </footer>
    <!-- End Footer -->
    
    <!-- Javascript Placed at the end of the document so the pages load faster -->
    
    <!-- Twitter Bootstrap-->
    <script src="js/bootstrap/bootstrap.js"></script>
    
    <!-- Form Validation -->
    <script src="js/validate/jquery.validationEngine.js"></script>
    <script>
      jQuery(document).ready(function(){
	// binds form submission and fields to the validation engine
      	jQuery("#formID").validationEngine();
      });
    </script>

  </body>
</html>
