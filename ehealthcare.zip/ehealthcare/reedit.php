<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<!-- Basic meta tags -->


    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Medical Pro - Bootstrap Responsive Template</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- CSS styles -->
    <link href="css/style.css" rel="stylesheet">
      
    <!-- Google Web font 'PT Sans and Yanone Kaffeesatz' -->  
    <link href='http://fonts.googleapis.com/css?family=PT+Sans+Narrow|Yanone+Kaffeesatz:400,300,700' rel='stylesheet' type='text/css'>
     
    <!-- Jquery Library -->
    <!--<script src="js/jquery-1.7.1.min.js"></script>-->
    
    <!-- for IE6-8 support of HTML5 elements & Seperate CSS for ie-8-7 -->
    <!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
      <link href="css/ie8-7.css" rel="stylesheet">
    <![endif]-->

<script type="text/javascript">

function validation()
{ 
	var id=document.frm1.id.value
   var firstname=document.frm1.firstname.value;
   var secondname=document.frm1.secondname.value;
   var lastname=document.frm1.lastname.value;
   var address=document.frm1.address.value;
   var city=document.frm1.city.value;
   var phoneno=document.frm1.phoneno.value;
   var email=document.frm1.email.value;
   var password=document.frm1.password.value;
   var msg='';
   var error='';
   
   if(id == '')
      {
	     error=alert(" Please Enter First name");
         msg+=error;
      }

    
     if(firstname == '')
   {
	     error=alert (" please enter first name");
         msg+=error;
   }
    
     if(secondname == '')
   {
	     error=alert (" please enter second name");
         msg+=error;
   }
   if(lastname == '')
   {
		 error=alert ("please enter Last name");
         msg+=error;
 
   }
    
     if(address == '')
   {
	     error=alert("please enter address");
         msg+=error;
   }
    
     if(city == '')
   {
	     error=alert ("please enter city");
         msg+=error;
   }
   
     if(phoneno == '')
   {
	     error=alert ("please enter phoneno");
         msg+=error;
   }
    
     if(email == '')
   {
	     error=alert ("please enter emailid");
         msg+=error;
   }
    
     if(password == '')
   {
	     error=alert ("please enter password");
         msg+=error;
   }
   if(msg !='')
   {
	    document.getElementById("error_div").innerHTML = msg;
		return false;
   }
}
</script>
</head>
<body>
    <!-- Header -->
    <header>
      <div class="container">
        <div class="row-fluid">
	  <!-- logo -->
          <div class="span6 logo">
            <a href="index.php"><img src="img/plo.jpg" /></a>
          </div>
	  <!-- End Logo -->
          
          <!-- Social menu -->
	  <div class="span6" id="social">
            <ul class="social">
              <li class="twitter">
		<a target="_blank" href="#">&nbsp;</a>
              </li>
	      <li class="facebook">
		<a target="_blank" href="#">&nbsp;</a>
	      </li>
            </ul>
          </div>
          <!-- End Social Menu -->
        </div> <!--/.row-fluid -->
      </div> <!--/.container -->
    </header>
    <!-- End Header -->
    
    <!-- Section Top -->
    <section id="top">
      <div class="container">
	<!-- Main Menu -->
        <div class="navbar">
          <div class="navbar-inner">
            <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
	      Main Menu
            </a>
            <div class="nav-collapse">
              <ul class="nav">
                <li><a href="index.php">Home</a></li>
                
                 <li class="dropdown">
                  <a href="doctorlogin.php">admin</a></li>
                  
                   
                   
                   <li class="dropdown">
                  <a href="registration.php">registration</a></li>
                  
                <li class="dropdown">
                  <a href="login.php">login</a></li>
                  
                <li class="dropdown">
		  <a href="about1.php">about us</a></li>
           
                <li><a href="contact-us.php">Contact Us</a></li>
              </ul>
            </div> <!--/.nav-collapse -->
          </div> <!--/.navbar-inner -->
        </div> <!--/.navbar -->
        <!-- End Main Menu -->
	
      </div> <!--/.container -->
    </section> <!--/#top --> 
    <!--  End Section Top -->
    
    <!-- Section Breadcrumbs-->
    <section id="breadcrumb">
      <div class="b-c">
	<div class="container">
	  <ul class="breadcrumb">
	</div> <!--/.container -->
      </div> <!--/.b-c -->
    </section> <!--#breadcrumb -->
    <!-- End Section Breadcrumb -->


<?php
 
   $conn=mysql_connect("localhost","root","");
   mysql_select_db("ehealthcare",$conn);
   $id=$_GET['id'];
   $select= "SELECT * FROM registration where id=".$id;
   $query= mysql_query($select,$conn);
   while($row=mysql_fetch_assoc($query))
   {
   
?>
<br><br>
<form id="tform" name="frm1" action="regupdate.php?id=<?php echo $row['id']; ?>" method="POST" onsubmit="return validation()">
<div id="error_div"></div>
<table align="center" border="2" bordercolor="#00FFFF">
<h1 align="center"><font face="Times New Roman, Times, serif" color="#FF0000"><i>Update now....</i></font></h1>
<tr>
<td><font size="+1" face="Times New Roman, Times, serif" color="#0000FF"><i>First name:</i></font></td>
<td><input type="text" name="firstname" id="firstname" value="<?php echo $row['firstname']; ?>" /></td>
</tr>
<tr>
<td><font size="+1" face="Times New Roman, Times, serif" color="#0000FF"><i>Secondname:</i></font></td>
<td><input type="text" name="secondname" id="secondname" value="<?php echo $row['secondname']; ?>" /></td>
</tr>
<tr>
<td><font size="+1" face="Times New Roman, Times, serif" color="#0000FF"><i>Lastname:</i></font></td>
<td><input type="text" name="lastname" id="lastname"value="<?php echo $row['lastname']; ?>"></td>
</tr>
<tr>
<td><font size="+1" face="Times New Roman, Times, serif" color="#0000FF"><i>Address:</i></font></td>
<td><textarea name="address" id="address" cols="5" rows="5" value="<?php echo $row['address']; ?>" /></textarea></td>
</tr>
<tr>
<td><font size="+1" face="Times New Roman, Times, serif" color="#0000FF"><i>City:</i></font></td>
<td><select name="city" id="city" value="<?php echo $row['city']; ?>" />
<option>Mumbai</option>
<option>Surat</option>
<option>Pune</option>
<option>Banglor</option>
<option>Ahemdabad</option>
</select>
</td>
</tr>
<tr>
<td><font size="+1" face="Times New Roman, Times, serif" color="#0000FF"><i>Phoneno:</i></font></td>
<td><input type="text" name="phoneno" id="phoneno" value="<?php echo $row['phoneno']; ?>" /></td>
</tr>
<tr>
<td><font size="+1" face="Times New Roman, Times, serif" color="#0000FF"><i>Email:</i></font></td>
<td><input type="text" name="email" id="email" value="<?php echo $row['email']; ?>" /></td>
</tr>
<tr>
<td><font size="+1" face="Times New Roman, Times, serif" color="#0000FF"><i>Password:</i></font></td>
<td><input type="password" name="password" id="password" value="<?php echo $row['password']; ?>" /></td>
</tr>
<tr>
<tr>
<td colspan="2" align="center"><input type="submit" class="btn-green" name="submit" value="edit">
</td>
</tr>
</table>
</form>
<?php
   }
?><br /><br /><br /><br /><br />
             <!-- Footer -->
    <footer>
      <div class="container">
        <div class="row-fluid">
          <div class="span3">
            <ul class="nav nav-list">
              <li class="nav-header">Contact Us</li>
              <li><span class="label label-inverse">Mobile</span></li>
              <li><span class="label label-inverse">Mobile</span></li>
              <li><span class="label label-inverse">Email</span></li>
             <li><span class="label label-inverse">Email</span></li>

              
            </ul>
          </div><!--/.span3 -->

          <div class="span3">
           <ul class="nav nav-list">
              <li class="nav-header">WEBSITE NAVIGATION</li>
              <li><a href="#">Home Page</a></li>
              <li><a href="doctor1.php">Doctor</a></li>
              <li><a href="registration.php">Registration</a></li>
              <li><a href="patient.php">Patient</a></li>
              <li><a href="about1.php">About us</a></li>
              <li><a href="contact-us.php">Contact Us</a></li>
            </ul>
          </div><!--/.span3 -->
        
          
          <div class="span12 copyright">
         
          </div><!--/.span12 -->
        </div><!--/.row-fluid -->
      </div><!--/.container -->
    </footer>
    <!-- End Footer -->
    
    <!-- Javascript Placed at the end of the document so the pages load faster -->
    
    <!-- Twitter Bootstrap -->
    <script src="js/bootstrap/bootstrap.js"></script>
    
    <!-- Form Validation -->
    <script src="js/validate/jquery.validationEngine.js"></script>
    <script>
      jQuery(document).ready(function(){
	// binds form submission and fields to the validation engine
      	jQuery("#formID").validationEngine();
      });
    </script>
    
    <!-- Elastislide -->
    <script type="text/javascript" src="js/jquery.elastislide.js"></script>
    <script type="text/javascript">
		$('#carousel').elastislide({
			  imageW 	: 180,
			  minItems	: 5
		});	
    </script>

  </body>
</html>

          
          
 





	 
    
   


