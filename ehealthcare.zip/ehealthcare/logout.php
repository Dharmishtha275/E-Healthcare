<?php
	session_start();
	session_unset();
	session_destroy();
	?>
	<script type="text/javascript">
	alert ("successfully logout...");
    window.location="doctorlogin.php?logout=success"; 
</script>
<!--	header('location:index.php?logout=success');
?>-->