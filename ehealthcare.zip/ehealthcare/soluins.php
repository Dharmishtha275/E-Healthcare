<?php
$conn=mysql_connect("localhost","root","");
mysql_select_db(" ehealthcare",$conn);
$id=$_GET['id'];
$solution=$_GET['solution'];
$insert="INSERT INTO solution('id','solution') VALUES ('".$id."','".$solution."')";
$query=mysql_query($insert,$conn);
header("Location:solution.php");
?>