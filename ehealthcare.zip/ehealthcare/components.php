<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
  <head>
    <!-- Basic meta tags -->
   
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Ehealthcare - Bootstrap Responsive Template</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- CSS styles -->
    <link href="css/style.css" rel="stylesheet">
      
    <!-- Google Web font 'PT Sans and Yanone Kaffeesatz' -->  
    <link href='http://fonts.googleapis.com/css?family=PT+Sans+Narrow|Yanone+Kaffeesatz:400,300,700' rel='stylesheet' type='text/css'>
     
    <!-- Jquery Library -->
    <script src="js/jquery-1.7.1.min.js"></script>
    
    <!-- for IE6-8 support of HTML5 elements & Seperate CSS for ie-8-7 -->
    <!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
      <link href="css/ie8-7.css" rel="stylesheet">
    <![endif]-->
    
  </head>

  <body>
    
    <!-- Header -->
    <header>
      <div class="container">
        <div class="row-fluid">
	  <!-- logo -->
          <div class="span6 logo">
            <a href="index.php"><img src="img/logo.png" /></a>
          </div>
	  <!-- End Logo -->
          
          <!-- Social menu -->
	  <div class="span6" id="social">
            <ul class="social">
              <li class="twitter">
		<a target="_blank" href="#">&nbsp;</a>
              </li>
	      <li class="facebook">
		<a target="_blank" href="#">&nbsp;</a>
	      </li>
            </ul>
          </div>
          <!-- End Social Menu -->
        </div> <!--/.row-fluid -->
      </div> <!--/.container -->
    </header>
    <!-- End Header -->
    
    <!-- Section Top -->
    <section id="top">
      <div class="container">
	<!-- Main Menu -->
        <div class="navbar">
          <div class="navbar-inner">
            <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
	      Main Menu
            </a>
            <div class="nav-collapse">
              <ul class="nav">
                <li><a href="index.php">Home</a></li>
                  
                  
                   <li class="dropdown">
                  <a href="doctorlogin.php">admin</a></li>
                  
                   
                 <li class="dropdown">
                  <a href="registration.php">registration</a></li>  
                             
                <li class="dropdown active">
                  <a  href="login.php">login</a></li>


                <li class="dropdown">
		  <a href="about1.php">about us</a></li>

                <li><a href="contact-us.php">Contact Us</a></li>
              </ul>
            </div> <!--/.nav-collapse -->
          </div> <!--/.navbar-inner -->
        </div> <!--/.navbar -->
        <!-- End Main Menu -->
	
      </div> <!--/.container -->
    </section> <!--/#top --> 
    <!--  End Section Top -->
    
    <!-- Section Breadcrumbs-->
    <section id="breadcrumb">
      <div class="b-c">
	<div class="container">
	  <ul class="breadcrumb">
	    <li class="title">You are here</li>
	    <li><a href="#">Home</a> <span class="divider"><img src="img/br-arrow.png" alt="" /></span></li>
	    <li><a href="#">Features</a> <span class="divider"><img src="img/br-arrow.png" alt="" /></span></li>
	    <li class="active">Components</li>
	  </ul>
	</div> <!--/.container -->
      </div> <!--/.b-c -->
    </section> <!--#breadcrumb -->
    <!-- End Section Breadcrumb -->
     
    <!-- Section content --> 
    <section id="content">
      <div class="container marg-top">
	<div class="row-fluid">
	  
	  <!-- Tab -->
	  <div class="page">  
	    <h3 class="tree">Tab</h3>
	    <div class="tab-01">
	      <ul id="myTab" class="nav nav-tabs">
		<li class="active"><a href="#title" data-toggle="tab">Title</a></li>
		<li class=""><a href="#title-two" data-toggle="tab">Title Two</a></li>
		<li class=""><a href="#title-three" data-toggle="tab">Title Three</a></li>
		<li class=""><a href="#title-four" data-toggle="tab">Title Four</a></li>
		<li class=""><a href="#title-five" data-toggle="tab">Title Five</a></li>
	      </ul>
	      <div id="myTabContent" class="tab-content">
		<div class="tab-pane fade active in" id="title">
		  <p>Raw denim you probably haven't heard of them jean shorts Austin. Nesciunt tofu stumptown aliqua, retro synth master cleanse. Mustache cliche tempor, williamsburg carles vegan helvetica. Reprehenderit butcher retro keffiyeh dreamcatcher synth. Cosby sweater eu banh mi, qui irure terry richardson ex squid. Aliquip placeat salvia cillum iphone. Seitan aliquip quis cardigan american apparel, butcher voluptate nisi qui.</p>
		</div>
		<div class="tab-pane fade" id="title-two">
		  <p>Food truck fixie locavore, accusamus mcsweeney's marfa nulla single-origin coffee squid. Exercitation +1 labore velit, blog sartorial PBR leggings next level wes anderson artisan four loko farm-to-table craft beer twee. Qui photo booth letterpress, commodo enim craft beer mlkshk aliquip jean shorts ullamco ad vinyl cillum PBR. Homo nostrud organic, assumenda labore aesthetic magna delectus mollit. Keytar helvetica VHS salvia yr, vero magna velit sapiente labore stumptown. Vegan fanny pack odio cillum wes anderson 8-bit, sustainable jean shorts beard ut DIY ethical culpa terry richardson biodiesel. Art party scenester stumptown, tumblr butcher vero sint qui sapiente accusamus tattooed echo park.</p>
		</div>
		<div class="tab-pane fade" id="title-three">
		  <p>Etsy mixtape wayfarers, ethical wes anderson tofu before they sold out mcsweeney's organic lomo retro fanny pack lo-fi farm-to-table readymade. Messenger bag gentrify pitchfork tattooed craft beer, iphone skateboard locavore carles etsy salvia banksy hoodie helvetica. DIY synth PBR banksy irony. Leggings gentrify squid 8-bit cred pitchfork. Williamsburg banh mi whatever gluten-free, carles pitchfork biodiesel fixie etsy retro mlkshk vice blog. Scenester cred you probably haven't heard of them, vinyl craft beer blog stumptown. Pitchfork sustainable tofu synth chambray yr.</p>
		</div>
		<div class="tab-pane fade" id="title-four">
		  <p>Duis vitae tellus id justo lobortis pharetra sed eu risus. Aliquam malesuada tempor urna, sit amet malesuada nisi pulvinar ultrices. Aliquam sit amet libero tortor. Donec ultricies, lorem quis pharetra rhoncus, risus lacus bibendum eros, eget ultricies leo justo vel risus. Maecenas at nunc sit amet ligula rutrum fermentum. Donec sit amet nulla quis orci cursus feugiat non non enim. Pellentesque pretium, risus nec interdum tincidunt, felis massa lobortis arcu, euismod vestibulum mauris justo quis mi. Phasellus ac eros nulla, quis interdum quam.</p>
		</div>
		 <div class="tab-pane fade" id="title-five">
		  <p>Trust fund seitan letterpress, keytar raw denim keffiyeh etsy art party before they sold out master cleanse gluten-free squid scenester freegan cosby sweater. Fanny pack portland seitan DIY, art party locavore wolf cliche high life echo park Austin. Cred vinyl keffiyeh DIY salvia PBR, banh mi before they sold out farm-to-table VHS viral locavore cosby sweater. Lomo wolf viral, mustache readymade thundercats keffiyeh craft beer marfa ethical. Wolf salvia freegan, sartorial keffiyeh echo park vegan.</p>
		</div>
	      </div> <!--#myTabContent -->
	    </div> <!--/.tab-01 -->
	  </div>
	  <!-- End Tab -->
	  
	  <!-- Accordian(Collpse) -->
	  <div class="page">
	    <h3 class="tree">Accordian</h3>
	    <div class="accordion" id="accordion2">
		<div class="accordion-group">
		  <div class="accordion-heading">
		    <a class="accordion-toggle" data-toggle="collapse" data-parent=".accordion" href="#collapseOne">
		      Collapsible Group Item #1
	  	    </a>
		  </div>
		  <div id="collapseOne" class="accordion-body collapse" style="height: 0px; ">
		    <div class="accordion-inner">
		      <p>Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.</p>
		    </div>
		  </div>
		</div> <!--/.accordion-group -->
		
		<div class="accordion-group">
		  <div class="accordion-heading">
		    <a class="accordion-toggle" data-toggle="collapse" data-parent=".accordion" href="#collapseTwo">
		      Collapsible Group Item #2
		    </a>
		  </div>
		  <div id="collapseTwo" class="accordion-body collapse" style="height: 0px; ">
		    <div class="accordion-inner">
		      <p>Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.</p>
		    </div>
		  </div>
		</div> <!--/.accordion-group -->
		
		<div class="accordion-group">
		  <div class="accordion-heading">
		    <a class="accordion-toggle" data-toggle="collapse" data-parent=".accordion" href="#collapseThree">
		      Collapsible Group Item #3
		    </a>
		  </div>
		  <div id="collapseThree" class="accordion-body collapse">
		    <div class="accordion-inner">
		      <p>Nhil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.</p>
		    </div>
		  </div>
		</div> <!--/.accordion-group -->
	      </div> <!--/.accordion -->
	  </div> <!--/.page -->
	  <!-- End Accordian (Collpse) -->
	  
	  <!-- Tooltips -->	  
	  <div class="page">
	    <h3 class="tree">Tooltip</h3>
	    <p>Eyahh! These jelly <a href="#" data-rel="tooltip" data-original-title="Default tooltip" class="tooltips">kinders</a> arent... alive, are they? What? No, they cant even talk. Kick it! <a href="#" data-rel="tooltip" data-original-title="Another Sample" class="tooltips">Thanks</a> for helping me out guys. What are these buggers for, anyway? Oh, theyre decorations for my Biennial <a href="#" data-rel="tooltip" data-original-title="Gamball Ball" class="tooltips">Gumball Ball</a>. Tonight! Sounds like it gonna be large. Yes! So very large. Id like you to be there as my <a href="#" data-rel="tooltip" data-original-title="Default tooltip" class="tooltips">special</a> guest. You want me to go with you to the ball? Heck yes. <a href="#" data-rel="tooltip" data-original-title="Default tooltip" class="tooltips">As my pal!</a> Oh. Right. It starts at seven, so dont be late! Fionna, we got trouble! My tail is <a href="#" data-rel="tooltip" data-original-title="Default tooltip" class="tooltips">totally frizzin</a> out! Ill check it out.</p>
	    <p><a href="#" data-rel="tooltip" data-original-title="Default tooltip" class="tooltips">TOOLTIP ON TOP</a>&nbsp;&nbsp; / &nbsp;&nbsp;<a href="#" data-rel="tooltip" data-original-title="Tooltip on Right" class="tooltips-r">TOOLTIP ON RIGHT</a>&nbsp;&nbsp; / &nbsp;&nbsp;<a href="#" data-rel="tooltip" data-original-title="Tooltip on Bottom" class="tooltips-b">TOOLTIP ON BOTTOM</a>&nbsp;&nbsp; / &nbsp;&nbsp;<a href="#" data-rel="tooltip" data-original-title="Tooltip on Left" class="tooltips-l">TOOLTIP ON LEFT</a></p>
	  </div> <!--/.page -->
	  <!-- End Tooltips -->
	  
	  <!-- Popover -->
	  <div class="page">
	    <h3 class="tree">Popover</h3>
	    <p>Mouse hover the buttons below to see the various Popovers.</p>
	    <a href="#" class="popovers btn btn-green" data-rel="popover" data-content="Every hundred years, it spews evil spores across the land. Then lets burn its butt down to the roof rubbins." data-original-title="A Title">Popover Default</a>&nbsp;&nbsp;&nbsp;&nbsp;
	    <a href="#" class="popovers-b btn btn-green" data-rel="popover" data-content="Every hundred years, it spews evil spores across the land. Then lets burn its butt down to the roof rubbins." data-original-title="A Title">Popover on Bottom</a>&nbsp;&nbsp;&nbsp;&nbsp;
	    <a href="#" class="popovers-t btn btn-green" data-rel="popover" data-content="Every hundred years, it spews evil spores across the land. Then lets burn its butt down to the roof rubbins." data-original-title="A Title">Popover on Top</a>&nbsp;&nbsp;&nbsp;&nbsp;
	    <a href="#" class="popovers-l btn btn-green" data-rel="popover" data-content="Every hundred years, it spews evil spores across the land. Then lets burn its butt down to the roof rubbins." data-original-title="A Title">Popover on Left</a>	    
	  </div> <!--/.page -->
	  <!-- End Popover -->
	  
	  <!-- Progress Bar -->
	  <div class="page">
	    <h3 class="tree">Progress Bar</h3>
	    
	    <h3 class="black">Basic</h3>
	    <div class="progress">
              <div class="bar" style="width: 40%;"></div>
            </div>
	    
	    <h3 class="black">Striped</h3>
	    <div class="progress progress-striped">
	      <div class="bar" style="width: 50%;"></div>
	    </div>
	    
	    <h3 class="black">Animated(Not in IE)</h3>
	    <div class="progress progress-striped active">
	      <div class="bar" style="width: 70%;"></div>
	    </div>
	    
	    <h3 class="black">Stacked</h3>
	    <div class="progress">
	      <div class="bar bar-success" style="width: 35%;"></div>
	      <div class="bar bar-warning" style="width: 20%;"></div>
	      <div class="bar bar-danger" style="width: 10%;"></div>
	    </div>
	  </div> <!--/.page -->
	  <!-- End Progress Bar -->
	</div>
      </div> <!-- Container  -->
    </section>
    <!-- End Section content -->
    
    <!-- Footer -->
    <footer>
      <div class="container">
        <div class="row-fluid">
          <div class="span3">
            <ul class="nav nav-list">
              <li class="nav-header">Contact Us</li>
              <li><span class="label label-inverse">Mobile</span></li>
              <li><span class="label label-inverse">Mobile</span></li>
              <li><span class="label label-inverse">Email</span></li>
             <li><span class="label label-inverse">Email</span></li>

              
            </ul>
          </div> <!--/.span3 -->

          <div class="span3">
           <ul class="nav nav-list">
              <li class="nav-header">WEBSITE NAVIGATION</li>
              <li><a href="#">Home Page</a></li>
              <li><a href="#">Doctor</a></li>
              <li><a href="registration.php">Registration</a></li>
              <li><a href="patient.php">Patient</a></li>
              <li><a href="about1.php">About us</a></li>
              <li><a href="contact-us.php">Contact Us</a></li>
            </ul>
          </div> <!--/.span3 -->
        
          
          <div class="span12 copyright">
         
          </div><!--/.span12 -->
        </div><!--/.row-fluid -->
      </div><!--/.container -->
    </footer>
    <!-- End Footer -->

    <!-- Javascript Placed at the end of the document so the pages load faster -->
    
    <!-- Twitter Bootstrap -->
    <script src="js/bootstrap/bootstrap.js"></script>
    <script type="text/javascript">
      $(document).ready(function(){  
	$('.tooltips').tooltip({'placement':'top', 'trigger' : 'hover'});
	$('.tooltips-r').tooltip({'placement':'right', 'trigger' : 'hover'});
	$('.tooltips-b').tooltip({'placement':'bottom', 'trigger' : 'hover'});
	$('.tooltips-l').tooltip({'placement':'left', 'trigger' : 'hover'});  
	$('.accordian').collapse();
	$('.popovers').popover({'placement':'right'});
	$('.popovers-b').popover({'placement':'bottom'});
	$('.popovers-l').popover({'placement':'left'});
	$('.popovers-t').popover({'placement':'top'});
	
      });  
    </script>	

  </body>
</html>
