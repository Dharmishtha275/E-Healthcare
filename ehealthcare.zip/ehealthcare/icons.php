<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
  <head>
    <!-- Basic meta tags -->
   
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Medical Pro - Bootstrap Responsive Template</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- CSS styles -->
    <link href="css/style.css" rel="stylesheet">
      
    <!-- Google Web font 'PT Sans and Yanone Kaffeesatz' -->  
    <link href='http://fonts.googleapis.com/css?family=PT+Sans+Narrow|Yanone+Kaffeesatz:400,300,700' rel='stylesheet' type='text/css'>
     
    <!-- Jquery Library -->
    <script src="js/jquery-1.7.1.min.js"></script>
    
    <!-- for IE6-8 support of HTML5 elements & Seperate CSS for ie-8-7 -->
    <!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
      <link href="css/ie8-7.css" rel="stylesheet">
    <![endif]-->
    
  </head>

  <body>
    <!-- Header -->
    <header>
      <div class="container">
        <div class="row-fluid">
	  <!-- logo -->
          <div class="span6 logo">
            <a href="index.php"><img src="img/logo.png" /></a>
          </div>
	  <!-- End Logo -->
          
          <!-- Social menu -->
	  <div class="span6" id="social">
            <ul class="social">
              <li class="twitter">
		<a target="_blank" href="#">&nbsp;</a>
              </li>
	      <li class="facebook">
		<a target="_blank" href="#">&nbsp;</a>
	      </li>
            </ul>
          </div>
          <!-- End Social Menu -->
        </div> <!--/.row-fluid -->
      </div> <!--/.container -->
    </header>
    <!-- End Header -->
    
    <!-- Section Top -->
    <section id="top">
      <div class="container">
	<!-- Main Menu -->
        <div class="navbar">
          <div class="navbar-inner">
            <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
	      Main Menu
            </a>
            <div class="nav-collapse">
              <ul class="nav">
                <li><a href="index.php">Home</a></li>
                
                 <li class="dropdown">
                  <a href="doctorlogin.php">admin</a></li>
                  
                   
                  
                  <li class="dropdown">
                  <a href="registration.php">registration</a></li>
                  
                <li class="dropdown active">
                  <a  href="login.php">login</a></li>


                <li class="dropdown">
		  <a href="about1.php">about us</a></li>

                <li><a href="contact-us.php">Contact Us</a></li>
              </ul>
            </div> <!--/.nav-collapse -->
          </div> <!--/.navbar-inner -->
        </div> <!--/.navbar -->
        <!-- End Main Menu -->
	
      </div> <!--/.container -->
    </section> <!--/#top --> 
    <!--  End Section Top -->
    
    <!-- Section Breadcrumbs-->
    <section id="breadcrumb">
      <div class="b-c">
	<div class="container">
	  <ul class="breadcrumb">
	    <li class="title">You are here</li>
	    <li><a href="#">Home</a> <span class="divider"><img src="img/br-arrow.png" alt="" /></span></li>
	    <li><a href="#">Features</a> <span class="divider"><img src="img/br-arrow.png" alt="" /></span></li>
	    <li class="active">Icons</li>
	  </ul>
	</div> <!--/.container -->
      </div> <!--/.b-c -->
    </section> <!--#breadcrumb -->
    <!-- End Section Breadcrumb -->
     
    <!-- Section content -->
    <section id="content">
      <div class="container marg-top">
	<div class="row-fluid">
	  <div class="page">
	    <h3 class="tree">Icons</h3>
	    <ul class="the-icons clearfix">
	      <li><i class="icon-glass"></i> icon-glass</li>
	      <li><i class="icon-music"></i> icon-music</li>
	      <li><i class="icon-search"></i> icon-search</li>
	      <li><i class="icon-envelope"></i> icon-envelope</li>
	      <li><i class="icon-heart"></i> icon-heart</li>
	      <li><i class="icon-star"></i> icon-star</li>
	      <li><i class="icon-star-empty"></i> icon-star-empty</li>
	      <li><i class="icon-user"></i> icon-user</li>
	      <li><i class="icon-film"></i> icon-film</li>
	      <li><i class="icon-th-large"></i> icon-th-large</li>
	      <li><i class="icon-th"></i> icon-th</li>
	      <li><i class="icon-th-list"></i> icon-th-list</li>
	      <li><i class="icon-ok"></i> icon-ok</li>
	      <li><i class="icon-remove"></i> icon-remove</li>
	      <li><i class="icon-zoom-in"></i> icon-zoom-in</li>
	      <li><i class="icon-zoom-out"></i> icon-zoom-out</li>
	      <li><i class="icon-off"></i> icon-off</li>
	      <li><i class="icon-signal"></i> icon-signal</li>
	      <li><i class="icon-cog"></i> icon-cog</li>
	      <li><i class="icon-trash"></i> icon-trash</li>
	      <li><i class="icon-home"></i> icon-home</li>
	      <li><i class="icon-file"></i> icon-file</li>
	      <li><i class="icon-time"></i> icon-time</li>
	      <li><i class="icon-road"></i> icon-road</li>
	      <li><i class="icon-download-alt"></i> icon-download-alt</li>
	      <li><i class="icon-download"></i> icon-download</li>
	      <li><i class="icon-upload"></i> icon-upload</li>
	      <li><i class="icon-inbox"></i> icon-inbox</li>
  
	      <li><i class="icon-play-circle"></i> icon-play-circle</li>
	      <li><i class="icon-repeat"></i> icon-repeat</li>
	      <li><i class="icon-refresh"></i> icon-refresh</li>
	      <li><i class="icon-list-alt"></i> icon-list-alt</li>
	      <li><i class="icon-lock"></i> icon-lock</li>
	      <li><i class="icon-flag"></i> icon-flag</li>
	      <li><i class="icon-headphones"></i> icon-headphones</li>
	      <li><i class="icon-volume-off"></i> icon-volume-off</li>
	      <li><i class="icon-volume-down"></i> icon-volume-down</li>
	      <li><i class="icon-volume-up"></i> icon-volume-up</li>
	      <li><i class="icon-qrcode"></i> icon-qrcode</li>
	      <li><i class="icon-barcode"></i> icon-barcode</li>
	      <li><i class="icon-tag"></i> icon-tag</li>
	      <li><i class="icon-tags"></i> icon-tags</li>
	      <li><i class="icon-book"></i> icon-book</li>
	      <li><i class="icon-bookmark"></i> icon-bookmark</li>
	      <li><i class="icon-print"></i> icon-print</li>
	      <li><i class="icon-camera"></i> icon-camera</li>
	      <li><i class="icon-font"></i> icon-font</li>
	      <li><i class="icon-bold"></i> icon-bold</li>
	      <li><i class="icon-italic"></i> icon-italic</li>
	      <li><i class="icon-text-height"></i> icon-text-height</li>
	      <li><i class="icon-text-width"></i> icon-text-width</li>
	      <li><i class="icon-align-left"></i> icon-align-left</li>
	      <li><i class="icon-align-center"></i> icon-align-center</li>
	      <li><i class="icon-align-right"></i> icon-align-right</li>
	      <li><i class="icon-align-justify"></i> icon-align-justify</li>
	      <li><i class="icon-list"></i> icon-list</li>
  
	      <li><i class="icon-indent-left"></i> icon-indent-left</li>
	      <li><i class="icon-indent-right"></i> icon-indent-right</li>
	      <li><i class="icon-facetime-video"></i> icon-facetime-video</li>
	      <li><i class="icon-picture"></i> icon-picture</li>
	      <li><i class="icon-pencil"></i> icon-pencil</li>
	      <li><i class="icon-map-marker"></i> icon-map-marker</li>
	      <li><i class="icon-adjust"></i> icon-adjust</li>
	      <li><i class="icon-tint"></i> icon-tint</li>
	      <li><i class="icon-edit"></i> icon-edit</li>
	      <li><i class="icon-share"></i> icon-share</li>
	      <li><i class="icon-check"></i> icon-check</li>
	      <li><i class="icon-move"></i> icon-move</li>
	      <li><i class="icon-step-backward"></i> icon-step-backward</li>
	      <li><i class="icon-fast-backward"></i> icon-fast-backward</li>
	      <li><i class="icon-backward"></i> icon-backward</li>
	      <li><i class="icon-play"></i> icon-play</li>
	      <li><i class="icon-pause"></i> icon-pause</li>
	      <li><i class="icon-stop"></i> icon-stop</li>
	      <li><i class="icon-forward"></i> icon-forward</li>
	      <li><i class="icon-fast-forward"></i> icon-fast-forward</li>
	      <li><i class="icon-step-forward"></i> icon-step-forward</li>
	      <li><i class="icon-eject"></i> icon-eject</li>
	      <li><i class="icon-chevron-left"></i> icon-chevron-left</li>
	      <li><i class="icon-chevron-right"></i> icon-chevron-right</li>
	      <li><i class="icon-plus-sign"></i> icon-plus-sign</li>
	      <li><i class="icon-minus-sign"></i> icon-minus-sign</li>
	      <li><i class="icon-remove-sign"></i> icon-remove-sign</li>
	      <li><i class="icon-ok-sign"></i> icon-ok-sign</li>
  
	      <li><i class="icon-question-sign"></i> icon-question-sign</li>
	      <li><i class="icon-info-sign"></i> icon-info-sign</li>
	      <li><i class="icon-screenshot"></i> icon-screenshot</li>
	      <li><i class="icon-remove-circle"></i> icon-remove-circle</li>
	      <li><i class="icon-ok-circle"></i> icon-ok-circle</li>
	      <li><i class="icon-ban-circle"></i> icon-ban-circle</li>
	      <li><i class="icon-arrow-left"></i> icon-arrow-left</li>
	      <li><i class="icon-arrow-right"></i> icon-arrow-right</li>
	      <li><i class="icon-arrow-up"></i> icon-arrow-up</li>
	      <li><i class="icon-arrow-down"></i> icon-arrow-down</li>
	      <li><i class="icon-share-alt"></i> icon-share-alt</li>
	      <li><i class="icon-resize-full"></i> icon-resize-full</li>
	      <li><i class="icon-resize-small"></i> icon-resize-small</li>
	      <li><i class="icon-plus"></i> icon-plus</li>
	      <li><i class="icon-minus"></i> icon-minus</li>
	      <li><i class="icon-asterisk"></i> icon-asterisk</li>
	      <li><i class="icon-exclamation-sign"></i> icon-exclamation-sign</li>
	      <li><i class="icon-gift"></i> icon-gift</li>
	      <li><i class="icon-leaf"></i> icon-leaf</li>
	      <li><i class="icon-fire"></i> icon-fire</li>
	      <li><i class="icon-eye-open"></i> icon-eye-open</li>
	      <li><i class="icon-eye-close"></i> icon-eye-close</li>
	      <li><i class="icon-warning-sign"></i> icon-warning-sign</li>
	      <li><i class="icon-plane"></i> icon-plane</li>
	      <li><i class="icon-calendar"></i> icon-calendar</li>
	      <li><i class="icon-random"></i> icon-random</li>
	      <li><i class="icon-comment"></i> icon-comment</li>
	      <li><i class="icon-magnet"></i> icon-magnet</li>
  
	      <li><i class="icon-chevron-up"></i> icon-chevron-up</li>
	      <li><i class="icon-chevron-down"></i> icon-chevron-down</li>
	      <li><i class="icon-retweet"></i> icon-retweet</li>
	      <li><i class="icon-shopping-cart"></i> icon-shopping-cart</li>
	      <li><i class="icon-folder-close"></i> icon-folder-close</li>
	      <li><i class="icon-folder-open"></i> icon-folder-open</li>
	      <li><i class="icon-resize-vertical"></i> icon-resize-vertical</li>
	      <li><i class="icon-resize-horizontal"></i> icon-resize-horizontal</li>
	      <li><i class="icon-hdd"></i> icon-hdd</li>
	      <li><i class="icon-bullhorn"></i> icon-bullhorn</li>
	      <li><i class="icon-bell"></i> icon-bell</li>
	      <li><i class="icon-certificate"></i> icon-certificate</li>
	      <li><i class="icon-thumbs-up"></i> icon-thumbs-up</li>
	      <li><i class="icon-thumbs-down"></i> icon-thumbs-down</li>
	      <li><i class="icon-hand-right"></i> icon-hand-right</li>
	      <li><i class="icon-hand-left"></i> icon-hand-left</li>
	      <li><i class="icon-hand-up"></i> icon-hand-up</li>
	      <li><i class="icon-hand-down"></i> icon-hand-down</li>
	      <li><i class="icon-circle-arrow-right"></i> icon-circle-arrow-right</li>
	      <li><i class="icon-circle-arrow-left"></i> icon-circle-arrow-left</li>
	      <li><i class="icon-circle-arrow-up"></i> icon-circle-arrow-up</li>
	      <li><i class="icon-circle-arrow-down"></i> icon-circle-arrow-down</li>
	      <li><i class="icon-globe"></i> icon-globe</li>
	      <li><i class="icon-wrench"></i> icon-wrench</li>
	      <li><i class="icon-tasks"></i> icon-tasks</li>
	      <li><i class="icon-filter"></i> icon-filter</li>
	      <li><i class="icon-briefcase"></i> icon-briefcase</li>
	      <li><i class="icon-fullscreen"></i> icon-fullscreen</li>
	    </ul>
	  </div> <!--/.page -->
	</div> <!--/.row-fluid -->
      </div> <!--/.Container  -->
    </section>
    <!-- End Section content -->
    
    <!-- Footer -->
    <footer>
      <div class="container">
        <div class="row-fluid">
          <div class="span3">
            <ul class="nav nav-list">
              <li class="nav-header">Contact Us</li>
               <li><span class="label label-inverse">Mobile</span></li>
              <li><span class="label label-inverse">Mobile</span></li>
              <li><span class="label label-inverse">Email</span></li>
             <li><span class="label label-inverse">Email</span></li>

              
            </ul>
          </div> <!--/.span3 -->

          <div class="span3">
           <ul class="nav nav-list">
              <li class="nav-header">WEBSITE NAVIGATION</li>
              <li><a href="#">Home Page</a></li>
              <li><a href="#">Doctor</a></li>
              <li><a href="registration.php">Registration</a></li>
              <li><a href="patient.php">patients</a></li>
              <li><a href="about1.php">About us</a></li>
              <li><a href="contact-us.phpa">Contact Us</a></li>
            </ul>
          </div> <!--/.span3 -->
        
          
          <div class="span12 copyright">
         
          </div><!--/.span12 -->
        </div><!--/.row-fluid -->
      </div><!--/.container -->
    </footer>
    <!-- End Footer -->
    
    <!-- Javascript Placed at the end of the document so the pages load faster -->
    
    <!-- Twitter Bootstrap -->
    <script src="js/bootstrap/bootstrap.js"></script>

  </body>
</html>
