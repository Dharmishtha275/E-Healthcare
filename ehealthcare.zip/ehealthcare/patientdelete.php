<?php
$conn=mysql_connect("localhost","root","");
if($conn)
{
	echo"sucessfully";
}
mysql_select_db("patient",$conn);
$patient=$_POST['patient'];
$id=$_GET['id'];
$address=$_POST['address'];
$city=$_POST['city'];
$gender=$_POST['gender'];
$phoneno=$_POST['phoneno'];
$delete="DELETE FROM register WHERE id='".$id."'";
$query=mysql_query($delete);
header("location:patient.php");
?>