<?php
$conn=mysql_connect("localhost","root","");
if($conn)
{
	echo "connect";
}
mysql_select_db('eheathcare',$conn);

echo $id=$_REQUEST['id'];
echo $firstname=$_POST['firstname'];
echo $secondname=$_POST['secondname'];
echo $lastname=$_POST['lastname'];
echo $address=$_POST['address'];
echo $bg=$_POST['BloodGroup'];

echo $phoneno=$_POST['phoneno'];
echo $email=$_POST['email'];
echo $password=$_POST['password'];
$insert="INSERT INTO registration(id,firstname,secondname,address,blood_group,phoneno,email,password) VALUES('$id','$firstname','$secondname','$lastname','$address','$bg','$phoneno','$email','$password')";
$query=mysql_query($insert,$conn);

header("Location:registration.php");
if($query)
{
	echo "<script>alert('Registration successfully')<script>";
}
else
{
    echo "<script>alert('Soorryyy...')<script>";
}

?>
