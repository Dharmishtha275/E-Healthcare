-- phpMyAdmin SQL Dump
-- version 4.4.14
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Feb 17, 2016 at 11:05 AM
-- Server version: 5.6.26
-- PHP Version: 5.5.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ehealthcare`
--

-- --------------------------------------------------------

--
-- Table structure for table `answer`
--

CREATE TABLE IF NOT EXISTS `answer` (
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `ques` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `answer`
--

INSERT INTO `answer` (`name`, `email`, `ques`) VALUES
('hhj', 'hhh', 'kkk,'),
('ryu', ' ehealthcare@gmail.com', 'ghjkl');

-- --------------------------------------------------------

--
-- Table structure for table `appointment`
--

CREATE TABLE IF NOT EXISTS `appointment` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `age` int(100) NOT NULL,
  `no` int(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `appointment`
--

INSERT INTO `appointment` (`id`, `name`, `age`, `no`) VALUES
(1, 'gggggg', 0, 0),
(2, 'gggggg', 0, 0),
(4, '', 0, 0),
(7, 'opp', 9, 89000),
(8, 'jkll', 9, 890),
(9, 'uiioo', 90, 9876),
(10, 'rutuja', 45, 456),
(11, 'rutuja', 45, 456),
(12, ' ehealthcare', 12, 0),
(13, '', 0, 0),
(14, 'mmmm', 9, 89),
(15, 'mmmm', 9, 89),
(16, '', 0, 0),
(17, ' ehealthcare', 3, 4567),
(18, ' ehealthcare', 18, 2147483647),
(19, 'vb', 34, 5667),
(20, 'dddd', 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `doctlogin`
--

CREATE TABLE IF NOT EXISTS `doctlogin` (
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `doctor`
--

CREATE TABLE IF NOT EXISTS `doctor` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `skills` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `phoneno` int(100) NOT NULL,
  `appointment` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `doctor1`
--

CREATE TABLE IF NOT EXISTS `doctor1` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `skills` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `phoneno` int(100) NOT NULL,
  `appointment` int(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `doctor1`
--

INSERT INTO `doctor1` (`id`, `name`, `skills`, `address`, `city`, `phoneno`, `appointment`) VALUES
(11, ' ehealthcare', 'Dentist', 'yghyjj', 'Mumbai', 444, 1),
(17, '', 'Dentist', 'vvvvvvv', 'Mumbai', 0, 1),
(19, 'jjj', 'Physiotheraphist', 'jjjj', 'Mumbai', 2147483647, 1),
(20, '', 'Dentist', '', 'Mumbai', 0, 1),
(21, '', 'Dentist', '', 'Mumbai', 0, 1),
(22, 'nnm', 'Dentist', 'hvh', 'Mumbai', 2147483647, 3),
(23, '', 'Dentist', '', 'Mumbai', 0, 1),
(24, ' ehealthcare', 'Dentist', 'ghj', 'Mumbai', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `health`
--

CREATE TABLE IF NOT EXISTS `health` (
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `login`
--

CREATE TABLE IF NOT EXISTS `login` (
  `username` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `medicine`
--

CREATE TABLE IF NOT EXISTS `medicine` (
  `id` int(11) NOT NULL,
  `code` int(100) NOT NULL,
  `name` varchar(50) NOT NULL,
  `date` int(50) NOT NULL,
  `ex` int(50) NOT NULL,
  `batch` int(50) NOT NULL,
  `prize` int(50) NOT NULL,
  `qty` int(50) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `medicine`
--

INSERT INTO `medicine` (`id`, `code`, `name`, `date`, `ex`, `batch`, `prize`, `qty`) VALUES
(1, 0, ' ehealthcare', 0, 0, 0, 0, 0),
(2, 0, '', 0, 0, 0, 0, 0),
(3, 0, '', 0, 0, 0, 0, 0),
(4, 0, '', 0, 0, 0, 0, 0),
(5, 0, '', 0, 0, 0, 0, 0),
(6, 0, '', 0, 0, 0, 0, 0),
(7, 0, 'eed', 0, 56, 6, 5, 7),
(8, 5, 'ff', 0, 0, 0, 4, 0),
(9, 0, 'ijjkl', 0, 9, 9, 90, 9),
(10, 7, 'hjhjujhjhjh', 78, 67, 8, 56, 7),
(11, 5, 'ghhg', 444, 55, 55, 66, 400),
(12, 3, 'ttt', 33, 34, 44, 44, 400),
(13, 8, ' ehealthcare', 6, 9, 8, 90, 1),
(14, 6, ',,,,,', 0, 6, 8, 9, 6);

-- --------------------------------------------------------

--
-- Table structure for table `newsolution`
--

CREATE TABLE IF NOT EXISTS `newsolution` (
  `id` int(11) NOT NULL,
  `solution` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `patient`
--

CREATE TABLE IF NOT EXISTS `patient` (
  `id` int(11) NOT NULL,
  `patient` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `gender` varchar(100) NOT NULL,
  `phoneno` int(100) NOT NULL,
  `age` int(50) NOT NULL,
  `discription` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=42 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `patient`
--

INSERT INTO `patient` (`id`, `patient`, `address`, `city`, `gender`, `phoneno`, `age`, `discription`) VALUES
(24, 'name', '', 'Mumbai', '', 0, 0, ''),
(25, 'name', '', 'Mumbai', '', 0, 0, ''),
(26, 'name', '', 'Mumbai', '', 0, 0, ''),
(28, ' ehealthcare', 'hujnm ', 'Mumbai', 'Female', 2147483647, 90, 'jnmklk;lkkjuuikjjjjjjjjjjjjjn'),
(29, ' ehealthcare', 'hujnm ', 'Mumbai', 'Female', 2147483647, 90, 'jnmklk;lkkjuuikjjjjjjjjjjjjjn'),
(30, 'hhh', 'hhn', 'Mumbai', '', 2147483647, 87, 'jjjj'),
(31, 'hhh', 'hhn', 'Mumbai', '', 2147483647, 87, 'jjjj'),
(32, ' ehealthcare', 'ffff', 'Mumbai', 'Female', 2147483647, 88, 'uuuuuu'),
(33, ' ehealthcare', 'ffff', 'Mumbai', 'Female', 2147483647, 88, 'uuuuuu'),
(34, ' ehealthcare', 'ffff', 'Mumbai', 'Female', 2147483647, 88, 'uuuuuu'),
(35, 'rutuja', 'hhhhh', 'Pune', 'Female', 2147483647, 0, 'jjjjjj'),
(36, 'rutuja', 'ggggg', 'Mumbai', '', 2147483647, 8, 'gggggg'),
(40, ' ehealthcare', 'darwaja', 'Mumbai', 'on', 2147483647, 5, 'diases'),
(41, ' ehealthcare', 'surat', 'Banglor', 'Female', 2147483647, 18, 'diases');

-- --------------------------------------------------------

--
-- Table structure for table `quires`
--

CREATE TABLE IF NOT EXISTS `quires` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `doctor` varchar(100) NOT NULL,
  `quire` varchar(100) NOT NULL,
  `solution` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `quires`
--

INSERT INTO `quires` (`id`, `name`, `doctor`, `quire`, `solution`) VALUES
(2, '', '', '', ''),
(3, '', '', '', ''),
(4, '', '', '', ''),
(5, '', '', '', ''),
(6, '', '', '', ''),
(8, '', '', '', ''),
(9, '', '', '', ''),
(10, '', '', '', ''),
(11, '', '', '', ''),
(12, '', '', '', ''),
(13, '', '', ' ehealthcare', ''),
(14, '', '', ' ehealthcare', ''),
(15, '', '', 'fvfvfffvc', ''),
(16, '', '', 'rutuja\r\n', ''),
(17, '', '', 'ytyuj', ''),
(18, '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `registration`
--

CREATE TABLE IF NOT EXISTS `registration` (
  `id` int(11) NOT NULL,
  `firstname` varchar(100) NOT NULL,
  `secondname` varchar(100) NOT NULL,
  `lastname` varchar(100) NOT NULL,
  `address` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `phoneno` int(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registration`
--

INSERT INTO `registration` (`id`, `firstname`, `secondname`, `lastname`, `address`, `city`, `phoneno`, `email`, `password`) VALUES
(6, 'rutuja', 'tuioo', 'kloo', 'mjjjjjjjjjjjjjjjjjj', 'Mumbai', 7899, 'jhkkk', '89ookj'),
(7, '', '', '', '', 'Mumbai', 0, '', ''),
(8, ' ehealthcare', 'kk', 'f', 'nnnnnnnnn', 'Mumbai', 2147483647, ' ehealthcaremendapara@gmail.com', 'ddddfvvv ');

-- --------------------------------------------------------

--
-- Table structure for table `solution`
--

CREATE TABLE IF NOT EXISTS `solution` (
  `id` int(11) NOT NULL,
  `solution` varchar(100) NOT NULL
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `solution`
--

INSERT INTO `solution` (`id`, `solution`) VALUES
(1, ''),
(2, ''),
(3, ''),
(4, ''),
(5, ''),
(6, ''),
(7, ''),
(8, ''),
(9, ''),
(10, ''),
(11, ''),
(12, 'diase'),
(13, 'please take proper medicine'),
(14, 'fadaycd'),
(15, 'gdejwfre');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `appointment`
--
ALTER TABLE `appointment`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doctor`
--
ALTER TABLE `doctor`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `doctor1`
--
ALTER TABLE `doctor1`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `medicine`
--
ALTER TABLE `medicine`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `newsolution`
--
ALTER TABLE `newsolution`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `patient`
--
ALTER TABLE `patient`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `quires`
--
ALTER TABLE `quires`
  ADD PRIMARY KEY (`id`),
  ADD KEY `solution` (`quire`);

--
-- Indexes for table `registration`
--
ALTER TABLE `registration`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `solution`
--
ALTER TABLE `solution`
  ADD KEY `quire` (`solution`),
  ADD KEY `id` (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `appointment`
--
ALTER TABLE `appointment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=21;
--
-- AUTO_INCREMENT for table `doctor`
--
ALTER TABLE `doctor`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `doctor1`
--
ALTER TABLE `doctor1`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=25;
--
-- AUTO_INCREMENT for table `medicine`
--
ALTER TABLE `medicine`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `newsolution`
--
ALTER TABLE `newsolution`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `patient`
--
ALTER TABLE `patient`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=42;
--
-- AUTO_INCREMENT for table `quires`
--
ALTER TABLE `quires`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `registration`
--
ALTER TABLE `registration`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=9;
--
-- AUTO_INCREMENT for table `solution`
--
ALTER TABLE `solution`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT,AUTO_INCREMENT=16;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
