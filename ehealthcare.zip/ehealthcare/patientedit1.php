<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<!-- Basic meta tags -->


    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Medical Pro - Bootstrap Responsive Template</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- CSS styles -->
    <link href="css/style.css" rel="stylesheet">
      
    <!-- Google Web font 'PT Sans and Yanone Kaffeesatz' -->  
    <link href='http://fonts.googleapis.com/css?family=PT+Sans+Narrow|Yanone+Kaffeesatz:400,300,700' rel='stylesheet' type='text/css'>
     
    <!-- Jquery Library -->
    <!--<script src="js/jquery-1.7.1.min.js"></script>-->
    
    <!-- for IE6-8 support of HTML5 elements & Seperate CSS for ie-8-7 -->
    <!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
      <link href="css/ie8-7.css" rel="stylesheet">
    <![endif]-->
    
 <script type="text/javascript">
    function validation()
{ 
   var id=document.htr.id.value;
   var patient=document.htr.patient.value;
   var address=document.htr.address.value;
   var city=document.htr.city.value;
   var phoneno=document.htr.phoneno.value;
   var msg='';
   var error='';
    
     if(id == '')
   {
	     error="<b style='color:red'><i> Please Enter Patientid</i></b></br>";
         msg+=error;
   }
    
     if(patient == '')
   {
	     error="<b style='color:red'><i>Please Enter Patientname</i></b></br>";
         msg+=error;
   }
   if(address == '')
   {
		 error="<b style='color:red'><i>Please Enter Address</i></b></br>";
         msg+=error;
 
   }
    
     if(city == '')
   {
	     error="<b style='color:red'><i>Please Enter City</i></b></br>";
         msg+=error;
   }
   
     if(phoneno == '')
   {
	     error="<b style='color:red'><i>Please Enter Phoneno</i></b></br>";
         msg+=error;
   }
   
     else if(!phone_no.test(phoneno))
   {
	  error=alert("please enter 10 digit no");
       msg+=error;  
   }     
    
   if(msg !='')
   {
	    document.getElementById("error_div").innerHTML = msg;
		return false;
   }
}
</script>
</head>
<body>
    <!-- Header -->
    <header>
      <div class="container">
        <div class="row-fluid">
	  <!-- logo -->
          <div class="span6 logo">
            <a href="index.php"><img src="img/plo.jpg" /></a>
          </div>
	  <!-- End Logo -->
          
          <!-- Social menu -->
	  <div class="span6" id="social">
            <ul class="social">
              <li class="twitter">
		<a target="_blank" href="#">&nbsp;</a>
              </li>
	      <li class="facebook">
		<a target="_blank" href="#">&nbsp;</a>
	      </li>
            </ul>
          </div>
          <!-- End Social Menu -->
        </div> <!--/.row-fluid -->
      </div> <!--/.container -->
    </header>
    <!-- End Header -->
    
    <!-- Section Top -->
    <section id="top">
      <div class="container">
	<!-- Main Menu -->
        <div class="navbar">
          <div class="navbar-inner">
            <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">

	                     	      
              	      Main Menu
            </a>
            <div class="nav-collapse">
              <ul class="nav">
                              <li><a href="our-doctor.php">Our-doctors</a></li>

                                  <li class="dropdown">

                <li><a href="patient.php">Patient</a></li>
                
                 <li class="dropdown">
                  <a href="service.php">services</a></li>
                  
                
                  
                <li class="dropdown">
		  <a href="index.php">Logout</a></li>
           
           
              </ul>
            </div> <!--/.nav-collapse -->
          </div> <!--/.navbar-inner -->
        </div> <!--/.navbar -->
        <!-- End Main Menu -->
	
      </div> <!--/.container -->
    </section> <!--/#top --> 
    <!--  End Section Top -->
    
    <!-- Section Breadcrumbs-->
    <section id="breadcrumb">
      <div class="b-c">
	<div class="container">
	  <ul class="breadcrumb">
	  </ul>
	</div> <!--/.container -->
      </div> <!--/.b-c -->
    </section> <!--#breadcrumb -->
    <!-- End Section Breadcrumb -->
    <script type="text/javascript">
  
    function validation()
{ 
   var id=document.htr.id.value;
   var patient=document.htr.patient.value;
   var address=document.htr.address.value;
   var city=document.htr.city.value;
   var phoneno=document.htr.phoneno.value;

   var msg='';
   var error='';
    
     if(id == '')
   {
	     error=alert("Please Enter Patientid");
         msg+=error;
   }
    
     if(patient == '')
   {
	     error=alert("Please Enter Patientname");
         msg+=error;
   }
   if(address == '')
   {
		 error=alert("Please Enter Address");
         msg+=error;
 
   }
    
     if(city == '')
   {
	     error=alert("Please Enter City");
         msg+=error;
   }
   
     if(phoneno == '')
   {
	     error=alert("Please Enter Phoneno");
         msg+=error;
   }
   if(msg !='')
   {
	  
		return false;
   }
}
</script>





<?php
 
   $conn=mysql_connect("localhost","root","");
   mysql_select_db("ehealthcare",$conn);
   $id=$_GET['id'];
   $select= "SELECT * FROM patient where id=".$id;
   $query= mysql_query($select,$conn);
   while($row=mysql_fetch_assoc($query))
   {
   
?>
<br><br><br>
<form id="hor" name="htr" action="patientupdate1.php?id=<?php echo $row['id']; ?>" method="POST" onsubmit="return validation()">
<div id="error_div"></div>
<table align="center" border="2" bordercolor="#00FFFF">
<h1 align="center"><font face="Times New Roman, Times, serif" color="#FF0000"><i>Update now....</i></font></h1>
<tr>
<td><font size="+1" face="Times New Roman, Times, serif" color="#0000FF"><i>Patientname:</i></font></td>
<td><input type="text" name="patient" id="patient" value="<?php echo $row['patient']; ?>" /></td>
</tr>
<tr>
<td><font size="+1" face="Times New Roman, Times, serif" color="#0000FF"><i>Address:</i></font></td>
<td><textarea name="address" id="address" cols="5" rows="5" value="<?php echo $row['address']; ?>" /></textarea></td>
</tr>
<tr>
<td><font size="+1" face="Times New Roman, Times, serif" color="#0000FF"><i>City:</i></font></td>
<td><select name="city" id="city">
<option>Mumbai</option>
<option>Banglor</option>
<option>Pune</option>
<option>Banglor</option>
<option>Delhi</option>
</select>
</td>
</tr>
<tr>
<td><font size="+1" face="Times New Roman, Times, serif" color="#0000FF"><i>Gender:</i></font></td>
<td><input type="radio" name="gender" id="gender" />male
<input type="radio" name="gender" id="gender" />female
</td>
</tr>
<tr>
<td><font size="+1" face="Times New Roman, Times, serif" color="#0000FF"><i>Phoneno:</i></font></td>
<td><input type="text" name="phoneno" id="phoneno" value="<?php echo $row['phoneno']; ?>" /></td>
</tr>
<tr>
<td><font size="+1" face="Times New Roman, Times, serif" color="#0000FF"><i>age:</i></font></td>
<td><input type="text" name="age" id="age" value="<?php echo $row['age']; ?>" /></td>
</tr>
<tr>
<td><font size="+1" face="Times New Roman, Times, serif" color="#0000FF"><i>description:</i></font></td>
<td><textarea name="discription" id="discription" cols="5" rows="5" value="<?php echo $row['discription']; ?>" /></textarea></td>
</tr>

<tr>
<td colspan="2" align="center"><input type="submit" class="btn-green" name="submit" value="edit">
</td>
</tr>
</table>
</form>
<?php
   }
?><br /><br /><br /><br /><br />
           <!-- Footer -->
    <footer>
      <div class="container">
        <div class="row-fluid">
          <div class="span3">
            <ul class="nav nav-list">
              <li class="nav-header">Contact Us</li>
              <li><span class="label label-inverse">Mobile</span></li>
              <li><span class="label label-inverse">Mobile</span></li>
              <li><span class="label label-inverse">Email</span></li>
             <li><span class="label label-inverse">Email</span></li>

              
            </ul>
          </div><!--/.span3 -->

          <div class="span3">
           <ul class="nav nav-list">
              <li class="nav-header">WEBSITE NAVIGATION</li>
              <li><a href="#">Home Page</a></li>
              <li><a href="doctor1.php">Doctor</a></li>
              <li><a href="registration.php">Registration</a></li>
              <li><a href="patient.php">Patient</a></li>
              <li><a href="about1.php">About us</a></li>
              <li><a href="contact-us.php">Contact Us</a></li>
            </ul>
          </div><!--/.span3 -->
        
          <div class="span3">
            <ul class="nav nav-list">
              <li class="nav-header">Social with us</li>
              <li><a href="#">Facebook</a></li>
              <li><a href="#">Twitter</a></li>
              <li><a href="#">Google Plus</a></li>
              <li><a href="#">Linkedin</a></li>
              <li><a href="#">Youtube</a></li>
            </ul>
          </div><!--/.span3 -->

          <div class="span3">
            <ul class="nav nav-list">
              <li class="nav-header">Sample Menu</li>
              <li><a href="#">Menu one</a></li>
              <li><a href="#">Menu Two</a></li>
              <li><a href="#">Menu Three</a></li>
              <li><a href="#">Menu Four</a></li>
              <li><a href="#">Menu Five</a></li>
              <li><a href="#">Menu Six</a></li>
            </ul>
          </div><!--/.span3 -->
          
          <div class="span12 copyright">
         
          </div><!--/.span12 -->
        </div><!--/.row-fluid -->
      </div><!--/.container -->
    </footer>
    <!-- End Footer -->
    
    <!-- Javascript Placed at the end of the document so the pages load faster -->
    
    <!-- Twitter Bootstrap -->
    <script src="js/bootstrap/bootstrap.js"></script>
    
    <!-- Form Validation -->
    <script src="js/validate/jquery.validationEngine.js"></script>
    <script>
      jQuery(document).ready(function(){
	// binds form submission and fields to the validation engine
      	jQuery("#formID").validationEngine();
      });
    </script>
    
    <!-- Elastislide -->
    <script type="text/javascript" src="js/jquery.elastislide.js"></script>
    <script type="text/javascript">
		$('#carousel').elastislide({
			  imageW 	: 180,
			  minItems	: 5
		});	
    </script>

  </body>
</html>

          
          
 





	 
    
   



 
</body>
</html>