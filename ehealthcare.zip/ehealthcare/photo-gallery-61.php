<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
  <head>
    <!-- Basic meta tags -->
   
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Medical Pro - Bootstrap Responsive Template</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- CSS Styles -->
    <link rel="stylesheet" type="text/css" href="file:///E|/E-healthcare/css/prettyPhoto.css"/>
    <link href="file:///E|/E-healthcare/css/style.css" rel="stylesheet">
      
    <!-- Google Web font 'PT Sans and Yanone Kaffeesatz' -->  
    <link href='http://fonts.googleapis.com/css?family=PT+Sans+Narrow|Yanone+Kaffeesatz:400,300,700' rel='stylesheet' type='text/css'>
     
    <!-- Jquery Library -->
    <script src="file:///E|/E-healthcare/js/jquery-1.7.1.min.js"></script>
    
    <!-- For IE6-8 support of HTML5 elements & Seperate CSS for ie-8-7 -->
    <!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
      <link href="css/ie8-7.css" rel="stylesheet">
    <![endif]-->
  </head>

  <body>
    
    <!-- Header -->
    <header>
      <div class="container">
        <div class="row-fluid">
	  <!-- logo -->
          <div class="span6 logo">
            <a href="index.php"><img src="img/logo.png" /></a>
          </div>
	  <!-- End Logo -->
          
          <!-- Social menu -->
	  <div class="span6" id="social">
            <ul class="social">
              <li class="twitter">
		<a target="_blank" href="#">&nbsp;</a>
              </li>
	      <li class="facebook">
		<a target="_blank" href="#">&nbsp;</a>
	      </li>
            </ul>
          </div>
          <!-- End Social Menu -->
        </div> <!--/.row-fluid -->
      </div> <!--/.container -->
    </header>
    <!-- End Header -->
    
    <!-- Section Top -->
    <section id="top">
      <div class="container">
	<!-- Main Menu -->
        <div class="navbar">
          <div class="navbar-inner">
            <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
	      Main Menu
            </a>
            <div class="nav-collapse">
              <ul class="nav">
                <li><a href="index.php">Home</a></li>
                
                 <li class="dropdown">
                  <a href="doctorlogin.php">admin</a></li>
                  
                   
                
                  
                   <li class="dropdown">
                  <a href="registration.php">registration</a></li> 
                      
                <li class="dropdown">
                  <a href="login.php">login</a></li>
            
          
                <li class="dropdown">
		  <a href="about1.php">about us</a></li>
          
                <li><a href="contact-us.php">Contact Us</a></li>
              </ul>
            </div> <!--/.nav-collapse -->
          </div> <!--/.navbar-inner -->
        </div> <!--/.navbar -->
        <!-- End Main Menu -->
	
      </div> <!--/.container -->
    </section> <!--/#top --> 
    <!--  End Section Top -->
    
    <!-- Section Breadcrumbs-->
    <section id="breadcrumb">
      <div class="b-c">
	<div class="container">
	  <ul class="breadcrumb">
	    <li class="title">You are here</li>
	    <li><a href="#">Home</a> <span class="divider"><img src="file:///E|/E-healthcare/img/br-arrow.png" alt="" /></span></li>
	    <li><a href="#">About us</a> <span class="divider"><img src="file:///E|/E-healthcare/img/br-arrow.png" alt="" /></span></li>
	    <li class="active">4-Columns</li>
	  </ul>
	</div> <!--/.container -->
      </div> <!--/.b-c -->
    </section> <!--#breadcrumb -->
    <!-- End Section Breadcrumb -->
    
    <!-- Section content -->
    <section id="content">
      <div class="container">
        <div class="row-fluid">
	  
	    <!-- Category Filter -->
	    
	    <!-- End Category Filter -->
      
	    <!-- Gallery Items -->
	    <ul class="gallery group 3-col"> 
	      <li class="item span2" data-id="id-1" data-type="Category-1">
		  <a href="img/New folder/images (15).jpg" data-rel="prettyPhoto[portfolio]"><img src="img/New folder/images (15).jpg" /></a>
	      </li> 
	      <li class="item span2" data-id="id-2" data-type="Category-2">
		  <a href="img/New folder/images (14).jpg" data-rel="prettyPhoto[portfolio]"><img src="img/New folder/images (14).jpg" /></a>
	      </li>
	      <li class="item span2" data-id="id-3" data-type="Category-2">
		<a href="img/New folder/images (20).jpg" data-rel="prettyPhoto[portfolio]"><img src="img/New folder/images (20).jpg" /></a>
	      </li>
	      <li class="item span2" data-id="id-4" data-type="Category-3">
		<a href="img/New folder/images (18).jpg" data-rel="prettyPhoto[portfolio]"><img src="img/New folder/images (18).jpg" /></a>
	      </li>
	      <li class="item span2" data-id="id-5" data-type="Category-3">
		<a href="img/New folder/download (27).jpg" data-rel="prettyPhoto[portfolio]"><img src="img/New folder/images (27).jpg" /></a>
	      </li>
	      <li class="item span2" data-id="id-6" data-type="Category-4">
		<a href="img/New folder/images (26).jpg" data-rel="prettyPhoto[portfolio]"><img src="img/New folder/images (26).jpg" /></a>
	      </li>
	      <li class="item span2" data-id="id-7" data-type="Category-5">
		<a href="img/New folder/images (9).jpg" data-rel="prettyPhoto[portfolio]"><img src="img/New folder/images (9).jpg"  alt="Yulia Gorbachenko, Wavelength 1" /></a>
	      </li>
	      <li class="item span2" data-id="id-8" data-type="Category-6">
		<a href="img/New folder/images (12).jpg" data-rel="prettyPhoto[portfolio]"><img src="img/New folder/images (12).jpg" /></a>
	      </li>
	      <li class="item span2" data-id="id-9" data-type="Category-6">
		<a href="img/New folder/images (16).jpg" data-rel="prettyPhoto[portfolio]"><img src="img/New folder/images (16).jpg" alt="Yulia Gorbachenko, On Fire 2" /></a>
	      </li>
	      
	    </ul>
	    <!-- End Gallery Items -->
	    
	</div> <!--/.row-fliud -->
      </div> <!--/.Container -->
    </section> <!--/.#content -->
    <!-- End content -->
      
    <!-- Footer -->
    <footer>
      <div class="container">
        <div class="row-fluid">
          <div class="span3">
            <ul class="nav nav-list">
              <li class="nav-header">Contact Us</li>
              <li><span class="label label-inverse">Mobile</span></li>
              <li><span class="label label-inverse">Mobile</span></li>
              <li><span class="label label-inverse">Email</span></li>
             <li><span class="label label-inverse">Email</span></li>

                        
            </ul>
          </div> <!--/.span3 -->

          <div class="span3">
           <ul class="nav nav-list">
              <li class="nav-header">WEBSITE NAVIGATION</li>
              <li><a href="#">Home Page</a></li>
              <li><a href="doctor1.php">Doctor</a></li>
              <li><a href="registration.php">Registration</a></li>
              <li><a href="#">Patient</a></li>
              <li><a href="about1.php">About us</a></li>
              <li><a href="#">Contact Us</a></li>
            </ul>
          </div> <!--/.span3 -->
        
          
          <div class="span12 copyright">
         
          </div><!--/.span12 -->
        </div><!--/.row-fluid -->
      </div><!--/.container -->
    </footer>
    <!-- End Footer -->
    
    <!-- Javascript Placed at the end of the document so the pages load faster -->
    
    <!-- For Photo Gallery and Image Popups -->	
    <script type="text/javascript" src="file:///E|/E-healthcare/js/photo-gallery/jquery.prettyPhoto.js"></script> 
    <script type="text/javascript" src="file:///E|/E-healthcare/js/photo-gallery/jquery.quicksand.js"></script> 
    <script type="text/javascript" src="file:///E|/E-healthcare/js/photo-gallery/jquery.easing.1.3.js"></script> 
    <script type="text/javascript" src="file:///E|/E-healthcare/js/photo-gallery/script.js"></script>
    <script type="text/javascript">
      $(document).ready(function() {
	$("a[data-rel^='prettyPhoto']").prettyPhoto();
      });
    </script>
    
    <!-- Twitter Bootstrap -->
    <script src="file:///E|/E-healthcare/js/bootstrap/bootstrap.js"></script>
		
  </body>
</html>

