<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body >
<script>
function validation()
{
	$uname=document.rep.username.value;
		
}
</script>
<br />
<br />
<br />
<br />


<form name="rep" id="rep" action="index.php" method="post">
<h1 align="center"><font face="Times New Roman, Times, serif" size="+3"><i>Login</i></font></h1><br />
<center>
<font face="Times New Roman, Times, serif" size="+2"><i>Username</i></font>
<input type="text" name="username" id="username" /><br />
<font face="Times New Roman, Times, serif" size="+2"><i>Password</i></font>
<input type="password" name="password" id="password" /><br />
<h1 align="center"><a href="index.php"><input type="submit" name="submit" id="submit" value="login" /></a></h1>
</center>
</form>
</body>
</html>