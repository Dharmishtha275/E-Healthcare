<?php
$conn=mysql_connect("localhost","root","");
if($conn)
{
	echo"sucessfully";
}
mysql_select_db("ehealthacare",$conn);
$patient=$_POST['patient'];
$id=$_GET['id'];
$address=$_POST['address'];
$city=$_POST['city'];
$gender=$_POST['gender'];
$phoneno=$_POST['phoneno'];
$update="UPDATE register SET patient='".$patient."',id='".$id."',address='".$address."',city='".$city."',gender='".$gender."',phoneno='".$phoneno."'";
$query=mysql_query($update);
header("location:patient.php");
?>