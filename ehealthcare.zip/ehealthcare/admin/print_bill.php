<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<div align="left">
<?php
   $conn=mysql_connect("localhost","root","");
mysql_select_db("ehealthcare",$conn);

      
   $id=$_GET['bill_id'];
   $select= "SELECT * FROM bill where bill_id='$id'";
   $query4= mysql_query($select);
    while($row=mysql_fetch_assoc($query4))
   {
	    echo "<div align='center' style='color:purple; font-size:30px'>";
		echo "Bill Of ".$row['patient_name'];
		echo "</div>"."<br></br></br>"; 
		echo "<div style='text-align=left;color:teal; padding-left:250px'>";
        echo "Patient Name  ::"."  ".$row['patient_name']."</br></br>";
		echo "Addrees  ::"."  ".$row['addr']."</br></br>";
		echo "date ::".$row['bill_date']."</br></br>";
		echo "Contact Number  ::" ."  ".$row['cont_no']."</br></br>";
		echo "Medicine name  ::"."  ".$row['med_name']."</br></br>";
		echo "Quantity  ::"."  ".$row['quantity']."</br></br>";
		echo "Price per Quatity  ::"."  ".$row['price']."</br></br>";
		echo "discount per Quatity  ::"."  ".$row['discount']."</br></br>";
		echo "Total  ::"."  ".$row['total']."</br></br>";
		echo " <div style='padding-left:70px'>";
		echo "<input type='submit' onclick='window.print()' name='print' value='print'/>"."</div>";
		echo "</div>";
		
	    	 
   }
   
?>
</div>
</body>
</html>