<?php
$conn=mysql_connect("localhost","root","");
mysql_select_db("patient",$conn);
$patient=$_POST['patient'];
$id=$_GET['id'];
$address=$_POST['address'];
$city=$_POST['city'];
$gender=$_POST['gender'];
$phoneno=$_POST['phoneno'];
$insert="INSERT INTO register(patient,id,address,city,gender,phoneno) VALUES ('$patient','$id','$address','$city','$gender','$phoneno')";
$query=mysql_query($insert,$conn);
?>