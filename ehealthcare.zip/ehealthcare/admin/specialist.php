<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
  <head>
    <!-- Basic meta tags -->
   
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Medical Pro - Bootstrap Responsive Template</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- CSS styles -->
    <link href="css/style.css" rel="stylesheet">
      
    <!-- Google Web font 'PT Sans and Yanone Kaffeesatz' -->  
    <link href='http://fonts.googleapis.com/css?family=PT+Sans+Narrow|Yanone+Kaffeesatz:400,300,700' rel='stylesheet' type='text/css'>
     
    <!-- Jquery Library -->
    <script src="js/jquery-1.7.1.min.js"></script>
    
    <!-- for IE6-8 support of HTML5 elements & Seperate CSS for ie-8-7 -->
    <!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
      <link href="css/ie8-7.css" rel="stylesheet">
    <![endif]-->
    
  </head>

  <body>
    <!-- Header -->
    <header>
      <div class="container">
        <div class="row-fluid">
	  <!-- logo -->
          <div class="span6 logo">
            <a href="index.html"><img src="img/plo.jpg" alt="" /></a>
          </div>
	  <!-- End Logo -->
          
          <!-- Social menu -->
	  <div class="span6" id="social">
            <ul class="social">
              <li class="twitter">
		<a target="_blank" href="#">&nbsp;</a>
              </li>
	      <li class="facebook">
		<a target="_blank" href="#">&nbsp;</a>
	      </li>
            </ul>
          </div>
          <!-- End Social Menu -->
        </div> <!--/.row-fluid -->
      </div> <!--/.container -->
    </header>
    <!-- End Header -->
    
    <!-- Section Top -->
    <section id="top">
      <div class="container">
	<!-- Main Menu -->
        <div class="navbar">
          <div class="navbar-inner">
    <!--        <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">

             	      
              	      Main Menu
            </a>
            <div class="nav-collapse">
              <ul class="nav">
                              <li><a href="our-doctor.php">Our-doctors</a></li>
                              
                                                           
                                               <li class="dropdown">
                  <a href="specialist.php">specialist</a></li>
   

                                  <li class="dropdown">

                <li><a href="patient.php">Patient-detail</a></li>
                
                 <li class="dropdown">
                  <a href="service.php">services</a></li>
                  
                
                  
                <li class="dropdown">
		  <a href="index.php">Logout</a></li>
          -->
           
              </ul>
            </div> <!--/.nav-collapse -->
          </div> <!--/.navbar-inner -->
        </div> <!--/.navbar -->
        <!-- End Main Menu -->
	
      </div> <!--/.container -->
    </section> <!--/#top --> 
    <!--  End Section Top -->
    
    <!-- Section Breadcrumbs-->
    <section id="breadcrumb">
      <div class="b-c">
	<div class="container">
	  <ul class="breadcrumb">
	  </ul>
	</div> <!--/.container -->
      </div> <!--/.b-c -->
    </section> <!--#breadcrumb -->
    <!-- End Section Breadcrumb -->
    
    <!-- Section content -->
    <section id="content">
      <div class="container">
        <div class="row-fluid">
	  <div class="page clearfix">
	    <div class="span4 hid">
	    </div>
	    <div class="span4">
	    </div>
	    <div class="span4 hid">
	    </div>
	    
<h3 class="marg-top-med">Dr.Sanjiv Dang</h3>
	    <p>ENT/Otolaryngologist </p>
        <p>*Consulation</p>
        <p>*Hearning Aid</p>
        <p>*Wax Removal</p>
        <p>MON TO SAT 5:30PM TO 8:30PM </p>
                <a href="../newappoint.php"> <input type="submit" class="btn btn-green" value="Book appointment"/></a>

        <h3 class="marg-top-med">Dr.Nabin Kumar Pattnaik</h3>
	    <p>MD-Ophthalmology,42 years Eye-specialist  </p>
        <p>*eye checkup</p>
        <p>*cartarcat surgery</p>
        <p>MON TO SAT 8AM TO 2PM </p>
                    <a href="../newappoint.php"><input type="submit" class="btn btn-green" value="Book appointment"/></a>
                    
        <h3 class="marg-top-med">Dr.Vishal Agrawal</h3>
	    <p>M.CH (CTVS,MS,MBBS,),17 year Experience in Cardiologist </p>
        <p>*angio graphic</p>
        <p>*Heart</p>
        <p>MON TO SAT 8AM TO 5PM </p>
                    <a href="../newappoint.php"><input type="submit" class="btn btn-green" value="Book appointment"/></a>
          
           <h3 class="marg-top-med">Dr.Jay Mahida</h3>
	    <p>Dentist ,.20 year Experience in Dental surgery  </p>
        <p>*OPD Specialist</p>
        <p>*Surgery</p>
        <p>MON TO SAT 8AM TO 5PM </p>
                    <a href="../newappoint.php"><input type="submit" class="btn btn-green" value="Book appointment"/></a>

	    
	      
	     <!--/.caption -->
        
        

	  </div> <!--/.page -->  
        </div> <!--/.row-fluid -->
      </div> <!--/.Container -->
    </section> <!--#content -->
    <!-- End Section content-->
    
    <!-- Footer -->
    <footer>
      <div class="container">
        <div class="row-fluid">
          <div class="span3">
            <ul class="nav nav-list">
              <li class="nav-header">Contact Us</li>
              <li><span class="label label-inverse">Telephone</span></li>
              <li><span class="label label-inverse">Fax</span> </li>
              <li><span class="label label-inverse">Mobile</span> </li>
              <li><span class="label label-inverse">Email</span> </li>
              <li><span class="label label-inverse">Location</span></li>
            </ul>
          </div> <!--/.span3 -->

          <div class="span3">
           <ul class="nav nav-list">
              <li class="nav-header">WEBSITE NAVIGATION</li>
              <li><a href="#">Home Page</a></li>
              <li><a href="#">About Us</a></li>
              <li><a href="#">Services We Offer</a></li>
              <li><a href="#">Meet Our Doctors</a></li>
              <li><a href="#">Our Blog</a></li>
              <li><a href="#">Contact Us</a></li>
            </ul>
          </div> <!--/.span3 -->
        
          
          <div class="span12 copyright">
            
          </div><!--/.span12 -->
        </div><!--/.row-fluid -->
      </div><!--/.container -->
    </footer>
    <!-- End Footer -->
    
    <!-- Javascript Placed at the end of the document so the pages load faster -->
    
    <!-- Twitter Bootstrap -->
    <script src="js/bootstrap/bootstrap.js"></script>

  </body>
</html>


