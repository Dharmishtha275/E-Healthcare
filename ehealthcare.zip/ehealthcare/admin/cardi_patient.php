<html>
<body>
<div align="left">
<?php
$conn=mysql_connect("localhost","root","");
mysql_select_db("ehealthcare",$conn);
      
   $id=$_GET['id'];
   $select= "SELECT * FROM priscription where s_id='$id'";
   $query4= mysql_query($select);
    while($row=mysql_fetch_assoc($query4))
   {
	    echo "<div align='center' style='color:purple; font-size:30px'>";
		echo "Details Of ".$row['fname'];
		echo "</div>"."<br></br></br>"; 
		echo "<div style='text-align=left;color:teal; padding-left:250px'>";
		echo "Id  ::"."  ".$row['id']."</br></br>";
        echo "Name  ::"."  ".$row['fname']." ".$row['sname']." ".$row['lname']."</br></br>";
		echo "Gender  ::"."  ".$row['gender']."</br></br>";
		echo "Blood Group  ::" ."  ".$row['bloodgroup']."</br></br>";
		echo "Phoneno ::"."  ".$row['phoneno']."</br></br>";
		echo "Age ::"."  ".$row['age']."</br></br>";
		echo "Email  ::"."  ".$row['email']."</br></br>";
		echo "Drug Name  ::"."  ".$row['drugname']."</br></br>";
		echo "Dosage  ::"."  ".$row['dosage']."</br></br>";
		echo "Medical Alart ::"."  ".$row['Medicalalarts']."</br></br>";
		echo "Prescribing Doctor ::"."  ".$row['priscribingdoctor']."</br></br>";
		echo " <div style='padding-left:70px'>";
		echo "<input type='submit' onclick='window.print()' name='print' value='print'/>"."</div>";
		echo "</div>";
		
	    	 
   }
   
?>
</div>
</body>
<html>