<?php
$conn=mysql_connect("localhost","root","");
mysql_select_db("ehealthcare",$conn);
$id=$_GET['id'];
if($_SERVER['REQUEST_METHOD'] == "POST"){
$name=$_POST['name'];
$skills=$_POST['skills'];
$address=$_POST['address'];
$city=$_POST['city'];
$phoneno=$_POST['phoneno'];
$appointment=$_POST['appointment'];
$insert="INSERT INTO doctor1(id,name,skills,address,city,phoneno,appointment) VALUES ('$id','$name','$skills','$address','$city','$phoneno','$appointment')";
$query=mysql_query($insert,$conn);
 if($query){
 $json = array("status" => 1, "msg" => "Done User added!");
 }else{
 $json = array("status" => 0, "msg" => "Error adding user!");
 }
 }
else{
 $json = array("status" => 0, "msg" => "Request method not accepted");
}
mysql_close($conn);
header("location:doctor1.php");
header('Content-type: application/json');
echo json_encode($json);

?>


