<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<script type="text/javascript">
    function validation()
{ 
   var patient=document.htr.patient.value;
   var id=document.htr.id.value;
   var address=document.htr.address.value;
   var city=document.htr.city.value;
   var phoneno=document.htr.phoneno.value;
   var msg='';
   var error='';
    
     if(patient == '')
   {
	     error="<b style='color:red'><i> Please Enter Patient Name</i></b></br>";
         msg+=error;
   }
    
     if(id == '')
   {
	     error="<b style='color:red'><i>Please Enter Patientid</i></b></br>";
         msg+=error;
   }
   if(address == '')
   {
		 error="<b style='color:red'><i>Please Enter Address</i></b></br>";
         msg+=error;
 
   }
    
     if(city == '')
   {
	     error="<b style='color:red'><i>Please Enter City</i></b></br>";
         msg+=error;
   }
   
     if(phoneno == '')
   {
	     error="<b style='color:red'><i>Please Enter Phoneno</i></b></br>";
         msg+=error;
   }
   if(msg !='')
   {
	    document.getElementById("error_div").innerHTML = msg;
		return false;
   }
}
</script>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<?php
 
   $conn=mysql_connect("localhost","root","");
   mysql_select_db("ehealthcare",$conn);
   $id=$_GET['id'];
   $select= "SELECT * FROM register where id=".$id;
   $query= mysql_query($select,$conn);
   while($row=mysql_fetch_assoc($query))
   {
   
?>
<br><br><br>
<form id="tform" name="htr" action="patientupdate.php?id=<?php echo $row['id']; ?>" method="POST" onsubmit="return validation()">
<div id="error_div"></div>
<table align="center" border="2">
<h1 align="center">Edit form</h1>
<tr>
<td>Patient:</td>
<td><input type="text" name="patient" id="patient" value="<?php echo $row['patient']; ?>" /></td>
</tr>
<tr>
<td>Patientid:<sup style="color:#C30">*</sup></td>
<td><input type="text" name="id" id="id" value="<?php echo $row['id']; ?>" /></td>
</tr>
<tr>
<td>Address:<sup style="color:#C30">*</sup></td>
<td><textarea name="address" id="address" cols="5" rows="5" value="<?php echo $row['address']; ?>" /></textarea></td>
</tr>
<tr>
<td>City:<sup style="color:#C30">*</sup></td>
<td><select name="city" id="city" value="<?php echo $row['city']; ?>" /></select></td>
</tr>
<tr>
<td>Gender:<sup style="color:#C30">*</sup></td>
<td><input type="radio" name="gender" id="gender" value="<?php echo $row['gender']; ?>"></textarea></td>
</tr>
<tr>
<td>Phoneno:<sup style="color:#C30">*</sup></td>
<td><select name="phoneno" id="phoneno" value="<?php echo $row['phoneno']; ?>" /></td>
</tr>
<input type="submit" name="submit" value="edit">
</td>
</table>
</form>
<?php
   }
?>

 
</body>
</html>