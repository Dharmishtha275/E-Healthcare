<?php
  if(isset($_SESSION['password']) && (time() - $_SESSION['password']>200))
  {

    session_unset();
	session_destroy();
		 }
  $_session['LAST_ACTIVITY']=time();
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<!-- Basic meta tags -->


    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- CSS styles -->
	
    <link href="css/style.css" rel="stylesheet">
      
    <!-- Google Web font 'PT Sans and Yanone Kaffeesatz' -->  
    <link href='http://fonts.googleapis.com/css?family=PT+Sans+Narrow|Yanone+Kaffeesatz:400,300,700' rel='stylesheet' type='text/css'>
     
    <!-- Jquery Library -->
    <script src="js/jquery-1.7.1.min.js"></script>
    
    <!-- for IE6-8 support of HTML5 elements & Seperate CSS for ie-8-7 -->
    <!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
      <link href="css/ie8-7.css" rel="stylesheet">
    <![endif]-->
  </head>

  <body>
    <!-- Header -->
    <header>
      <div class="container">
        <div class="row-fluid">
	  <!-- logo -->
          <div class="span6 logo">
            <a href="index.php"><img src="img/plo.jpg" /></a>
          </div>
	  <!-- End Logo -->
          
          <!-- Social menu -->
	  <div class="span6" id="social">
            <ul class="social">
              <li class="twitter">
		<a target="_blank" href="#">&nbsp;</a>
              </li>
	      <li class="facebook">
		<a target="_blank" href="#">&nbsp;</a>
	      </li>
            </ul>
          </div>
          <!-- End Social Menu -->
          
          
        </div> <!--/.row-fluid -->
      </div> <!--/.container -->
    </header>
    <!-- End Header -->
    
    <!-- Section Top -->
    <section id="top">
      <div class="container">
	<!-- Main Menu -->
        <div class="navbar">
          <div class="navbar-inner">
            <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
	      Main Menu
            </a><!--/.nav-collapse -->
            <div class="nav-collapse">
              <ul class="nav">
                              
                <!--                 <li class="dropdown">
                  <a href="doctorlogin.php">DoctorAdmin</a></li>

              -->
                 <li class="dropdown">
                  <a href="dentist.php">Dentist</a></li>
                  
                <li class="dropdown">
                  <a  href="physiotherapist.php">Physiotherapist</a></li>
                 <li class="dropdown">
                  <a  href="cardiologist.php">cardiologist</a></li>

                <li class="dropdown">
		       <a href="eye-Specialist.php">Eye-Specialist</a></li>
               
                <li class="dropdown">
                  <a href="Priscription.php">Priscription</a></li>
                  
                <li class="dropdown">
                  <a href="bills.php">Bill</a></li>
                
          
              
               
               
              </ul>
            </div>
          </div>
          </div> 
          <!--/.navbar-inner -->
        </div> <!--/.navbar -->
        <!-- End Main Menu -->
	
      </div> <!--/.container -->
    </section> <!--/#top --> 
    <!--  End Section Top -->
    
    <!-- Section Breadcrumbs-->
    <section id="breadcrumb">
      <div class="b-c">
	<div class="container">
	  <ul class="breadcrumb">
	  </ul>
	</div> <!--/.container -->
      </div> <!--/.b-c -->
    </section> 

<?php
if(isset($_POST['submit']))
{
$conn=mysql_connect("localhost","root","");
mysql_select_db("ehealthcare",$conn);
$date=$_POST['date'];
$Firstname=$_POST['pname'];
$addr=$_POST['addr'];
$phoneno=$_POST['Phoneno'];
$med_name=$_POST['med_name'];
$quan=$_POST['qty'];
$price=$_POST['price'];
$discount=$_POST['disc'];
$total=$_POST['total'];

$insert="INSERT INTO bill(bill_date,patient_name,addr,cont_no,med_name,quantity,price,discount,total) VALUES ('$date','$Firstname','$addr','$phoneno','$med_name','$quan','$price','$discount','$total')";
$query=mysql_query($insert,$conn);
if($query)
{
	header("Location:bills.php");
}
else
{
	echo "<script>priscription not submit</script>";
}

}
?>
</head>


<body>

<form action="search_bill.php">
<table align="right">
<td><input type="submit" class="btn-green" name="search" value="Click here to print bill"></td>
</table>

</form>


<form name="htr" id="htr" method="post" onSubmit="return validation()" >

<table>
<h1 align="center"><i>Enter Bill Entry</i></h1>
<tr>
<td >Date:</td>
<td><input type="date" name="date" /><br/><br/></td>
<tr>
<td >Patient Name:</td>
<td><input type="text" name="pname" /><br/><br/></td>
</tr>
<tr>
<td>Address:</td>
<td><input type="text" name="addr"  /><br/><br/></td>
</tr>
<tr>
<td>Phone No:</td>
<td><input type="text" name="Phoneno" id="pno"  /><br/><br/></td>
</tr>
<tr>
<td>Medicine Name:</td>
<td><input type="text" name="med_name" /><br/><br/></td>
</tr>
<tr>
<td>Quantity:</td>
<td><input type="number" name="qty"  /><br/><br/></td>
</tr>
<tr>
<td>Price:</td>
<td><input type="number" name="price" max="10000" min="20"  /><br/><br/></td>
</tr>

<tr>
<td>Discount:</td>
<td><input type="text" name="disc" /><br/><br/></td>
</tr>
<tr>
<td>Total:</td>
<td><input type="text" name="total" /><br/><br/></td>
</tr>
<tr>
<td><input type="submit" class="btn-green" name="submit" id="submit" value="submit"  />
</td>

</tr>
</table>
</form>
<!--<div>

 <form action="view_prec.php" method="POST" name="frm2">
 <input type="submit" class="btn-green" name="print" value="print" id="print"/>
 
 </form>
</div> -->

    <div class="span12 copyright">
         
          </div><!--/.span12 -->
        </div><!--/.row-fluid -->
      </div><!--/.container -->
    </footer>
    <!-- End Footer -->
    
    <!-- Javascript Placed at the end of the document so the pages load faster -->
    
    <!-- Twitter Bootstrap -->
    <script src="js/bootstrap/bootstrap.js"></script>
    
    <!-- Form Validation -->
    <script src="js/validate/jquery.validationEngine.js"></script>
    <script>
      jQuery(document).ready(function(){
	// binds form submission and fields to the validation engine
      	jQuery("#formID").validationEngine();
      });
    </script>
    
    <!-- Elastislide -->
    <script type="text/javascript" src="js/jquery.elastislide.js"></script>
    <script type="text/javascript">
		$('#carousel').elastislide({
			  imageW 	: 180,
			  minItems	: 5
		});	
    </script>

  </body>
</html>

