<?php
$conn=mysql_connect("localhost","root","");
if($conn)
{
	echo"sucessfully";
}
mysql_select_db("ehealthcare",$conn);
$id=$_GET['id'];
$delete="DELETE FROM patient WHERE id='".$id."'";
$query=mysql_query($delete);
header("location:cardi_patient.php");
?>