<?php
$conn=mysql_connect("localhost","root","");
{
	echo"sucessfully";
}
mysql_select_db("ehealthcare",$conn);
$id=$_GET['id'];
$name=$_POST['name'];
$skills=$_POST['skills'];
$address=$_POST['address'];
$city=$_POST['city'];
$phoneno=$_POST['phoneno'];
$appointment=$_POST['appointment'];

$update="UPDATE doctor1 SET name='".$name."',skills='".$skills."',address='".$address."',city='".$city."',phoneno='".$phoneno."',appointment='".$appointment."' WHERE id='".$id."'";
$query=mysql_query($update);
header("location:doctor1.php");
?>
