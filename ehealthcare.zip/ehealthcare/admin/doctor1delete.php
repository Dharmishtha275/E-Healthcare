<?php
$conn=mysql_connect("localhost","root","");
if($conn)
{
	echo"sucessfully";
}
mysql_select_db("ehealthcare",$conn);
$id=$_GET['id'];
$name=$_POST['name'];
$skills=$_POST['skills'];
$address=$_POST['address'];
$city=$_POST['city'];
$phoneno=$_POST['phoneno'];
$appointment=$_POST['appointment'];
$delete="DELETE FROM doctor1 WHERE id='".$id."'";
$query=mysql_query($delete);
header("location:doctor1.php");
?>

