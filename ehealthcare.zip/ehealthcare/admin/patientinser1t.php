<?php
$conn=mysql_connect("localhost","root","");
mysql_select_db("ehealthcare",$conn);
$id=$_GET['id'];
$patient=$_POST['patient'];
$address=$_POST['address'];
$city=$_POST['city'];
$gender=$_POST['gender'];
$phoneno=$_POST['phoneno'];
$age=$_POST['age'];
$discription=$_POST['discription'];
$insert="INSERT INTO patient(id,patient,address,city,gender,phoneno,age,discription) VALUES ('$id','$patient','$address','$city','$gender','$phoneno','$age','$discription')";
$query=mysql_query($insert,$conn);
header("location:patient.php");
?>