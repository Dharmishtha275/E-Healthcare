<?php
$conn=mysql_connect("localhost","root","");
if($conn)
{
	echo"sucessfully";
}
mysql_select_db("ehealthcare",$conn);

$id=$_POST['id'];
$patient=$_POST['patient'];
$address=$_POST['address'];
$gender=$_POST['gender'];
$BloodGroup=$_POST['BloodGroup'];
$Specialist=$_POST['Specialist'];
$Phoneno=$_POST['phoneno'];
$age=$_POST['age'];
$email=$_POST['email'];
$password=$_POST['password'];
$update="UPDATE patient SET id='".$id."', patient='".$patient."',address='".$address."',gender='".$gender."',BloodGroup='".$BloodGroup."',Specialist='".$Specialist."',phoneno='".$Phoneno."',age='".$age."',email='".$email."',password='".$password."' WHERE id='".$id."'";
$query=mysql_query($update);
header("location:patient.php");
?>