<?php
$conn=mysql_connect("localhost","root","");
mysql_select_db("ehealthcare",$conn);
$username=$_POST['username'];
$password=$_POST['password'];
$insert="INSERT INTO doctlogin(Username,Password) VALUES ('$username','$password')";
$query=mysql_query($insert,$conn);
?>