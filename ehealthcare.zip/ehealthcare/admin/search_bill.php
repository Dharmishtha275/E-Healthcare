<?php
  if(isset($_SESSION['password']) && (time() - $_SESSION['password']>200))
  {

    session_unset();
	session_destroy();
		 }
  $_session['LAST_ACTIVITY']=time();
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<!-- Basic meta tags -->


    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- CSS styles -->
	
    <link href="css/style.css" rel="stylesheet">
      
    <!-- Google Web font 'PT Sans and Yanone Kaffeesatz' -->  
    <link href='http://fonts.googleapis.com/css?family=PT+Sans+Narrow|Yanone+Kaffeesatz:400,300,700' rel='stylesheet' type='text/css'>
     
    <!-- Jquery Library -->
    <script src="js/jquery-1.7.1.min.js"></script>
    
    <!-- for IE6-8 support of HTML5 elements & Seperate CSS for ie-8-7 -->
    <!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
      <link href="css/ie8-7.css" rel="stylesheet">
    <![endif]-->
  </head>

  <body>
    <!-- Header -->
    <header>
      <div class="container">
        <div class="row-fluid">
	  <!-- logo -->
          <div class="span6 logo">
            <a href="index.php"><img src="img/plo.jpg" /></a>
          </div>
	  <!-- End Logo -->
          
          <!-- Social menu -->
	  <div class="span6" id="social">
            <ul class="social">
              <li class="twitter">
		<a target="_blank" href="#">&nbsp;</a>
              </li>
	      <li class="facebook">
		<a target="_blank" href="#">&nbsp;</a>
	      </li>
            </ul>
          </div>
          <!-- End Social Menu -->
          
          
        </div> <!--/.row-fluid -->
      </div> <!--/.container -->
    </header>
    <!-- End Header -->
    
    <!-- Section Top -->
    <section id="top">
      <div class="container">
	<!-- Main Menu -->
        <div class="navbar">
          <div class="navbar-inner">
            <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
	      Main Menu
            </a><!--/.nav-collapse -->
            <div class="nav-collapse">
              <ul class="nav">
                              
                <!--                 <li class="dropdown">
                  <a href="doctorlogin.php">DoctorAdmin</a></li>

              -->
                 <li class="dropdown">
                  <a href="dentist.php">Dentist</a></li>
                  
                <li class="dropdown">
                  <a  href="physiotherapist.php">Physiotherapist</a></li>
                 <li class="dropdown">
                  <a  href="cardiologist.php">cardiologist</a></li>

                <li class="dropdown">
		       <a href="eye-Specialist.php">Eye-Specialist</a></li>
               
                <li class="dropdown">
                  <a href="Priscription.php">Priscription</a></li>
                  
                <li class="dropdown">
                  <a href="bills.php">Bill</a></li>
                
          
              
               
               
              </ul>
            </div>
          </div>
          </div> 
          <!--/.navbar-inner -->
        </div> <!--/.navbar -->
        <!-- End Main Menu -->
	
      </div> <!--/.container -->
    </section> <!--/#top --> 
    <!--  End Section Top -->
    
    <!-- Section Breadcrumbs-->
    <section id="breadcrumb">
      <div class="b-c">
	<div class="container">
	  <ul class="breadcrumb">
	  </ul>
	</div> <!--/.container -->
      </div> <!--/.b-c -->
    </section>
    </head>
    <body>
    <div align="center">
    <form action="<?php $_PHP_SELF?>" method="POST">
    <b>search for printing bill using name::</b>
    <input type="text" name="searchfor" size="20">
 <input type="submit" value="Find" name="Find">
    </form>
    </div>
    <div align="center">
    <?php
    $conn=mysql_connect("localhost","root","");
mysql_select_db("ehealthcare",$conn);
if(isset($_POST['Find']))
{
	$pname=$_POST['searchfor'];
	$select="select * from bill where patient_name LIKE '%$pname%'";
	$query=mysql_query($select);
	$i=0;
	if(mysql_num_rows($query))
	{
		echo "<table border='1'> 
		<tr>
		<th>date</th>
		<th>Patient Name</th>
		<th>Address</th>
		<th>Contact Number</th>
		<th>Medicine Name</th>
		<th>Quantity</th>
		<th>Price</th>
		<th>Discount</th>
		<th>Total</th>
		<th>Click here to print bill</th>
		</tr>";
}
while($row=mysql_fetch_array($query))
{
	echo '<tr>';
	//echo '<td>'.$row['bill_id'].'</td>';
	echo '<td>'.$row['bill_date'].'</td>';
	echo '<td>'.$row['patient_name'].'</td>';
	echo '<td>'.$row['addr'].'</td>';
	echo '<td>'.$row['cont_no'].'</td>';
	echo '<td>'.$row['med_name'].'</td>';
	echo '<td>'.$row['quantity'].'</td>';
	echo '<td>'.$row['price'].'</td>';
	echo '<td>'.$row['discount'].'</td>';
	echo '<td>'.$row['total'].'</td>';
	echo "<td><a href='print_bill.php?bill_id=".$row['bill_id']."'>print</a></td></tr>";
	$i++;
}
echo "</table>";

}
else
{
	echo "No matching found";
	}
?>
    </div>
    </body>
    </html>