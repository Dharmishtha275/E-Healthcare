<?php
  if(isset($_SESSION['password']) && (time() - $_SESSION['password']>200))
  {

    session_unset();
	session_destroy();
		 }
  $_session['LAST_ACTIVITY']=time();
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<!-- Basic meta tags -->


    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content=""> -

    <!-- CSS styles -->
	
    <link href="css/style.css" rel="stylesheet">
      
    <!-- Google Web font 'PT Sans and Yanone Kaffeesatz' -->  
    <link href='http://fonts.googleapis.com/css?family=PT+Sans+Narrow|Yanone+Kaffeesatz:400,300,700' rel='stylesheet' type='text/css'>
     
    <!-- Jquery Library -->
    <script src="js/jquery-1.7.1.min.js"></script>
    
    <!-- for IE6-8 support of HTML5 elements & Seperate CSS for ie-8-7 -->
    <!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
      <link href="css/ie8-7.css" rel="stylesheet">
    <![endif]-->
  </head>

  
  <body>
   <?php
$conn=mysql_connect("localhost","root","");
mysql_select_db("ehealthcare",$conn);
if(isset($_POST['submit']))
{
$patient=$_POST['username'];
$psd=$_POST['password'];
$res=mysql_query("select * from admin where Username='dentist' and Password='$psd'") or die(mysql_error());

if(mysql_num_rows($res)>0)
{
  header("location:admin_dentist.php");
}
else
{
  echo "<script>alert('invalid username or Password')</script>";
}
}

?>
    <!-- Header -->
    <header>
      <div class="container">
        <div class="row-fluid">
	  <!-- logo -->
          <div class="span6 logo">
            <a href="index.php"><img src="img/plo.jpg" /></a>
          </div>
	  <!-- End Logo -->
          
          <!-- Social menu -->
	  <div class="span6" id="social">
            <ul class="social">
              <li class="twitter">
		<a target="_blank" href="#">&nbsp;</a>
              </li>
	      <li class="facebook">
		<a target="_blank" href="#">&nbsp;</a>
	      </li>
            </ul>
          </div>
          <!-- End Social Menu -->
          
          
        </div> <!--/.row-fluid -->
      </div> <!--/.container -->
    </header>
    <!-- End Header -->
    
    <!-- Section Top -->
    <section id="top">
      <div class="container">
	<!-- Main Menu -->
        <div class="navbar">
          <div class="navbar-inner">
            <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
	      Main Menu
            </a><!--/.nav-collapse -->
            <div class="nav-collapse">
              <ul class="nav">
                              
                <!--                 <li class="dropdown">
                  <a href="doctorlogin.php">DoctorAdmin</a></li>

              -->
                 <li class="dropdown">
                  <a href="dentist.php">Dentist</a></li>
                  
                <li class="dropdown">
                  <a  href="Physiotherapist.php">Physiotherapist</a></li>
                 <li class="dropdown">
                  <a  href="cardiologist.php">cardiologist</a></li>

                <li class="dropdown">
		       <a href="eye-Specialist.php">Eye-Specialist</a></li>
          
                <li class="dropdown">
                  <a href="Priscription.php">Prescription</a></li>
                  
                <li class="dropdown">
                  <a href="bills.php">Bill</a></li>
                
               
               
              </ul>
            </div>
          </div>
          </div> 
          <!--/.navbar-inner -->
        </div> <!--/.navbar -->
        <!-- End Main Menu -->
	
      </div> <!--/.container -->
    </section> <!--/#top --> 
    <!--  End Section Top -->
    
    <!-- Section Breadcrumbs-->
    <section id="breadcrumb">
      <div class="b-c">
	<div class="container">
	  <ul class="breadcrumb">
	  </ul>
	</div> <!--/.container -->
      </div> <!--/.b-c -->
    </section> <!--#breadcrumb -->
    <!-- End Section Breadcrumb -->
    
    
    

 <form name="def" id="def"  method="post" onsubmit="return validation()"style="background-image:url(img/gallery/5.jpg) ;background-position:center; background-repeat:repeat-x; background-size:cover">

 <br />
 <br />
         <h1 align="center"><font face="Georgia, Times New Roman, Times, serif"><i>Dentist login</i></font></h1>
         <font size="+2" face="Times New Roman, Times, serif">username</font>
         <input type="text" name="username" id="username" placeholder="username" /><br /><br />
         <font size="+2" face="Times New Roman, Times, serif">password</font>
         <input type="password" name="password" id="password" placeholder="password" /><br /><br />
         <input type="submit"  class="btn-green" name="submit" id="submit" value="login" /> </h1>
          </form><br /><br /><br /><br /><br />
          
           <!-- Footer -->
    <footer style="padding-top:110px;">
      <div class="container">
        
          
          
        
          
          <div class="span12 copyright">
         
          </div><!--/.span12 -->
        </div><!--/.row-fluid -->
      </div><!--/.container -->
    </footer>
    <!-- End Footer -->
    
    <!-- Javascript Placed at the end of the document so the pages load faster -->
    
    <!-- Twitter Bootstrap -->
    <script src="js/bootstrap/bootstrap.js"></script>
    
    <!-- Form Validation -->
    <script src="js/validate/jquery.validationEngine.js"></script>
    <script>
      jQuery(document).ready(function(){
	// binds form submission and fields to the validation engine
      	jQuery("#formID").validationEngine();
      });
    </script>
    
    <!-- Elastislide -->
    <script type="text/javascript" src="js/jquery.elastislide.js"></script>
    <script type="text/javascript">
		$('#carousel').elastislide({
			  imageW 	: 180,
			  minItems	: 5
		});	
    </script>

  </body>
</html>

         
