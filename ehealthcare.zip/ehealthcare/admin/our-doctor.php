<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
  <head>
    <!-- Basic meta tags -->
   
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Medical Pro - Bootstrap Responsive Template</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- CSS styles -->
    <link href="css/style.css" rel="stylesheet">
      
    <!-- Google Web font 'PT Sans and Yanone Kaffeesatz' -->  
    <link href='http://fonts.googleapis.com/css?family=PT+Sans+Narrow|Yanone+Kaffeesatz:400,300,700' rel='stylesheet' type='text/css'>
     
    <!-- Jquery Library -->
    <script src="js/jquery-1.7.1.min.js"></script>
    
    <!-- for IE6-8 support of HTML5 elements & Seperate CSS for ie-8-7 -->
    <!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
      <link href="css/ie8-7.css" rel="stylesheet">
    <![endif]-->
    
  </head>

  <body>
    <!-- Header -->
    <header>
      <div class="container">
        <div class="row-fluid">
	  <!-- logo -->
          <div class="span6 logo">
            <a href="index.html"><img src="img/plo.jpg" alt="" /></a>
          </div>
	  <!-- End Logo -->
          
          <!-- Social menu -->
	  <div class="span6" id="social">
            <ul class="social">
              <li class="twitter">
		<a target="_blank" href="#">&nbsp;</a>
              
	      <li class="facebook">
		<a target="_blank" href="#">&nbsp;</a>
	      </li>
            </ul>
          </div>
          <!-- End Social Menu -->
        </div> <!--/.row-fluid -->
      </div> <!--/.container -->
    </header>
    <!-- End Header -->
    
    <!-- Section Top -->
    <section id="top">
      <div class="container">
	<!-- Main Menu -->
        <div class="navbar">
          <div class="navbar-inner">
            <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
	      

             	      
              	      Main Menu
            </a>
            <div class="nav-collapse">
              <ul class="nav">
                              <li><a href="our-doctor.php">Our-doctors</a></li>
                              
                                                            
                                               

                                  <li class="dropdown">

                <li><a href="patient.php">Patient-detail</a></li>
                
                 <li class="dropdown">
                  <a href="service.php">services</a></li>
                  
                
                  
                <li class="dropdown">
		  <a href="index.php">Logout</a></li>
                           </ul>
                
              </ul>
            </div> <!--/.nav-collapse -->
          </div> <!--/.navbar-inner o-->
        </div> <!--/.navbar -->
        <!-- End Main Menu -->
	
      </div> <!--/.container -->
    </section> <!--/#top --> 
    <!--  End Section Top -->
    
    <!-- Section Breadcrumbs-->
    <section id="breadcrumb">
      <div class="b-c">
	<div class="container">
	  <ul class="breadcrumb">
	   
	  </ul>
	</div> <!--/.container -->
      </div> <!--/.b-c -->
    </section> <!--#breadcrumb -->
    <!-- End Section Breadcrumb -->
    <br /><br />
    
    <!-- Section content -->
    <section id="content" class="doctors">
      <div class="container">
        <div class="row-fluid">
	  <div class="span3">
	    <div class="page clearfix">
	      <img src="img/carousel/1.jpg" alt="" />
	      <h4>Mrs. Melisa Arguelles</h4>
	      <p>Mrs. Melisa Arguelles is MD-ophthalmology, she has 42 years Experience in ophthalomlogy address-Lajpatnagar Delhi
          Timing 8AM TO 2PM,6PM TO 7PM ..</p>
	    </div>
	  </div>
	  
	  <div class="span3">
	    <div class="page clearfix">
	      <img src="img/carousel/2.jpg" alt="" />
	      <h4>Mrs. Alejandra Fenster</h4>
	      <p>Mrs. Alejandra Fenstar is BDS,MDS-orthodontics she has 10 years Experience she is a Dentist savani dental and orthodontics Athwaline surat Timing  9:30AM TO 1:30PM</p>
	    </div>
	  </div>
	  
	  <div class="span3">
	    <div class="page clearfix">
	      <img src="img/carousel/3.jpg" alt="" />
	      <h4>Mrs. Clare Gehlert</h4>
	      <p>Mrs. Clare Gehlert is FRCS,MD-ophthalmology she has 16 years Experience in ophthalmology address Foresight Eyeclinic 
          Timing every day 9AM TO 3PM </p>
	    </div>
	  </div>
	  
	  <div class="span3">
	    <div class="page clearfix">
	      <img src="img/carousel/4.jpg" alt="" />
	      <h4>Mrs. Darcy Hersman</h4>
	      <p>Mrs. Darcy Hersman is an indian american author and Public speaker. she is an alternative Medicine advocate .and a pramoter of popular forms of spirituality.</p>
	    </div>
	  </div>
	  
	  <div class="span3">
	    <div class="page clearfix">
	      <img src="img/carousel/5.jpg" alt="" />
	      <h4>Mrs. Jami Redington</h4>
	      <p>Mrs. Jami Redington is wellknow for her contribusion to unani medicine he Founded IDN sina Academemy  of Medieval madicine and science in 2000. Timing 9AM TO 5PM in Every day</p>
	    </div>
	  </div>
	  
	  <div class="span3">
	    <div class="page clearfix">
	      <img src="img/carousel/6.jpg" alt="" />
	      <h4>Mrs. Tanisha Enterline</h4>
	      <p>Mrs. Tanisha Enterline is a faculty member in the decipline of pharmacology and chair of the advisory concil, international association of Medical Colleges. Timing Sunday 7AM TO 12PM</p>
	    </div>
	  </div>
	  
	  <div class="span3">
	    <div class="page clearfix">
	      <img src="img/carousel/7.jpg" alt="" />
	      <h4>Mrs. Edwina Lukowski</h4>
	      <p>Mrs. Edwina Lukowski is a leading heart surgeon who has pioneered new Treatments, founded new Hospitals earned an international repupation. Timing Everyday 9AM TO 12PM  </p>
	    </div>
	  </div>
	  
	  <div class="span3">
	    <div class="page clearfix">
	      <img src="img/carousel/11.jpg" alt="" />
	      <h4>Mrs. Margery Berti</h4>
	      <p>Mrs. Margery Berti is DOMS,MBBS,FMRF she has 12 years Experience in Authonilogist Doctor pattnaik's lasereye Institute Lajpatnagar Delhi Monday to Saturday 8AM TO 7 PM. </p>
	    </div>
	  </div>
	  
	    </div>
	  </div>
        </div> <!--/.row-fluid -->
      </div> <!--/.Container -->
    </section> <!--#content -->
    <!-- End Section content-->
    
    <!-- Footer -->
    <footer>
      <div class="container">
        <div class="row-fluid">
          <div class="span3">
            <ul class="nav nav-list">
              <li class="nav-header">Contact Us</li>
              <li><span class="label label-inverse">Telephone</span></li>
              <li><span class="label label-inverse">Fax</span> </li>
              <li><span class="label label-inverse">Mobile</span> </li>
              <li><span class="label label-inverse">Email</span> </li>
              <li><span class="label label-inverse">Location</span></li>
            </ul>
          </div> <!--/.span3 -->

          <div class="span3">
           <ul class="nav nav-list">
              <li class="nav-header">WEBSITE NAVIGATION</li>
              <li><a href="#">Home Page</a></li>
              <li><a href="#">About Us</a></li>
              <li><a href="#">Services We Offer</a></li>
              <li><a href="#">Meet Our Doctors</a></li>
              <li><a href="#">Our Blog</a></li>
              <li><a href="#">Contact Us</a></li>
            </ul>
          </div> <!--/.span3 -->
        
          
          <div class="span12 copyright">
            
          </div><!--/.span12 -->
        </div><!--/.row-fluid -->
      </div><!--/.container -->
    </footer>
    <!-- End Footer -->
    
    <!-- Javascript Placed at the end of the document so the pages load faster -->
    
    <!-- Twitter Bootstrap -->
    <script src="js/bootstrap/bootstrap.js"></script>

  </body>
</html>

