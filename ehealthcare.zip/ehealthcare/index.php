s<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
  <head>
    <!-- Basic meta tags -->
   
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- CSS styles -->
    <link href="css/validationengine.css" rel="stylesheet">
    <link href="css/style.css" rel="stylesheet">
    
    <!-- Google Web font 'PT Sans and Yanone Kaffeesatz' -->  
    <link href='http://fonts.googleapis.com/css?family=PT+Sans+Narrow|Yanone+Kaffeesatz:400,300,700' rel='stylesheet' type='text/css'>
     
    <!-- Jquery Library -->
    <script src="js/jquery-1.7.1.min.js"></script>
    
    <!-- for IE6-8 support of HTML5 elements & Seperate CSS for ie-8-7 -->
    <!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
      <link href="css/ie8-7.css" rel="stylesheet">
    <![endif]-->
    
  </head>

  <body>
    <!-- Header -->
    <header>
      <div class="container">
        <div class="row-fluid">
	  <!-- logo -->
          <div class="span6 logo">
            <a href="index.php"><img src="img/plo.jpg" /></a>
          </div>
	  <!-- End Logo -->
          
          <!-- Social menu -->
	  <div class="span6" id="social">
            <ul class="social">
              <li class="twitter">
		<a target="_blank" href="#">&nbsp;</a>
              </li>
	      <li class="facebook">
		<a target="_blank" href="#">&nbsp;</a>
	      </li>
            </ul>
          </div>
          <!-- End Social Menu -->
	  
        </div><!--/.row-fluid -->
      </div><!--/.container -->
    </header>
    <!-- End Header -->
    
    <!-- Section top -->
    <section id="top">
      <div class="container">
      	
		
        <!-- Main Menu -->
       <div class="navbar">
          <div class="navbar-inner">
            <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
	      Main Menu
            </a>
            <div class="nav-collapse">
              <ul class="nav">
                <li class="active"><a href="index.php">Home</a></li>
                
                <!--                 <li class="dropdown">
                  <a href="doctorlogin.php">DoctorAdmin</a></li>

              -->
                 <li class="dropdown">
                  <a href="userpatient.php">Registration</a></li>
                  
                <li class="dropdown">
                  <a  href="admin/specialist.php">Speclalist</a></li>
                 <li class="dropdown">
                  <a  href="medicine.php">Medicine</a></li>

                <li class="dropdown">
		       <a href="newabout.php">About us</a></li>
          
               <li><a href="contact-us.php">Contact Us</a></li>
               
               
              </ul>
            </div>
          </div>
        </div>
        <!-- End Main Menu -->
        
        <!-- Home page Carousel -->
        <div class="frame">
          <div id="myCarousel" class="carousel slide">
            <!-- Carousel items -->
            <div class="carousel-inner">
              <div class="active item"><img src="img/slider/1.png" alt="" />
                <div class="carousel-caption">
                </div>
              </div>
              <div class="item"><img src="img/slider/2.png"  alt="" /></div>
              <div class="item"><img src="img/slider/3.png"  alt="" /></div>
              <div class="item"><img src="img/slider/4.png"  alt="" /></div>
            </div><!--/.carousel-inner -->
  
            <!-- Carousel nav -->
            <a class="carousel-control left" href="#myCarousel" data-slide="prev"></a>
            <a class="carousel-control right" href="#myCarousel" data-slide="next"></a>
          </div><!--/#myCarousel -->
        </div><!--/.frame -->
        <!-- End Home page Carousel -->
        
      </div><!--/.container -->
    </section><!--/#top -->
    <!-- End Section top -->
    
    <section id="content">
      <div class="container">
        <div class="row-fluid">
          <div class="span12">
            <div class="marg-top-med page">
              <h3 class="tree">Welcome to E Healthcare </h3>
              <p>E-Health care system is the Treatments preventions of Disease, Illness, Injury and other physical,impairments in human beings.E-Health care is Hendled by Specialist Doctors To Care Them Patients Sencitively.This Service Provide Dentist, Eye-Specialist,Cardiologist,physiotherapist, nurses,Receptionist And other care providers.Hospitals,Clinic and Community Health Can be Very Differnt From to Other Work Environments.E-Healthcare Systems are Many Things You need to Know About Types of Hospital Systems,Patient care,Management,Staff E-Healthcare Providers Support For It...
              THANK YOU FOR VISIT..  </p>
            </div><!--/.marg-top-med .page -->
          </div><!--/.span12 -->
	</div><!--/.row-fluid -->  
	  
	<div class="row-fluid">
          <div class="span4">
            <div class="page">
              <h3 class="tree">What is E-Health? </h3>
              <span class="box-icon">
                <img src="img/box-icons/team.png" alt=""/>
              </span>
             <em></em> <img src="img/doctors.png" alt="" />
              <p>eHealth or e-health is short form  electronic health,and refers broadly to the use of Technology and Specially Electronic Communication within Healthcare Environments. </p>
            </div><!--/.page -->
          </div><!--/.span4 --> 
      
	  <div class="span4">
	    <div class="page">
	      <h3 class="tree">What We Offer?</h3>
	      <span class="box-icon">
		<img src="img/box-icons/offer.png" alt="" />
	      </span>
	      <p>Services Provided By This System Are:- .</p>
	      <ul class="ul-1">
		<li>Electronic Health Records</li>
		<li>Computrized Physician Order Entry</li>
        <li>Medical research using Grids</li>
        <li>m-Health and mhealth</li>
         <li>Clinical Decision Support</li>
		<li>Consumer health informatics</li>
		<li>Virtual healthcare teams</li>
        <li>Healthcare Information Systems</li>
        <li>Health Knowledge Managment</li>
        
        
        

	      </ul>
	    </div><!--/.page -->
	  </div><!--/.span4 -->
	
	  <div class="span4">
	    <div class="page dark">
	      <h3 class="snow">news</h3>
	      <span class="box-icon">
		<img src="img/box-icons/appontment.png" alt="" />
	      </span>
	      <marquee direction="up" behavior="alternate">Ehealthcare is provide all type of facilitys so you can treatment in the home and Provide the all Product in such as Himalaya cxream ,soap also all item Provided by the E-healthcare.and Provide all Technology and Latest Treatment.and the Special Diseases Reduce Heart Diseas in Women World Health Organization(WHO).Indian Healthcare to spend US $ 1.2 billion on IT,Future belongs to Trained Techniciains in Medical field:JP Nadda,Aster Healthcare to Boost Medical Tourism in India.Cancer Patient dont get Acess to Proper Surgery.UN Launch Strategy For Healthy Women,Children.</marquee>
	    </div><!--/.page dark -->
	  </div><!--/.span4 -->
	</div><!--/.row-fluid -->
      
       
	<!-- Doctors Carousel -->
        <div class="row-fluid">
          <div class="span12">
            <h3>Meet Our Nationally Known Doctors</h3>
            <div class="content">
	      <div id="carousel" class="es-carousel-wrapper">
		<div class="es-carousel">
		  <ul>
		    <li><a href="#"><img src="img/carousel/1.jpg" alt="image01" /></a></li>
		    <li><a href="#"><img src="img/carousel/2.jpg" alt="image02" /></a></li>
		    <li><a href="#"><img src="img/carousel/3.jpg" alt="image03" /></a></li>
		    <li><a href="#"><img src="img/carousel/4.jpg" alt="image04" /></a></li>
		    <li><a href="#"><img src="img/carousel/5.jpg" alt="image05" /></a></li>
		    <li><a href="#"><img src="img/carousel/6.jpg" alt="image06" /></a></li>
		    <li><a href="#"><img src="img/carousel/7.jpg" alt="image07" /></a></li>
		    <li><a href="#"><img src="img/carousel/8.jpg" alt="image08" /></a></li>
		    <li><a href="#"><img src="img/carousel/9.jpg" alt="image09" /></a></li>
		    <li><a href="#"><img src="img/carousel/10.jpg" alt="image10" /></a></li>
		    <li><a href="#"><img src="img/carousel/11.jpg" alt="image11" /></a></li>
		    <li><a href="#"><img src="img/carousel/12.jpg" alt="image12" /></a></li>
		    <li><a href="#"><img src="img/carousel/13.jpg" alt="image13" /></a></li>
		    <li><a href="#"><img src="img/carousel/14.jpg" alt="image14" /></a></li>
		    <li><a href="#"><img src="img/carousel/15.jpg" alt="image15" /></a></li>
                  </ul>
		</div><!--/.es-carousel -->
	      </div><!--#carousel -->
	    </div><!--/.content -->
          </div><!--./span12 -->
        </div><!--/.row-fluid -->
      </div><!--/.container -->
      <!-- End Doctors Carousel -->   
    
    </section>
    <!-- End Section content -->
    
    <!-- Footer -->
    <footer>
      <div class="container">
        <div class="row-fluid">
          <div class="span3">
            <ul class="nav nav-list">
              <li class="nav-header">Contact Us</li>
              <li><span class="label label-inverse">Mobile</span>7567270530</li>
              <li><span class="label label-inverse">Mobile</span>7048333781</li>
              <li><span class="label label-inverse">Email</span>yashcthakore@gmail.com</li>
             <li><span class="label label-inverse">Email</span>deepzumkhawala@gmail.com</li>

              
            </ul>
          </div><!--/.span3 -->

          <div class="span3">
           <ul class="nav nav-list">
              <li class="nav-header">WEBSITE NAVIGATION</li>
              <li><a href="patient.php">Patient</a></li>
              <li><a href="newabout.php">About us</a></li>
              <li><a href="contact-us.php">Contact Us</a></li>
            </ul>
          </div><!--/.span3 -->
        
         
          <div class="span12 copyright">
         
          </div><!--/.span12 -->
        </div><!--/.row-fluid -->
      </div><!--/.container -->
    </footer>
    <!-- End Footer -->
    
    <!-- Javascript Placed at the end of the document so the pages load faster -->
    
    <!-- Twitter Bootstrap -->
    <script src="js/bootstrap/bootstrap.js"></script>
    
    <!-- Form Validation -->
    <script src="js/validate/jquery.validationEngine.js"></script>
    <script>
      jQuery(document).ready(function(){
	// binds form submission and fields to the validation engine
      	jQuery("#formID").validationEngine();
      });
    </script>
    
    <!-- Elastislide -->
    <script type="text/javascript" src="js/jquery.elastislide.js"></script>
    <script type="text/javascript">
		$('#carousel').elastislide({
			  imageW 	: 180,
			  minItems	: 5
		});	
    </script>
    

  </body>
</html>
