<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<!-- Basic meta tags -->


    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- CSS styles -->
    <link href="css/style.css" rel="stylesheet">
      
    <!-- Google Web font 'PT Sans and Yanone Kaffeesatz' -->  
    <link href='http://fonts.googleapis.com/css?family=PT+Sans+Narrow|Yanone+Kaffeesatz:400,300,700' rel='stylesheet' type='text/css'>
     
    <!-- Jquery Library -->
    <!--<script src="js/jquery-1.7.1.min.js"></script>-->
    
    <!-- for IE6-8 support of HTML5 elements & Seperate CSS for ie-8-7 -->
    <!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
      <link href="css/ie8-7.css" rel="stylesheet">
    <![endif]-->
  <script type="text/javascript">
  
    function validation()
{ 
   var id=document.htr.id.value;
   var patient=document.htr.patient.value;
   var address=document.htr.address.value;
   var city=document.htr.city.value;
   var phoneno=document.htr.phoneno.value;
   var phone_no=/^[1-9]{1}[0-9]{9}$/;


   var msg='';
   var error='';
    
     if(id == '')
   {
	     error=alert("Please Enter Patientid");
         msg+=error;
   }
    
     if(patient == '')
   {
	     error=alert("Please Enter Patientname");
         msg+=error;
   }
   if(address == '')
   {
		 error=alert("Please Enter Address");
         msg+=error;
 
   }
    
     if(city == '')
   {
	     error=alert("Please Enter City");
         msg+=error;
   }
   
     if(phoneno == '')
   {
	     error=alert("Please Enter Phoneno");
         msg+=error;
   }
   
     else if(!phone_no.test(phoneno))
   {
	  error=alert("please enter 10 digit no");
       msg+=error;  
   }     
    

   if(msg !='')
   {
	  
		return false;
   }
}
</script>

    

  	  <!-- End Logo -->
            </head>
<body background="img/plo.jpg">
    <!-- Header -->
    <header>
      <div class="container">
        <div class="row-fluid">
	  <!-- logo -->
           <div class="span6 logo">
                <a href="index.php"> <img src="img/plo.jpg" /></a>
          </div>
          

          <!-- Social menu -->
	  <div class="span6" id="ocial">
            <ul class="social">
              <li class="twitter">
		<a target="_blank" href="#">&nbsp;</a>
              </li>
	      <li class="facebook">
		<a target="_blank" href="#">&nbsp;</a>
	      </li>
            </ul>
          </div>
          <!-- End Social Menu -->
        </div> <!--/.row-fluid -->
      </div> <!--/.container -->
    </header>
    <!-- End Header -->
    
    <!-- Section Top -->
    <section id="top">
      <div class="container">
	<!-- Main Menu -->
        <div class="navbar">
          <div class="navbar-inner">
            <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
	      
           Main Menu
            </a>       <div class="navbar">
          <div class="navbar-inner">
            <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
	      Main Menu
            </a>
            <div class="nav-collapse">
              <ul class="nav">
                <li class="active"><a href="index.php">Home</a></li>
                
                <!--                 <li class="dropdown">
                  <a href="doctorlogin.php">DoctorAdmin</a></li>

              -->
                <li class="dropdown">
                  <a href="userpatient.php">Registration</a></li>
                  
               
                <li class="dropdown">
                  <a  href="medicine.php">Medicine</a></li>

                <li class="dropdown">
		  <a href="newabout.php">About us</a></li>
          
               <li><a href="contact-us.php">Contact Us</a></li>
               
   
              </ul>
            </div>
          </div>
        </div>
          
             <!--/.nav-collapse -->
          </div> <!--/.navbar-inner -->
        </div> <!--/.navbar -->
        <!-- End Main Menu -->
	
      </div> <!--/.container -->
    </section> <!--/#top --> 
    <!--  End Section Top -->
    
    <!-- Section Breadcrumbs-->
    <section id="breadcrumb">
      <div class="b-c">
	<div class="container">
	  <ul class="breadcrumb">
	  </ul>
	</div> <!--/.container -->
      </div> <!--/.b-c -->
    </section> <!--#breadcrumb -->
    <!-- End Section Breadcrumb -->
    <br />
    <br />
<form name="htr" id="htr" action=" patientinser1t.php" method="post" onsubmit="return validation()" style="background-image:url(img/gallery/1.jpg) ;background-position:center; background-repeat:repeat-x; background-size:cover">

<table>
<h1 align="center"><font face="Times New Roman, Times, serif" size="+3"><i>Patient details</i></font></h1>
<tr> 
<td><font size="+1" face="Times New Roman, Times, serif">ID</font></td>
<td><input type="text" name="id" id="id" placeholder="Provide Patient id" required/></td>
</tr>
<tr> 
<td><font size="+1" face="Times New Roman, Times, serif">Firstname</font></td>
<td><input type="text" name="firstname" id="firstname" placeholder="firstname" required/></td>
<td><font size="+1" face="Times New Roman, Times, serif">Secondname</font></td>
<td><input type="text" name="secondname" id="secondname" placeholder="secondname" required /></td>
<td><font size="+1" face="Times New Roman, Times, serif">Lastname</font></td>
<td><input type="text" name="lastname" id="lastname" placeholder="lastname" required /></td>
</tr>


<tr>
<td><font face="Times New Roman, Times, serif" size="+1">Address</font></td>
<td><textarea name="address" id="address" cols="5" rows="5"></textarea></td>
</tr>

<tr>
<td><font face="Times New Roman, Times, serif" size="+1">Gender</font></td>
<td><input type="radio" name="gender" id="gender" value="Male" />Male</td>
<td><input type="radio" name="gender" id="gender" value="Female" />Female</td>
</tr><br />
<td><font face="Times New Roman, Times, serif" size="+1">Blood Group</font></td>
<td>
<select name="BloodGroup" id="BloodGroup" required>
<option n>A+</option>
<option>A-</option>
<option>B+</option>
<option>B-</option>
<option>AB+</option>
<option>AB-</option>
<option>o+</option>
<option>o-</option>
</select>
</td>
</tr>

<td><font face="Times New Roman, Times, serif" size="+1">Specialist</font></td>
<td>
<select name="Specialist" id="Specialist" required>
<option n>Dentist</option>
<option>Physiotherapist</option>
<option>Cardiologist</option>
<option>Eye-Specialist</option>
</select>
</td>
</tr>

<tr>
<td><font face="Times New Roman, Times, serif" size="+1">Phoneno</font></td>
<td><input type="text" name="phoneno" id="phoneno" placeholder="phoneno" /></td>
</tr>
<tr>
<td><font face="Times New Roman, Times, serif" size="+1">Age</font></td>
<td><input type="text" name="age" id="age" placeholder="age" /></td>
</tr>
<tr>
<td><font size="+1" face="Times New Roman, Times, serif">Email</font></td>
<td><input type="email" name="email" id="email" placeholder="email" required/></td>
</tr>
<tr>
<td><font size="+1" face="Times New Roman, Times, serif">Password</font></td>
<td><input type="password" name="password" id="password" placeholder="password" required /></td>
</tr>


<tr>
<td><input type="submit" class="btn-green" name="submit" id="submit" value="submit" /> <input type="submit" class="btn-green" name="submit" id="submit" value="reset" /></td></tr>

</form> </table>


<br /><br /><br /><br /><br />


           <!-- Footer -->
    <footer>
      <div class="container">
        <div class="row-fluid">
          <div class="span3">
            <ul class="nav nav-list">
              <li class="nav-header">Contact Us</li>
              <li><span class="label label-inverse">Mobile</span></li>
              <li><span class="label label-inverse">Mobile</span></li>
              <li><span class="label label-inverse">Email</span></li>
             <li><span class="label label-inverse">Email</span></li>

              
            </ul>
          </div><!--/.span3 -->

          <div class="span3">
           <ul class="nav nav-list">
              <li class="nav-header">WEBSITE NAVIGATION</li>
              <li><a href="patient.php">Patient</a></li>
              <li><a href="about1.php">About us</a></li>
              <li><a href="contact-us.php">Contact Us</a></li>
            </ul>
          </div><!--/.span3 -->
        
                   
          <div class="span12 copyright">
         
          </div><!--/.span12 -->
        </div><!--/.row-fluid -->
      </div><!--/.container -->
    </footer>
    <!-- End Footer -->
    
    <!-- Javascript Placed at the end of the document so the pages load faster -->
    
    <!-- Twitter Bootstrap -->
    <script src="js/bootstrap/bootstrap.js"></script>
    
    <!-- Form Validation -->
    <script src="js/validate/jquery.validationEngine.js"></script>
    <script>
      jQuery(document).ready(function(){
	// binds form submission and fields to the validation engine
      	jQuery("#formID").validationEngine();
      });
    </script>
    
    <!-- Elastislide -->
    <script type="text/javascript" src="js/jquery.elastislide.js"></script>
    <script type="text/javascript">
		$('#carousel').elastislide({
			  imageW 	: 180,
			  minItems	: 5
		});	
    </script>

  </body>
</html>

          
          
 





	 
    

