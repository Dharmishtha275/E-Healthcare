<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
  <head>
    <!-- Basic meta tags -->
   
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Ehealthcare - Bootstrap Responsive Template</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- CSS styles -->
    <link href="css/style.css" rel="stylesheet">
      
    <!-- Google Web font 'PT Sans and Yanone Kaffeesatz' -->  
    <link href='http://fonts.googleapis.com/css?family=PT+Sans+Narrow|Yanone+Kaffeesatz:400,300,700' rel='stylesheet' type='text/css'>
     
    <!-- Jquery Library -->
    <script src="js/jquery-1.7.1.min.js"></script>
    
    <!-- for IE6-8 support of HTML5 elements & Seperate CSS for ie-8-7 -->
    <!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
      <link href="css/ie8-7.css" rel="stylesheet">
    <![endif]-->
    
  </head>

  <body>
    <!-- Header -->
    <header>
      <div class="container">
        <div class="row-fluid">
	  <!-- logo -->
          <div class="span6 logo">
            <a href="index.php"><img src="img/plo.jpg" /></a>
          </div>
	  <!-- End Logo -->
          
          <!-- Social menu -->
	  <div class="span6" id="social">
            <ul class="social">
              <li class="twitter">
		<a target="_blank" href="#">&nbsp;</a>
              </li>
	      <li class="facebook">
		<a target="_blank" href="#">&nbsp;</a>
	      </li>
            </ul>
          </div>
          <!-- End Social Menu -->
        </div> <!--/.row-fluid -->
      </div> <!--/.container -->
    </header>
    <!-- End Header -->
    
    <!-- Section Top -->
    <section id="top">
      <div class="container">
	<!-- Main Menu -->
        <div class="navbar">
          <div class="navbar-inner">
            <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
	      Main Menu
            </a>
            <div class="nav-collapse">
              <ul class="nav">
                <li><a href="index.php">home</a></li>
                
                 <li class="dropdown">
                  <a href="doctorlogin.php">admin</a></li>
                  
                   
                   
                  <li class="dropdown">
                  <a href="registration.php">registration.php</a></li>
                  
                <li class="dropdown">
               <a  href="login.php">login</a></li>

                <li class="dropdown">
		  <a href="about1.php">about us</a></li>
		 
                <li><a href="contact-us.php">Contact Us</a></li>
              </ul>
            </div> <!--/.nav-collapse -->
          </div> <!--/.navbar-inner -->
        </div> <!--/.navbar -->
        <!-- End Main Menu -->
	
      </div> <!--/.container -->
    </section> <!--/#top --> 
    <!--  End Section Top -->
    
    <!-- Section Breadcrumbs-->
    <section id="breadcrumb">
      <div class="b-c">
	<div class="container">
	  <ul class="breadcrumb">
	    <li class="title">You are here</li>
	    <li><a href="#">Home</a> <span class="divider"><img src="img/br-arrow.png" alt="" /></span></li>
	    <li><a href="#">Web Pages</a> <span class="divider"><img src="img/br-arrow.png" alt=""  /></span></li>
	    <li class="active">About us</li>
	  </ul>
	</div> <!--/.container -->
      </div> <!--/.b-c -->
    </section> <!--#breadcrumb -->
    <!-- End Section Breadcrumb -->
    
    <!-- Section content -->
    <section id="content">
      <div class="container">
        <div class="row-fluid">
	  <div class="page clearfix">
	    <div class="span4 hid">
	      <img src="img/gallery/1.jpg" alt=""  />
	    </div>
	    <div class="span4">
	      <img src="img/gallery/3.jpg" alt=""  />
	    </div>
	    <div class="span4 hid">
	      <img src="img/gallery/8.jpg" alt=""  />
	    </div>
	    
	    <div class="clearfix"></div>
	    
	    <div class="caption">
	      <h3>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aliquam vel nisl sem. Integer vitae turpis sem, nec sollicitudin eros. Sed libero nisl, consequat sit amet vehicula sed, facilisis at nunc. In ultrices nisl ac nibh vestibulum non porttitor augue porttitor. Aliquam vel nisl sem. Integer vitae turpis ipsum dolor sit amet, consectetur adipiscing. Vivamus ut dui metus Pellentesque</h3>
	    </div> <!--/.caption -->

	    <h3 class="marg-top-med">our healthcare products</h3>
	    <p>Every day,Millons of Peoples Around The World Enjoy The Benefits of Product From E-Healthcare Companies
 your Familys Health And well-being is our Passion.Thats Why Our Companys Offer The Worlds Broadest Range of Healthcare Products.Whether you Have a Skin Blemish or Sniffles or a Serious Medical Condition,you and The Health Professionals you Trust can Turn to your Companies Products for Comfort and care.    </p>
	    <p>In Your Home,Products From our Consumer Health Companys Brighten your Smile,and luster to your Hair and ease The Nagging Headache you Can Rely on us to Help keep Baby Fresh,Sooth an irritating itch,or Relieve and Aching Muscle in Operating Rooms and Laboratories,Doctors and Nurses too Rely,on Products from our Medical Technologies Companys   .</p>
	    <h3 class="marg-top-med">Imperdiet molestie nisl mauris nec magna</h3>
	    <p>Imperdiet molestie nisl mauris nec magna. Ut ullamcorper ultrices est, imperdiet a gravida orci fringilla. Nullam non molestie mauris. Suspendisse accumsan metus sed arcu commodo malesuada. Nam purus ligula, accumsan eu imperdiet non, auctor eu ligula. Ut malesuada ligula in magna malesuada vestibulum. Sed vitae dolor non elit aliquet consectetur. Pellentesque adipiscing faucibus euismod. Vestibulum sapien lorem, suscipit sit amet pretium ut, fringilla vitae dolor. Nulla et ante vitae dolor hendrerit placerat.</p>
	  </div> <!--/.page -->  
        </div> <!--/.row-fluid -->
      </div> <!--/.Container -->
    </section> <!--#content -->
    <!-- End Section content-->
    
    <!-- Footer -->
    <footer>
      <div class="container">
        <div class="row-fluid">
          <div class="span3">
            <ul class="nav nav-list">
              <li class="nav-header">Contact Us</li>
               <li><span class="label label-inverse">Mobile</span>7567270530</li>
              <li><span class="label label-inverse">Mobile</span>7048333781</li>
              <li><span class="label label-inverse">Email</span>yashcthakore@gmail.com</li>
             <li><span class="label label-inverse">Email</span>deepzumkhawala@gmail.com</li>


              
            </ul>
          </div> <!--/.span3 -->

          <div class="span3">
           <ul class="nav nav-list">
              <li class="nav-header">WEBSITE NAVIGATION</li>
              <li><a href="#">Home Page</a></li>
              <li><a href="#">doctor</a></li>
              <li><a href="registration.php">Registration</a></li>
              <li><a href="patient.php">Patient</a></li>
              <li><a href="about1.php">About us</a></li>
              <li><a href="contact-us.php">Contact Us</a></li>
            </ul>
          </div> <!--/.span3 -->
        
          
          <div class="span12 copyright">
       
          </div><!--/.span12 -->
        </div><!--/.row-fluid -->
      </div><!--/.container -->
    </footer>
    <!-- End Footer -->
    
    <!-- Javascript Placed at the end of the document so the pages load faster -->
    
    <!-- Twitter Bootstrap -->
    <script src="js/bootstrap/bootstrap.js"></script>

  </body>
</html>
