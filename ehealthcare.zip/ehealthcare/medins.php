<?php
$conn=mysql_connect("localhost","root","");
mysql_select_db("ehealthcare",$conn);
$code=$_POST['code'];
$name=$_POST['name'];
$date=$_POST['date'];
$ex=$_POST['ex'];
$batch=$_POST['batch'];
$prize=$_POST['prize'];
$qty=$_POST['qty'];
$insert="INSERT INTO medicine(code,name,date,ex,batch,prize,qty) VALUES ('$code','$name','$date','$ex','$batch','$prize','$qty')";
$query=mysql_query($insert,$conn);
header("Location:medicine.php");
?>