<?php
$conn=mysql_connect("localhost","root","");
mysql_select_db("ehealthcare",$conn);

$name=$_POST['name'];
$email=$_POST['email'];
$ques=$_POST['ques'];
$insert="INSERT INTO answer(name,email,ques) VALUES ('$name','$email','$ques')";
$query=mysql_query($insert,$conn);
header("Location:answer.php");
?>