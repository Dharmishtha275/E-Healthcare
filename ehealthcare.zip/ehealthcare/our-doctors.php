<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
  <head>
    <!-- Basic meta tags -->
   
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
 
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- CSS styles -->
    <link href="css/style.css" rel="stylesheet">
      
    <!-- Google Web font 'PT Sans and Yanone Kaffeesatz' -->  
    <link href='http://fonts.googleapis.com/css?family=PT+Sans+Narrow|Yanone+Kaffeesatz:400,300,700' rel='stylesheet' type='text/css'>
     
    <!-- Jquery Library -->
    <script src="js/jquery-1.7.1.min.js"></script>
    
    <!-- for IE6-8 support of HTML5 elements & Seperate CSS for ie-8-7 -->
    <!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
      <link href="css/ie8-7.css" rel="stylesheet">
    <![endif]-->
    
  </head>

  <body>
    <!-- Header -->
    <header>
      <div class="container">
        <div class="row-fluid">
	  <!-- logo -->
          <div class="span6 logo">
            <a href="index.php"><img src="img/plo.jpg" alt="" /></a>
          </div>
	  <!-- End Logo -->
          
          <!-- Social menu -->
	  <div class="span6" id="social">
            <ul class="social">
              <li class="twitter">
		<a target="_blank" href="#">&nbsp;</a>
              </li>
	      <li class="facebook">
		<a target="_blank" href="#">&nbsp;</a>
	      </li>
            </ul>
          </div>
          <!-- End Social Menu -->
        </div> <!--/.row-fluid -->
      </div> <!--/.container -->
    </header>
    <!-- End Header -->
    
    <!-- Section Top -->
    <section id="top">
      <div class="container">
	<!-- Main Menu -->
        <div class="navbar">
          <div class="navbar-inner">
            <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
	      Main Menu
            </a>
             <!--/.nav-collapse -->
          </div> <!--/.navbar-inner -->
        </div> <!--/.navbar -->
        <!-- End Main Menu -->
	
      </div> <!--/.container -->
    </section> <!--/#top --> 
    <!--  End Section Top -->
    
    <!-- Section Breadcrumbs-->
    <!--#breadcrumb -->
    <!-- End Section Breadcrumb -->
    
    <!-- Section content -->
    <section id="content" class="doctors">
      <div class="container">
        <div class="row-fluid">
	  <div class="span3">
	    <div class="page clearfix">
	      <img src="img/carousel/1.jpg" alt="" />
	      <h4>Mrs. Melisa Arguelles</h4>
	      <p>Maecenas at mi nulla, et ultrices neque. Sed vestibulum faucibus nunc, at euismod magna facilisis a. Etiam eleifend imperdiet dolor, at accumsan libero feugiat sit amet.</p>
	    </div>
	  </div>
	  
	  <div class="span3">
	    <div class="page clearfix">
	      <img src="img/carousel/2.jpg" alt="" />
	      <h4>Mrs. Alejandra Fenster</h4>
	      <p>Maecenas at mi nulla, et ultrices neque. Sed vestibulum faucibus nunc, at euismod magna facilisis a. Etiam eleifend imperdiet dolor, at accumsan libero feugiat sit amet.</p>
	    </div>
	  </div>
	  
	  <div class="span3">
	    <div class="page clearfix">
	      <img src="img/carousel/3.jpg" alt="" />
	      <h4>Mrs. Clare Gehlert</h4>
	      <p>Maecenas at mi nulla, et ultrices neque. Sed vestibulum faucibus nunc, at euismod magna facilisis a. Etiam eleifend imperdiet dolor, at accumsan libero feugiat sit amet.</p>
	    </div>
	  </div>
	  
	  <div class="span3">
	    <div class="page clearfix">
	      <img src="img/carousel/4.jpg" alt="" />
	      <h4>Mrs. Darcy Hersman</h4>
	      <p>Maecenas at mi nulla, et ultrices neque. Sed vestibulum faucibus nunc, at euismod magna facilisis a. Etiam eleifend imperdiet dolor, at accumsan libero feugiat sit amet.</p>
	    </div>
	  </div>
	  
	  <div class="span3">
	    <div class="page clearfix">
	      <img src="img/carousel/5.jpg" alt="" />
	      <h4>Mrs. Jami Redington</h4>
	      <p>Maecenas at mi nulla, et ultrices neque. Sed vestibulum faucibus nunc, at euismod magna facilisis a. Etiam eleifend imperdiet dolor, at accumsan libero feugiat sit amet.</p>
	    </div>
	  </div>
	  
	  <div class="span3">
	    <div class="page clearfix">
	      <img src="img/carousel/6.jpg" alt="" />
	      <h4>Mrs. Tanisha Enterline</h4>
	      <p>Maecenas at mi nulla, et ultrices neque. Sed vestibulum faucibus nunc, at euismod magna facilisis a. Etiam eleifend imperdiet dolor, at accumsan libero feugiat sit amet.</p>
	    </div>
	  </div>
	  
	  <div class="span3">
	    <div class="page clearfix">
	      <img src="img/carousel/7.jpg" alt="" />
	      <h4>Mrs. Edwina Lukowski</h4>
	      <p>Maecenas at mi nulla, et ultrices neque. Sed vestibulum faucibus nunc, at euismod magna facilisis a. Etiam eleifend imperdiet dolor, at accumsan libero feugiat sit amet.</p>
	    </div>
	  </div>
	  
	  <div class="span3">
	    <div class="page clearfix">
	      <img src="img/carousel/8.jpg" alt="" />
	      <h4>Mrs. Lorrie Raymo</h4>
	      <p>Maecenas at mi nulla, et ultrices neque. Sed vestibulum faucibus nunc, at euismod magna facilisis a. Etiam eleifend imperdiet dolor, at accumsan libero feugiat sit amet.</p>
	    </div>
	  </div>
	  
	  <div class="span3">
	    <div class="page clearfix">
	      <img src="img/carousel/9.jpg" alt="" />
	      <h4>Mrs. Alana Paula</h4>
	      <p>Maecenas at mi nulla, et ultrices neque. Sed vestibulum faucibus nunc, at euismod magna facilisis a. Etiam eleifend imperdiet dolor, at accumsan libero feugiat sit amet.</p>
	    </div>
	  </div>
	  
	  <div class="span3">
	    <div class="page clearfix">
	      <img src="img/carousel/10.jpg" alt="" />
	      <h4>Mrs. Esmeralda Galaz</h4>
	      <p>Maecenas at mi nulla, et ultrices neque. Sed vestibulum faucibus nunc, at euismod magna facilisis a. Etiam eleifend imperdiet dolor, at accumsan libero feugiat sit amet.</p>
	    </div>
	  </div>
	  
	  <div class="span3">
	    <div class="page clearfix">
	      <img src="img/carousel/11.jpg" alt="" />
	      <h4>Mrs. Margery Berti</h4>
	      <p>Maecenas at mi nulla, et ultrices neque. Sed vestibulum faucibus nunc, at euismod magna facilisis a. Etiam eleifend imperdiet dolor, at accumsan libero feugiat sit amet.</p>
	    </div>
	  </div>
	  
	  <div class="span3">
	    <div class="page clearfix">
	      <img src="img/carousel/12.jpg" alt="" />
	      <h4>Mrs. Noreen Bosque</h4>
	      <p>Maecenas at mi nulla, et ultrices neque. Sed vestibulum faucibus nunc, at euismod magna facilisis a. Etiam eleifend imperdiet dolor, at accumsan libero feugiat sit amet.</p>
	    </div>
	  </div>
        </div> <!--/.row-fluid -->
      </div> <!--/.Container -->
    </section> <!--#content -->
    <!-- End Section content-->
    
    <!-- Footer -->
    <footer>
      <div class="container">
        <div class="row-fluid">
          <div class="span3">
            <ul class="nav nav-list">
              <li class="nav-header">Contact Us</li>
              <li><span class="label label-inverse">Mobile</span></li>
              <li><span class="label label-inverse">Mobile</span></li>
              <li><span class="label label-inverse">Email</span></li>
             <li><span class="label label-inverse">Email</span></li>

              
            </ul>
          </div> <!--/.span3 -->

          <div class="span3">
           <ul class="nav nav-list">
              <li class="nav-header">WEBSITE NAVIGATION</li>
              <li><a href="#">Home Page</a></li>
              <li><a href="#">Doctor</a></li>
              <li><a href="registration.php">Registration</a></li>
              <li><a href="patient.php">Patient</a></li>
              <li><a href="about1.php">About us</a></li>
              <li><a href="contact-us.php">Contact Us</a></li>
            </ul>
          </div> <!--/.span3 -->
        
          <div class="span3">
            <ul class="nav nav-list">
              <li class="nav-header">Social with us</li>
              <li><a href="#">Facebook</a></li>
              <li><a href="#">Twitter</a></li>
              <li><a href="#">Google Plus</a></li>
              <li><a href="#">Linkedin</a></li>
              <li><a href="#">Youtube</a></li>
            </ul>
          </div> <!--/.span3 -->

          
          </div><!--/.span12 -->
        </div><!--/.row-fluid -->
      </div><!--/.container -->
    </footer>
    <!-- End Footer -->
    
    <!-- Javascript Placed at the end of the document so the pages load faster -->
    
    <!-- Twitter Bootstrap -->
    <script src="js/bootstrap/bootstrap.js"></script>

  </body>
</html>
