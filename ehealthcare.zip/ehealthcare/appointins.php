<?php
$conn=mysql_connect("localhost","root","");
mysql_select_db("ehealthcare",$conn);
$id=$_POST['id'];
$name=$_POST['name'];
$age=$_POST['age'];
$date=$_POST['date'];
$no=$_POST['no'];
$insert="INSERT INTO appointment(id,name,age,no) VALUES ('$id','$name','$age','$no')";
$query=mysql_query($insert,$conn);
header("location:newappoint.php");
?>