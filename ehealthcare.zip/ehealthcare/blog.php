<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
  <head>
    <!-- Basic meta tags -->
   
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Medical Pro - Bootstrap Responsive Template</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- CSS styles -->
    <link href="css/style.css" rel="stylesheet">
    <link href="css/validationengine.css" rel="stylesheet">

    <!-- Google Web font 'PT Sans and Yanone Kaffeesatz' -->  
    <link href='http://fonts.googleapis.com/css?family=PT+Sans+Narrow|Yanone+Kaffeesatz:400,300,700' rel='stylesheet' type='text/css'>
     
    <!-- Jquery Library -->
    <script src="js/jquery-1.7.1.min.js"></script>
 
    <!-- For IE6-8 support of HTML5 elements & Seperate CSS for ie-8-7 -->
    <!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
      <link href="css/ie8-7.css" rel="stylesheet">
    <![endif]-->
  </head>

  <body>
    <!-- Header -->
    <header>
      <div class="container">
        <div class="row-fluid">
	  <!-- logo -->
          <div class="span6 logo">
            <a href="index.php"><img src="img/logo.png" /></a>
          </div>
	  <!-- End Logo -->
          
          <!-- Social menu -->
	  <div class="span6" id="social">
            <ul class="social">
              <li class="twitter">
		<a target="_blank" href="#">&nbsp;</a>
              </li>
	      <li class="facebook">
		<a target="_blank" href="#">&nbsp;</a>
	      </li>
            </ul>
          </div>
          <!-- End Social Menu -->
        </div> <!--/.row-fluid -->
      </div> <!--/.container -->
    </header>
    <!-- End Header -->
    
    <!-- Section Top -->
    <section id="top">
      <div class="container">
	<!-- Main Menu -->
        <div class="navbar">
          <div class="navbar-inner">
            <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
	      Main Menu
            </a>
            <div class="nav-collapse">
              <ul class="nav">
                <li><a href="index.php">Home</a></li>
                
                 <li class="dropdown">
                  <a href="doctorlogin.php">admin</a></li>
                  
                   
                   
                   <li class="dropdown">
                  <a href="registration.php">registration</a></li>
                  
                <li class="dropdown">
                <a  href="login.php">login</a></li>

       

                <li class="dropdown active">
 		  <a href="about1.php">about us</a></li>
          
                <li><a href="contact-us.php">Contact Us</a></li>
              </ul>
            </div> <!--/.nav-collapse -->
          </div> <!--/.navbar-inner -->
        </div> <!--/.navbar -->
        <!-- End Main Menu -->
	
      </div> <!--/.container -->
    </section> <!--/#top --> 
    <!--  End Section Top -->
    
    <!-- Section Breadcrumbs-->
    <section id="breadcrumb">
      <div class="b-c">
	<div class="container">
	  <ul class="breadcrumb">
	    <li class="title">You are here</li>
	    <li><a href="#">Home</a> <span class="divider"><img src="img/br-arrow.png" alt="" /></span></li>
	    <li><a href="#">Our Blog</a> <span class="divider"><img src="img/br-arrow.png" alt="" /></span></li>
	    <li class="active">Modern Style</li>
	  </ul>
	</div> <!--/.container -->
      </div> <!--/.b-c -->
    </section> <!--#breadcrumb -->
    <!-- End Section Breadcrumb -->
    
    <!-- Section content -->
    <section id="content">
      <div class="container">
	<div class="row-fluid">
	  <div class="span8">
	    <div class="page no-padd clearfix">
	      <div class="blog-cp">
		<div class="blog-date">15/06</div>
		<ul>
		  <li class="arthur"><a href="#" data-rel="tooltip" title="Admin" class="tooltips"></a></li>
		  <li class="comment"><a href="#" data-rel="tooltip" title="15" class="tooltips"></a></li>
		  <li class="tag"><a href="#" data-rel="tooltip" title="Medical, Blog" class="tooltips"></a></li>
		</ul>
	      </div> <!--/.blog-cp -->     
	      <img src="img/blog/1.jpg" alt="" />
    
	      <div class="entry">
		<h3>Another Blog entry with Image</h3>
		<p>Pellentesque nec dolor in mauris auctor varius. Cras pharetra consequat dolor sed elementum. Pellentesque non tortor aliquet metus vestibulum lobortis et et eros. Suspendisse hendrerit suscipit diam sed porta. Pellentesque dictum mollis arcu eu gravida. Aliquam imperdiet viverra ornare. Pellentesque nec dolor in mauris auctor varius. Cras pharetra consequat dolor sed elementum. Pellentesque non tortor aliquet metus vestibulum lobortis et et eros. Suspendisse hendrerit.</p>
		<span class="btn btn-green"><a href="blog-detail.html">Read More</a></span>
	      </div> <!--/.entry -->
	    </div> <!--/.page .no-padd .clearfix -->
	    
	    <div class="page no-padd clearfix">
	      <div class="blog-cp">
		<div class="blog-date">10/06</div>
		<ul>
		  <li class="arthur"><a href="#" data-rel="tooltip" title="Admin" class="tooltips"></a></li>
		  <li class="comment"><a href="#" data-rel="tooltip" title="15" class="tooltips"></a></li>
		  <li class="tag"><a href="#" data-rel="tooltip" title="Medical, Blog" class="tooltips"></a></li>
		</ul>
	      </div> <!--/.blog-cp -->     
	      <img src="img/blog/2.jpg" alt="" />
    
	      <div class="entry">
		<h3>Another Blog entry with Image</h3>
		<p>Pellentesque nec dolor in mauris auctor varius. Cras pharetra consequat dolor sed elementum. Pellentesque non tortor aliquet metus vestibulum lobortis et et eros. Suspendisse hendrerit suscipit diam sed porta. Pellentesque dictum mollis arcu eu gravida. Aliquam imperdiet viverra ornare. Pellentesque nec dolor in mauris auctor varius. Cras pharetra consequat dolor sed elementum. Pellentesque non tortor aliquet metus vestibulum lobortis et et eros. Suspendisse hendrerit.</p>
		<span class="btn btn-green"><a href="blog-detail.html">Read More</a></span>
	      </div> <!--/.entry -->
	    </div> <!--/.page .no-padd .clearfix -->
	    
	    <div class="page no-padd clearfix">
	      <div class="blog-cp">
		<div class="blog-date">29/03</div>
		<ul>
		  <li class="arthur"><a href="#" data-rel="tooltip" title="Nathan Morn" class="tooltips"></a></li>
		  <li class="comment"><a href="#" data-rel="tooltip" title="10" class="tooltips"></a></li>
		  <li class="tag"><a href="#" data-rel="tooltip" title="Hospital, Doctor" class="tooltips"></a></li>
		</ul>
	      </div> <!--/.blog-cp -->
	      
	      <div class="entry">  
		<h3>Text only Blog entry </h3>
		<p>Mauris erat arcu, tincidunt a mollis et, cursus et nulla. Quisque quis magna non enim ultricies ullamcorper vitae vitae odio. Praesent eget nisi orci. Morbi hendrerit, erat eget aliquam accumsan, nulla diam imperdiet velit, sit amet lacinia turpis sapien sit amet enim. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Vivamus viverra, augue eget dapibus rutrum, mauris justo pellentesque ligula, id eleifend nisi lorem ac nisl. Nulla ultricies arcu egestas ligula porta fringilla. Etiam euismod porta dolor sed vulputate.</p>
		<span class="btn btn-green"><a href="blog-detail.html">Read More</a></span>
	      </div> <!--/.entry -->
	    </div> <!--/.page .no-padd .clearfix -->
	    
	     <div class="page no-padd clearfix">
	      <div class="blog-cp">
		<div class="blog-date">01/03</div>
		<ul>
		  <li class="arthur"><a href="#" data-rel="tooltip" title="Nathan Morn" class="tooltips"></a></li>
		  <li class="comment"><a href="#" data-rel="tooltip" title="10" class="tooltips"></a></li>
		  <li class="tag"><a href="#" data-rel="tooltip" title="Hospital, Doctor" class="tooltips"></a></li>
		</ul>
	      </div> <!--/.blog-cp -->
	      
	      <div class="entry">  
		<h3>Another Text only Blog entry </h3>
		<p>Mauris erat arcu, tincidunt a mollis et, cursus et nulla. Quisque quis magna non enim ultricies ullamcorper vitae vitae odio. Praesent eget nisi orci. Morbi hendrerit, erat eget aliquam accumsan, nulla diam imperdiet velit, sit amet lacinia turpis sapien sit amet enim. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Vivamus viverra, augue eget dapibus rutrum, mauris justo pellentesque ligula, id eleifend nisi lorem ac nisl. Nulla ultricies arcu egestas ligula porta fringilla. Etiam euismod porta dolor sed vulputate.</p>
		<span class="btn btn-green"><a href="blog-detail.html">Read More</a></span>
	      </div> <!--/.entry -->
	    </div> <!--/.page .no-padd .clearfix -->
	    
	    <!-- Pagination -->
	    <div class="page clearfix no-marg-bottom" id="pagination">
	      <div class="pagination">
		<ul>
		  <li><a href="#">Prev</a></li>
		  <li class="active">
		    <a href="#">1</a>
		  </li>
		  <li><a href="#">2</a></li>
		  <li><a href="#">3</a></li>
		  <li><a href="#">4</a></li>
		  <li><a href="#">Next</a></li>
		</ul>
	      </div> <!--/.pagination -->
	    </div> <!--/.page .clearfix .no-marg-bottom -->
	    <!-- End Pagination -->
 
	  </div> <!-- span8 -->
	  
	  <!-- Sidebar -->
	  <div class="span4">
	    
	    <!-- Category Widget -->
	    <div class="page category">
	      <h3 class="tree">Sample Categories</h3>
	      <div class="sidebar-nav">
		<ul class="nav nav-list">
		  <li><a href="#">Wireless Video Capsule (VCE)</a></li>
		  <li><a href="#">Diabetes Prevention and Risk</a></li>
		  <li><a href="#">Pain Management</a></li>
		  <li><a href="#">Reproductive Endocrinology</a></li>
		  <li><a href="#">Osteoporosis Lipid Disorders</a></li>
		  <li><a href="#">Non-surgical treatment of obesity</a></li>
		</ul>
	      </div><!--/.sidebar-nav -->
	    </div><!--/.page .category -->
	    <!-- End Category Widget -->
	    
	    <!-- Text Widget -->
	    <div class="page">
	      <h3 class="tree">Text Widget with Image</h3>
	      <img src="img/blog/1-1.jpg" alt="" />
	      <p>Donec vulputate diam eu elit molestie eu gravida ante laoreet. Donec vulputate Donec vulputate diam eu elit molestie molestie eu gravida ante laoreet Donec vulputate diam eu elit molestie eu gravida ante laoreet.</p>
	    </div> <!--/.page -->
	    <!--  End Text Widget -->
	    
	    <!-- Accordian Widget -->
	    <div class="page">
	      <h3 class="tree">Accordian (Collapse)</h3>
	      <div class="accordion" id="accordion2">
		<div class="accordion-group">
		  <div class="accordion-heading">
		    <a class="accordion-toggle" data-toggle="collapse" data-parent=".accordion" href="#collapseOne">
		      Collapsible Group Item #1
		    </a>
		  </div>
		  <div id="collapseOne" class="accordion-body collapse" style="height: 0px; ">
		    <div class="accordion-inner">
		      <p>Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.</p>
		    </div>
		  </div>
		</div> <!--/.accordion-group -->
		<div class="accordion-group">
		  <div class="accordion-heading">
		    <a class="accordion-toggle" data-toggle="collapse" data-parent=".accordion" href="#collapseTwo">
		      Collapsible Group Item #2
		    </a>
		  </div>
		  <div id="collapseTwo" class="accordion-body in collapse" style="height: auto; ">
		    <div class="accordion-inner">
		      <p>Nihil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.</p>
		    </div>
		  </div>
		</div> <!--/.accordion-group -->
		<div class="accordion-group">
		  <div class="accordion-heading">
		    <a class="accordion-toggle" data-toggle="collapse" data-parent=".accordion" href="#collapseThree">
		      Collapsible Group Item #3
		    </a>
		  </div>
		  <div id="collapseThree" class="accordion-body collapse">
		    <div class="accordion-inner">
		      <p>Nhil anim keffiyeh helvetica, craft beer labore wes anderson cred nesciunt sapiente ea proident. Ad vegan excepteur butcher vice lomo. Leggings occaecat craft beer farm-to-table, raw denim aesthetic synth nesciunt you probably haven't heard of them accusamus labore sustainable VHS.</p>
		    </div>
		  </div>
		</div> <!--/.accordion-group -->
	      </div>
	    </div> <!--/.page -->
	    <!--  End Accordian Widget -->
	    
	    <!-- Twitter Widget -->
	    <div class="page">
	      <h3 class="tree">Twitter Widget</h3>
	      <div class="tweet"></div>
	    </div> <!--/.page -->
	    <!--  End Twitter Widget -->

	  </div> <!--/.span4 -->
	  <!-- End Sidebar -->
	  
	</div> <!--/.container -->
      </div> <!--/.row-fluid -->
    </section>
    <!-- End Section content -->

    <!-- Footer -->
    <footer>
      <div class="container">
        <div class="row-fluid">
          <div class="span3">
            <ul class="nav nav-list">
              <li class="nav-header">Contact Us</li>
               <li><span class="label label-inverse">Mobile</span></li>
              <li><span class="label label-inverse">Mobile</span></li>
              <li><span class="label label-inverse">Email</span></li>
             <li><span class="label label-inverse">Email</span></li>

              
            </ul>
          </div><!--/.span3 -->

          <div class="span3">
           <ul class="nav nav-list">
              <li class="nav-header">WEBSITE NAVIGATION</li>
              <li><a href="#">Home Page</a></li>
              <li><a href="#">Doctor</a></li>
              <li><a href="registration.php">Registration</a></li>
              <li><a href="patient.php">Patient</a></li>
              <li><a href="about1.php">About us</a></li>
              <li><a href="contact-us.php">Contact Us</a></li>
            </ul>
          </div><!--/.span3 -->
        
          <div class="span3">
            <ul class="nav nav-list">
              <li class="nav-header">Social with us</li>
              <li><a href="#">Facebook</a></li>
              <li><a href="#">Twitter</a></li>
              <li><a href="#">Google Plus</a></li>
              <li><a href="#">Linkedin</a></li>
              <li><a href="#">Youtube</a></li>
            </ul>
          </div><!--/.span3 -->

          <div class="span3">
            <ul class="nav nav-list">
              <li class="nav-header">Sample Menu</li>
              <li><a href="#">Menu one</a></li>
              <li><a href="#">Menu Two</a></li>
              <li><a href="#">Menu Three</a></li>
              <li><a href="#">Menu Four</a></li>
              <li><a href="#">Menu Five</a></li>
              <li><a href="#">Menu Six</a></li>
            </ul>
          </div><!--/.span3 -->
          
          <div class="span12 copyright">
       
          </div><!--/.span12 -->
        </div><!--/.row-fluid -->
      </div><!--/.container -->
    </footer>
    <!-- End Footer -->

    <!-- Javascript Placed at the end of the document so the pages load faster -->
    
    <!-- Twitter Bootstrap -->
    <script src="js/bootstrap/bootstrap.js"></script>
    <script type="text/javascript">
      $(document).ready(function(){  
	$('.tooltips').tooltip({'placement':'top', 'trigger' : 'hover'});  
	$(".accordian").collapse()
      });  
    </script>
    
    <!-- Form Validation -->
    <script src="js/validate/jquery.validationEngine.js"></script>
    <script>
      jQuery(document).ready(function(){
	// binds form submission and fields to the validation engine
      	jQuery("#formID").validationEngine();
      });
    </script>
    
    <!-- Twitter widget -->
    <script src="js/jquery.tweet.js" type="text/javascript"></script>
    <script type='text/javascript'>
      jQuery(function($){
	  $(".tweet").tweet({
	      username: "rushan123",
	      join_text: "auto",
	      avatar_size: "30",
	      count: 4,
	      auto_join_text_default: "we said,", 
	      auto_join_text_ed: "we",
	      auto_join_text_ing: "we were",
	      auto_join_text_reply: "we replied to",
	      auto_join_text_url: "",
	      loading_text: "loading tweets..."
	  });
      });
    </script>
  </body>
</html>
