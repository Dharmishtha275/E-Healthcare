<?php
$conn=mysql_connect("localhost","root","");
mysql_select_db("ehealthcare",$conn);
$name=$_POST['name'];
$email=$_POST['email'];
$message=$_POST['message'];
$insert="INSERT INTO email(name,email,message) VALUES ('$name','$email','$message')";
$query=mysql_query($insert,$conn);
header("location:contact-us.php");
?>
