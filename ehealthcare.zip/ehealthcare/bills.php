<html>
<head>
<?php
if(isset($_POST['submit']))
{
$conn=mysql_connect("localhost","root","");
mysql_select_db("ehealthcare",$conn);
$date=$_POST['date'];
$Firstname=$_POST['pname'];
$addr=$_POST['addr'];
$phoneno=$_POST['Phoneno'];
$med_name=$_POST['med_name'];
$quan=$_POST['qty'];
$price=$_POST['price'];
$discount=$_POST['disc'];
$total=$_POST['total'];

$insert="INSERT INTO bill(bill_date,patient_name,addr,cont_no,med_name,price,discount,total) VALUES ('$date','$Firstname','$addr','$phoneno','$med_name','$quan','$price','discount','$total')";
$query=mysql_query($insert,$conn);
if($query)
{
	header("Location:priscription.php");
}
else
{
	echo "<script>priscription not submit</script>";
}

}
?>
</head>


<body>


<form name="htr" id="htr" method="post" onsubmit="return validation()" >

<table>
<h1 align="center"><i>BILL</i></h1>
<tr>
<td >Date:
<input type="date" name="date" /><br/><br/></td>
<tr>
<td >Patient Name:<input type="text" name="pname" /><br/><br/></td>
</tr>
<tr>
<td>Address:<input type="text" name="addr"  /><br/><br/></td>
</tr>
<tr>
<td>Phone No:<input type="text" name="Phoneno" id="pno"  /><br/><br/></td>
</tr>
<tr>
<td>Medicine Name:<input type="text" name="med_name" /><br/><br/></td>
</tr>
<tr>
<td>Quantity:<input type="number" name="qty"  /><br/><br/></td>
</tr>
<tr>
<td>Price:<input type="number" name="price" max="10000" min="20"  /><br/><br/></td>
</tr>

<tr>
<td>Discount:<input type="text" name="disc" /><br/><br/></td>
</tr>
<tr>
<td>Total:<input type="text" name="total" /><br/><br/></td>
</tr>
<tr>
<td><input type="submit" class="btn-green" name="submit" id="submit" value="submit"  />
</td>

</tr>
</table>
</form>
<!--<div>

 <form action="view_prec.php" method="POST" name="frm2">
 <input type="submit" class="btn-green" name="print" value="print" id="print"/>
 
 </form>
</div> -->


</body>

</html>
