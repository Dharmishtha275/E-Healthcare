<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
  <head>
    <!-- Basic meta tags -->
   
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Ehealthcare - Bootstrap Responsive Template</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- CSS styles -->
    <link href="css/style.css" rel="stylesheet">
      
    <!-- Google Web font 'PT Sans and Yanone Kaffeesatz' -->  
    <link href='http://fonts.googleapis.com/css?family=PT+Sans+Narrow|Yanone+Kaffeesatz:400,300,700' rel='stylesheet' type='text/css'>
     
    <!-- Jquery Library -->
    <script src="js/jquery-1.7.1.min.js"></script>
    
    <!-- for IE6-8 support of HTML5 elements & Seperate CSS for ie-8-7 -->
    <!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
      <link href="css/ie8-7.css" rel="stylesheet">
    <![endif]-->
    
  </head>

  <body>
    
    <!-- Header -->
    <header>
      <div class="container">
        <div class="row-fluid">
	  <!-- logo -->
          <div class="span6 logo">
            <a href="index.php"><img src="img/logo.png" /></a>
          </div>
	  <!-- End Logo -->
          
          <!-- Social menu -->
	  <div class="span6" id="social">
            <ul class="social">
              <li class="twitter">
		<a target="_blank" href="#">&nbsp;</a>
              </li>
	      <li class="facebook">
		<a target="_blank" href="#">&nbsp;</a>
	      </li>
            </ul>
          </div>
          <!-- End Social Menu -->
        </div> <!--/.row-fluid -->
      </div> <!--/.container -->
    </header>
    <!-- End Header -->
    
    <!-- Section Top -->
    <section id="top">
      <div class="container">
	<!-- Main Menu -->
        <div class="navbar">
          <div class="navbar-inner">
            <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
	      Main Menu
            </a>
            <div class="nav-collapse">
              <ul class="nav">
                <li><a href="index.php">Home</a></li>
                
                 <li class="dropdown">
                  <a href="doctorlogin.php">admin</a></li>
                  
                   
                  
                 <li class="dropdown">
                  <a href="registration.php">registration</a></li>
                  
                <li class="dropdown active">
                  <a href="login.php">login</a></li>
                  

                <li class="dropdown">
		  <a href="about1.php">about us</a></li>

                <li><a href="contact-us.php">Contact Us</a></li>
              </ul>
            </div> <!--/.nav-collapse -->
          </div> <!--/.navbar-inner -->
        </div> <!--/.navbar -->
        <!-- End Main Menu -->
	
      </div> <!--/.container -->
    </section> <!--/#top --> 
    <!--  End Section Top -->
    
    <!-- Section Breadcrumbs-->
    <section id="breadcrumb">
      <div class="b-c">
	<div class="container">
	  <ul class="breadcrumb">
	    <li class="title">You are here</li>
	    <li><a href="#">Home</a> <span class="divider"><img src="img/br-arrow.png" alt="" /></span></li>
	    <li><a href="#">Features</a> <span class="divider"><img src="img/br-arrow.png" alt="" /></span></li>
	    <li class="active">Typography</li>
	  </ul>
	</div> <!--/.container -->
      </div> <!--/.b-c -->
    </section> <!--#breadcrumb -->
    <!-- End Section Breadcrumb -->
    
    <!-- Section content -->
    <section id="content" class="typography">
      <div class="container">
        <div class="row-fluid">
	  <!-- Headings -->
	  <div class="page">
	    <div class="container">
	      <h3 class="tree">Headings</h3>
	      <div class="span4 no-marg-left">
		<h4 class="black">Default</h4>
		<h1>H1.Heading</h1>
		<h2>H2.Heading</h2>
		<h3>H3.Heading</h3>
		<h4>H4.Heading</h4>
		<h5>H5.Heading</h5>
		<h6>H6.Heading</h6>
	      </div> <!--/.span4 .no-marg-left -->
	      
	      <div class="span4">
		<h4 class="black">Styled</h4>
		<h1 class="tree">H1.Heading</h1>
		<h2 class="tree">H2.Heading</h2>
		<h3 class="tree">H3.Heading</h3>
		<h4 class="tree">H4.Heading</h4>
		<h5 class="tree">H5.Heading</h5>
		<h6 class="tree">H6.Heading</h6>
	      </div> <!--/.span4 -->
	      
	      <div class="span4">
		<h4 class="black">Styled on Dark Background</h4>
		<div class="page dark">
		  <h1 class="snow">H1.Heading</h1>
		  <h2 class="snow">H2.Heading</h2>
		  <h3 class="snow">H3.Heading</h3>
		  <h4 class="snow">H4.Heading</h4>
		  <h5 class="snow">H5.Heading</h5>
		  <h6 class="snow">H6.Heading</h6>
		</div>
	      </div> <!--/.span4 -->
	    </div> <!--/.container -->
	  </div> <!--/.page -->
	  <!-- End Headings -->
	  
	  <!-- Unordered Lists -->
	  <div class="page">
	    <div class="container">
	      <h3 class="tree">Unordered List</h3>
	      <div class="span4 no-marg-left">
		<h4 class="black">Default</h4>
		<ul>
		  <li>Lorem ipsum dolor sit amet</li>
		  <li>Consectetur adipiscing elit</li>
		  <li>Integer molestie lorem at massa</li>
		  <li>Facilisis in pretium nisl aliquet</li>
		  <li>Nulla volutpat aliquam velit
		    <ul>
		      <li>Phasellus iaculis neque</li>
		      <li>Purus sodales ultricies</li>
		      <li>Vestibulum laoreet porttitor sem</li>
		      <li>Ac tristique libero volutpat at</li>
		    </ul>
		  </li>
		  <li>Faucibus porta lacus fringilla vel</li>
		  <li>Aenean sit amet erat nunc</li>
		  <li>Eget porttitor lorem</li>
		</ul>
	      </div> <!--/.span4 .no-marg-left -->
	      
	      <div class="span4">
		<h4 class="black">Style-01</h4>
		<ul class="ul-1">
		  <li>Lorem ipsum dolor sit amet</li>
		  <li>Consectetur adipiscing elit</li>
		  <li>Integer molestie lorem at massa</li>
		  <li>Facilisis in pretium nisl aliquet</li>
		  <li>Nulla volutpat aliquam velit
		    <ul>
		      <li>Phasellus iaculis neque</li>
		      <li>Purus sodales ultricies</li>
		      <li>Vestibulum laoreet porttitor sem</li>
		      <li>Ac tristique libero volutpat at</li>
		    </ul>
		  </li>
		  <li>Faucibus porta lacus fringilla vel</li>
		  <li>Aenean sit amet erat nunc</li>
		  <li>Eget porttitor lorem</li>
		</ul>
	      </div> <!--/.span4 -->
	      
	      <div class="span4">
		<h4 class="black">Style-02</h4>
		<ul class="ul-2">
		  <li>Lorem ipsum dolor sit amet</li>
		  <li>Consectetur adipiscing elit</li>
		  <li>Integer molestie lorem at massa</li>
		  <li>Facilisis in pretium nisl aliquet</li>
		  <li>Nulla volutpat aliquam velit
		    <ul>
		      <li>Phasellus iaculis neque</li>
		      <li>Purus sodales ultricies</li>
		      <li>Vestibulum laoreet porttitor sem</li>
		      <li>Ac tristique libero volutpat at</li>
		    </ul>
		  </li>
		  <li>Faucibus porta lacus fringilla vel</li>
		  <li>Aenean sit amet erat nunc</li>
		  <li>Eget porttitor lorem</li>
		</ul>
	      </div> <!--/.span4 -->
	    </div> <!--/.container -->
	  </div> <!--/.page -->
	  <!-- End Unordered Lists -->
	  
	  <!-- Description -->
	  <div class="page">
	    <div class="container">
	      <h3 class="tree">Description</h3>
	      <div class="span5 no-marg-left">
		<h4 class="black">Default</h4>
		<dl>
		  <dt>Description lists</dt>
		  <dd>A description list is perfect for defining terms.</dd>
		  <dt>Euismod</dt>
		  <dd>Vestibulum id ligula porta felis euismod semper eget lacinia odio sem nec elit.</dd>
		  <dd>Donec id elit non mi porta gravida at eget metus.</dd>
		  <dt>Malesuada porta</dt>
		  <dd>Etiam porta sem malesuada magna mollis euismod.</dd>
		</dl>
	      </div> <!--/.span5 .no-marg-left -->
	      
	      <div class="span7">
		<h4 class="black">Horizontal</h4>
		<dl class="dl-horizontal">
		  <dt>Description lists</dt>
		  <dd>A description list is perfect for defining terms.</dd>
		  <dt>Euismod</dt>
		  <dd>Vestibulum id ligula porta felis euismod semper eget lacinia odio sem nec elit.</dd>
		  <dd>Donec id elit non mi porta gravida at eget metus.</dd>
		  <dt>Malesuada porta</dt>
		  <dd>Etiam porta sem malesuada magna mollis euismod.</dd>
		  <dt>Felis euismod semper eget lacinia</dt>
		  <dd>Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus.</dd>
		</dl>
	      </div> <!--/.span7 -->
	    </div> <!--/.container -->
	  </div> <!--/.page -->
	  <!-- End Description -->
	  
	  <!-- Blockquotes -->
	  <div class="page">
	    <div class="container">
	      <h3 class="tree">Blockquotes</h3>
	      <div class="span4 no-marg-left">
		<h4 class="black">Default</h4>
		<blockquote>
		  <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer posuere erat a ante.</p>
		</blockquote>
	      </div> <!--/.span4 .no-marg-left -->
	      
	      <div class="span4">
		<h4 class="black">Naming a Source</h4>
		<blockquote>
		  <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer posuere erat a ante.</p>
		  <small>Someone famous in <cite title="Source Title">Source Title</cite></small>
		</blockquote>
	      </div> <!--/.span4 -->
	      
	      <div class="span4">
		<h4 class="black">Alternate displays</h4>
		<blockquote class="pull-right">
		  <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer posuere erat a ante.</p>
		  <small>Someone famous in <cite title="Source Title">Source Title</cite></small>
		</blockquote>
	      </div> <!--/.span4 -->
	    </div> <!--/.container -->
	  </div> <!--/.page -->
	  <!-- End Blockquotes -->
	  
	  <!-- Abbreviations -->
	  <div class="page">
	    <h3 class="tree">Abbreviations</h3>
	    <p>An abbreviation of the word attribute is <abbr title="attribute">attr</abbr>.</p>
	    <p> Whatya <abbr title="attribute">building?</abbr> Uhm, its just a <abbr title="attribute">little stick fort</abbr>. Oh, rad! Look. Its just my size. Hey, get <abbr title="attribute">away</abbr> from my fort, you big stinky <abbr title="attribute">monster!</abbr> I like it when you get small, Jake. Yeah, me too. Whoa, Peppermint butler! Finn, Jake. The Princess wants to see you. As <abbr title="attribute">princess</abbr> of Candy Kingdom, Im in charge of a lot of candy <abbr title="attribute">people</abbr>. They rely on me. I cant imagine what might happen to them if I was gone. And after my <abbr title="attribute">brush</abbr> with death, at the hands of the Lich, I realized something. Im not gonna live <abbr title="attribute">forever Finn</abbr>. I would if I could.</p>
	  </div> <!--/.page -->
	  <!-- End Abbreviations -->
	  
	  <!-- Emphasis -->
	  <div class="page">
	    <div class="container">
	      <h3 class="tree">Emphasis</h3>
	      <div class="span4 no-marg-left">
		<h4 class="black">small</h4>
		<small>This line of text is meant to be treated as fine print.</small><br /><br />
		<small>Finn? Finn? Finn! Where are you? I need you to try this! Ill be there in a sec! Whats the status? Good, man! Nice! Seal the deal, bro! Okay, man! Whatevs! You can do it, you hear me?! Im playin BMO--call me later, bye! Hows Finns date? I think its goin good. Unlike your game, boiiiii!</small>
	      </div> <!--/.span4 .no-marg-left -->
	      
	      <div class="span4">
		<h4 class="black">strong</h4>
		<p>For emphasizing a snippet of text with <strong>important</strong></p>
		<p>Alright. <strong>Whaddaya wanna see next?</strong> A cheetah! A fart! A cookie! An external hard drive! Ooh, ooh! Change into Finn, <strong>but give him my body! BMO, your ideas are boring.</strong> What? Your head on my body isnt boring! Its weird!  Alright.</p>
	      </div> <!--/.span4 -->
	      
	      <div class="span4">
		<h4 class="black">em</h4>
		<p>The following snippet of text is <em>rendered as italicized text</em>.</p>
		<p>Eyahh! <em>These jelly kinders arent...</em> alive, are they? What? No, they cant even talk. Kick it! <em>Thanks for helping me out guys. What are these buggers for, anyway?</em> Oh, theyre decorations for my Biennial Gumball Ball. Tonight!</p>
	      </div> <!--/.span4 -->
	    </div> <!--/.container -->
	  </div> <!--/.page -->
	  <!-- End Emphasis -->
	  
	  <!-- Tables -->
	  <div class="page">
	    <h3 class="tree">Tables</h3>
	    <h4 class="black">Default</h4>
	    <table class="table">
              <thead>
                <tr>
                  <th>#</th>
                  <th>First Name</th>
                  <th>Last Name</th>
                  <th>Username</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>1</td>
                  <td>Mark</td>
                  <td>Otto</td>
                  <td>@mdo</td>
                </tr>
                <tr>
                  <td>2</td>
                  <td>Jacob</td>
                  <td>Thornton</td>
                  <td>@fat</td>
                </tr>
                <tr>
                  <td>3</td>
                  <td>Larry</td>
                  <td>the Bird</td>
                  <td>@twitter</td>
                </tr>
              </tbody>
            </table>
	    <br />
	    
	    <h4 class="black">Table Striped</h4>
	    <table class="table table-striped">
              <thead>
                <tr>
                  <th>#</th>
                  <th>First Name</th>
                  <th>Last Name</th>
                  <th>Username</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td>1</td>
                  <td>Mark</td>
                  <td>Otto</td>
                  <td>@mdo</td>
                </tr>
                <tr>
                  <td>2</td>
                  <td>Jacob</td>
                  <td>Thornton</td>
                  <td>@fat</td>
                </tr>
                <tr>
                  <td>3</td>
                  <td>Larry</td>
                  <td>the Bird</td>
                  <td>@twitter</td>
                </tr>
              </tbody>
            </table>
	    <br />
	    
	    <h4 class="black">Table Bordered and Rounded Corners</h4>
	    <table class="table table-bordered">
              <thead>
                <tr>
                  <th>#</th>
                  <th>First Name</th>
                  <th>Last Name</th>
                  <th>Username</th>
                </tr>
              </thead>
              <tbody>
                <tr>
                  <td rowspan="2">1</td>
                  <td>Mark</td>
                  <td>Otto</td>
                  <td>@mdo</td>
                </tr>
                <tr>
                  <td>Mark</td>
                  <td>Otto</td>
                  <td>@TwBootstrap</td>
                </tr>
                <tr>
                  <td>2</td>
                  <td>Jacob</td>
                  <td>Thornton</td>
                  <td>@fat</td>
                </tr>
                <tr>
                  <td>3</td>
                  <td colspan="2">Larry the Bird</td>
                  <td>@twitter</td>
                </tr>
              </tbody>
            </table>
	    <br />
	    
	    <h4 class="black">Optional Row Classes</h4>
	    <table class="table">
              <thead>
                <tr>
                  <th>#</th>
                  <th>Product</th>
                  <th>Payment Taken</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                <tr class="success">
                  <td>1</td>
                  <td>TB - Monthly</td>
                  <td>01/04/2012</td>
                  <td>Approved</td>
                </tr>
                <tr class="error">
                  <td>2</td>
                  <td>TB - Monthly</td>
                  <td>02/04/2012</td>
                  <td>Declined</td>
                </tr>
                <tr class="info">
                  <td>3</td>
                  <td>TB - Monthly</td>
                  <td>03/04/2012</td>
                  <td>Pending</td>
                </tr>
              </tbody>
            </table>
	  </div> <!--/.page -->
	  <!-- End Tables -->
	  
	  <!-- Buttons -->
	  <div class="page">
	    <div class="container">
	      <h3 class="tree">Buttons</h3>
	      <div class="span3 no-marg-left">
		<h4 class="black n0-marg-left">Default Buttons</h4>
		<button type="button" class="btn">Default</button><br/><br/>
		<button type="button" class="btn btn-primary">Primary</button><br/><br/>
		<button type="button" class="btn btn-info">Information</button><br/><br/> 
		<button type="button" class="btn btn-success">Success</button><br/><br/>
		<button type="button" class="btn btn-warning">Warning</button><br/><br/> 
		<button type="button" class="btn btn-danger">Danger</button><br/><br/> 
		<button type="button" class="btn btn-inverse">Inverse</button>
	      </div> <!--/.span3 .no-marg-left -->
	      
	      <div class="span3">
		<h4 class="black n0-marg-left">Template(Medical-Pro Styles)</h4>
		<button type="button" class="btn btn-green">Default Green</button><br/><br/>
		<button type="button" class="btn btn-orange">Default Green</button>
	      </div> <!--/.span3 -->
	      
	      <div class="span3">
		<h4 class="black n0-marg-left">Button Sizes</h4>
		<button type="button" class="btn btn-large">Large button</button><br/><br/>
		<button type="button" class="btn">Default button</button><br/><br/>
		<button type="button" class="btn btn-small">Small button</button><br/><br/>
		<button type="button" class="btn btn-mini">Mini button</button>
	      </div> <!--/.span3 -->
	      
	      <div class="span3">
		<h4 class="black">Block Level Buttons</h4>
		<button type="button" class="btn btn-large btn-block btn-primary">Block level button</button><br />
		<button type="button" class="btn btn-large btn-block">Block level button</button>
	      </div> <!--/.span3 -->
	    </div> <!--/.container -->
	  </div> <!--/.page -->
	  <!-- End Buttons -->
     
        </div><!--/.row-fluid -->
      </div> <!--/.Container -->
    </section><!--#content -->
    
    <!-- Footer -->
    <footer>
      <div class="container">
        <div class="row-fluid">
          <div class="span3">
            <ul class="nav nav-list">
              <li class="nav-header">Contact Us</li>
              
              <li><span class="label label-inverse">Mobile</span></li>
              <li><span class="label label-inverse">Mobile</span></li>
              <li><span class="label label-inverse">Email</span></li>
             <li><span class="label label-inverse">Email</span></li>

              
            </ul>
          </div><!--/.span3 -->

          <div class="span3">

           <ul class="nav nav-list">
              <li class="nav-header">WEBSITE NAVIGATION</li>
              <li><a href="#">Home Page</a></li>
              <li><a href="#">Doctor</a></li>
              <li><a href="registration.php">Registration</a></li>
              <li><a href="patient.php">Patient</a></li>
              <li><a href="about1.php">About us</a></li>
              <li><a href="contact-us.php">Contact Us</a></li>
            </ul>
          </div><!--/.span3 -->
        
          
          <div class="span12 copyright">
         
          </div><!--/.span12 -->
        </div><!--/.row-fluid -->
      </div><!--/.container -->
    </footer>
    <!-- End Footer -->
    
    <!-- Javascript Placed at the end of the document so the pages load faster -->
    
    <!-- Twitter Bootstrap -->
    <script src="js/bootstrap/bootstrap.js"></script>
		
  </body>
</html>
