<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
  <head>
    <!-- Basic meta tags -->
   
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
   
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- CSS styles -->
    <link href="css/style.css" rel="stylesheet">
    <link href="css/validationengine.css" rel="stylesheet">

    <!-- Google Web font 'PT Sans and Yanone Kaffeesatz' -->  
    <link href='http://fonts.googleapis.com/css?family=PT+Sans+Narrow|Yanone+Kaffeesatz:400,300,700' rel='stylesheet' type='text/css'>
     
    <!-- Jquery Library -->
    <script src="js/jquery-1.7.1.min.js"></script>
 
    <!-- For IE6-8 support of HTML5 elements & Seperate CSS for ie-8-7 -->
    <!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
      <link href="css/ie8-7.css" rel="stylesheet">
    <![endif]-->
    <script type="text/javascript">

function validation()
{ 
   var email=document.asd.email.value;
   var message=document.asd.message.value;
   var msg='';
   var error='';
    
     if(email == '')
   {
	     error="<b style='color:red'>please enter Email</b></br>";
         msg+=error;
   }
   if(message == '')
   {
	     error="<b style='color:red'>please enter message</b></br>";
         msg+=error;
   }
    if(msg !='')
   {
	    document.getElementById("error_div").innerHTML = msg;
		return false;
   }
}
</script>
  </head>
    
    <!-- Header -->
    <header>
      <div class="container">
        <div class="row-fluid">
	  <!-- logo -->
          <div class="span6 logo">
            <a href="index.php"><img src="img/plo.jpg" /></a>
          </div>
	  <!-- End Logo -->
          
          <!-- Social menu -->
	  <div class="span6" id="social">
            <ul class="social">
              <li class="twitter">
		<a target="_blank" href="#">&nbsp;</a>
              </li>
	      <li class="facebook">
		<a target="_blank" href="#">&nbsp;</a>
	      </li>
            </ul>
          </div>
          <!-- End Social Menu -->
        </div> <!--/.row-fluid -->
      </div> <!--/.container -->
    </header>
    <!-- End Header -->
    
    <!-- Section Top -->
    <section id="top">
      <div class="container">
	<!-- Main Menu -->
        <div class="navbar">
          <div class="navbar-inner">
            <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
	      Main Menu
            </a>
            <div class="nav-collapse">
              <ul class="nav">
                <li><a href="index.php">Home</a></li>
                
      <!--           <li class="dropdown">
                  <a href="doctorlogin.php">DoctorAdmin</a></li>
                  
          -->         
                  
                  <li class="dropdown">
                  <a href="userpatient.php">Registration</a></li>
                  
               
                  
                   <li class="dropdown">
                  <a href="medicine.php">medicine</a></li>

                

               <li class="dropdown">
		  <a href="newabout.php">About us</a></li>
          
              <li class="active"><a href="contact-us.php">Contact Us</a></li>
              </ul>
            </div> <!--/.nav-collapse -->
          </div> <!--/.navbar-inner -->
        </div> <!--/.navbar -->
        <!-- End Main Menu -->
	
      </div> <!--/.container -->
    </section> <!--/#top --> 
    <!--  End Section Top -->
    
    <!-- Section Breadcrumbs-->
    <section id="breadcrumb">
      <div class="b-c">
	<div class="container">
	  <ul class="breadcrumb">
	 
	  </ul>
	</div> <!--/.container -->
      </div> <!--/.b-c -->
    </section> <!--#breadcrumb -->
    <!-- End Section Breadcrumb -->
     <center>
     <img src="img/sample.jpg" />  
     </center>
    <!-- Section content -->
    <section id="content" class="contact">  
      <div class="container">
	<div class="row-fluid">
	  <div class="span7">
	    <div class="page clearfix no-marg-bottom">
	      <h3 class="tree">Contact Ehealthcare</h3>
	      <p>Work in the field .visit our recruitment frequently asked questions.you can also contact us via our online form below .if you would like to learn more about the services provided by Ehealthcare system,or have us a specific question,Please complete and Sub it the form below and we will Contact you. </p>
	 
	      <ul class="contact">
		<li><i class="call"></i>Call us:</li>

		<li><i class="email"></i>Email:</li>
		<li><i class="address"></i>Come to us:</li>
	      </ul>
     
	      <ul class="social c2">
		<li class="google">
		  <a target="_blank" href="#">&nbsp;</a>
		</li>
		<li class="in">
		  <a target="_blank" href="#">&nbsp;</a>
		</li>
		<li class="rss">
		  <a target="_blank" href="#">&nbsp;</a>
		</li>
		<li class="facebook">
		  <a target="_blank" href="#">&nbsp;</a>
		</li>
		<li class="twitter">
		  <a target="_blank" href="#">&nbsp;</a>
		</li>
		<li class="myspace">
		  <a target="_blank" href="#">&nbsp;</a>
		</li>
		<li class="thumblr">
		  <a target="_blank" href="#">&nbsp;</a>
		</li>
		<li class="technorati">
		  <a target="_blank" href="#">&nbsp;</a>
		</li>
		<li class="reddit">
		  <a target="_blank" href="#">&nbsp;</a>
		</li>    
	      </ul>
	    </div> <!--/.page .clearfix .no-marg-bottom -->
	  </div> <!--/.span7 -->
    
	  <div class="span5">
	    <div class="page dark no-marg-bottom">
        <table>
	      <h3 class="snow">Contact us</h3>
	     <form name="asd" id="asi" action="contactinsert.php" method="post" onsubmit="return validation()">
         
         <h1 align="center"><font face="Times New Roman, Times, serif" size="+2">Contact us</font></h1>
         <td><font face="Times New Roman, Times, serif" size="+1">Name</font></td>
         <td><input type="text" name="name" id="name" /></td>
         </tr>
         <tr>
          <td><font face="Times New Roman, Times, serif" size="+1">Email</font></td>
          <td><input type="text" name="email" id="email" /></td>
          </tr>
          <tr>
          <td> <font face="Times New Roman, Times, serif" size="+1">Message</font></td>
          <td><textarea name="message" id="message" cols="5" rows="5"></textarea></td>
          </tr>
          <tr>
           <td><h1 align="center"><input type="submit" name="submit " id="submit" value="Submit" /></h1></td>
           </tr>
           </form>
           </table>
	    </div> <!--/.page .dark .no-marg-bottom -->
	  </div> <!--/.span5 -->
	</div> <!--/.rpw-fluid -->
      </div> <!--/.Container  -->
    </section>
    <!-- End Section content -->

    <!-- Footer -->
    <footer>
      <div class="container">
        <div class="row-fluid">
          <div class="span3">
            <ul class="nav nav-list">
              <li class="nav-header">Contact Us</li>
               <li><span class="label label-inverse">Mobile</span></li>
              <li><span class="label label-inverse">Mobile</span></li>
              <li><span class="label label-inverse">Email</span></li>
             <li><span class="label label-inverse">Email</span></li>

              
            </ul>
          </div> <!--/.span3 -->

          <div class="span3">
           <ul class="nav nav-list">
              <li class="nav-header">WEBSITE NAVIGATION</li>
              <li><a href="index.php">Home Page</a></li>
              <li><a href="about1.php">About us</a></li>
              <li><a href="contact-us.php">Contact Us</a></li>
            </ul>
          </div> <!--/.span3 -->
        
          
          <div class="span12 copyright">
            
          </div><!--/.span12 -->
        </div><!--/.row-fluid -->
      </div><!--/.container -->
    </footer>
    <!-- End Footer -->

    <!-- Javascript Placed at the end of the document so the pages load faster -->
    
    <!-- Twitter Bootstrap -->
    <script src="js/bootstrap/bootstrap.js"></script>
    
    <!-- Form Validation -->
    <script src="js/validate/jquery.validationEngine.js"></script>
    <script>
      jQuery(document).ready(function(){
	// binds form submission and fields to the validation engine
      	jQuery("#formID").validationEngine();
      });
    </script>
  </body>
</html>
