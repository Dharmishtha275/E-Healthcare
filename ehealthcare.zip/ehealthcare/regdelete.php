<?php
$conn=mysql_connect("localhost","root","");
if($conn)
{
	echo"sucessfully";
}
mysql_select_db("ehealthcare",$conn);
$id=$_GET['id'];
$firstname=$_POST['firstname'];
$secondname=$_POST['secondname'];
$lastname=$_POST['lastname'];
$address=$_POST['address'];
$city=$_POST['city'];
$email=$_POST['email'];
$password=$_POST['password'];
$delete="DELETE FROM registration WHERE id='".$id."'";
$query=mysql_query($delete);
header("location:registration.php");
?>

