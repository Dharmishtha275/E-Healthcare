<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
  <head>
    <!-- Basic meta tags -->
   
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <title>Ehealthcare - Bootstrap Responsive Template</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- CSS styles -->
    <link href="css/style.css" rel="stylesheet">
      
    <!-- Google Web font 'PT Sans and Yanone Kaffeesatz' -->  
    <link href='http://fonts.googleapis.com/css?family=PT+Sans+Narrow|Yanone+Kaffeesatz:400,300,700' rel='stylesheet' type='text/css'>
     
    <!-- Jquery Library -->
    <script src="js/jquery-1.7.1.min.js"></script>
    
    <!-- for IE6-8 support of HTML5 elements & Seperate CSS for ie-8-7 -->
    <!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
      <link href="css/ie8-7.css" rel="stylesheet">
    <![endif]-->
    
  </head>

  <body>
    <!-- Header -->
    <header>
      <div class="container">
        <div class="row-fluid">
	  <!-- logo -->
          <div class="span6 logo">
            <a href="index.php"><img src="img/logo.png" /></a>
          </div>
	  <!-- End Logo -->
          
          <!-- Social menu -->
	  <div class="span6" id="social">
            <ul class="social">
              <li class="twitter">
		<a target="_blank" href="#">&nbsp;</a>
              </li>
	      <li class="facebook">
		<a target="_blank" href="#">&nbsp;</a>
	      </li>
            </ul>
          </div>
          <!-- End Social Menu -->
        </div> <!--/.row-fluid -->
      </div> <!--/.container -->
    </header>
    <!-- End Header -->
    
    <!-- Section Top -->
    <section id="top">
      <div class="container">
	<!-- Main Menu -->
        <div class="navbar">
          <div class="navbar-inner">
            <a class="btn btn-navbar" data-toggle="collapse" data-target=".nav-collapse">
	      Main Menu
            </a>
            <div class="nav-collapse">
              <ul class="nav">
                <li><a href="index.php">Home</a></li>
                
                 <li class="dropdown">
                  <a href="doctorlogin.php">admin</a></li>
                  
                   
                  
                  <li class="dropdown">
                  <a href="registration.php">registration</a></li>
                  
                <li class="dropdown active">
                  <a  href="login.php">login</a></li>
                  

                <li class="dropdown">
 		  <a href="about1.php">about us</a></li>

                <li><a href="contact-us.php">Contact Us</a></li>
              </ul>
            </div> <!--/.nav-collapse -->
          </div> <!--/.navbar-inner -->
        </div> <!--/.navbar -->
        <!-- End Main Menu -->
	
      </div> <!--/.container -->
    </section> <!--/#top --> 
    <!--  End Section Top -->
    
    <!-- Section Breadcrumbs-->
    <section id="breadcrumb">
      <div class="b-c">
	<div class="container">
	  <ul class="breadcrumb">
	    <li class="title">You are here</li>
	    <li><a href="#">Home</a> <span class="divider"><img src="img/br-arrow.png" alt="" /></span></li>
	    <li><a href="#">Features</a> <span class="divider"><img src="img/br-arrow.png" alt="" /></span></li>
	    <li class="active">Columns</li>
	  </ul>
	</div> <!--/.container -->
      </div> <!--/.b-c -->
    </section> <!--#breadcrumb -->
    <!-- End Section Breadcrumb -->
    
    <!-- Section content -->
    <section id="content">
      <div class="container">
        <div class="row-fluid">
	  <div class="page">
	    <h3 class="tree">Responsive Grid System</h3>
	    <p>The fluid grid system uses percents instead of pixels for column widths. It has the same responsive capabilities as our fixed grid system, ensuring proper proportions for key screen resolutions and devices.</p>
	  </div> <!--/.page -->
	  
	  <!-- 1 Column -->
          <div class="span1 page no-marg-left">1</div>
	  <div class="span1 page">1</div>
	  <div class="span1 page">1</div>
	  <div class="span1 page">1</div>
	  <div class="span1 page">1</div>
	  <div class="span1 page">1</div>
	  <div class="span1 page">1</div>
	  <div class="span1 page">1</div>
	  <div class="span1 page">1</div>
	  <div class="span1 page">1</div>
	  <div class="span1 page">1</div>
	  <div class="span1 page">1</div>
	  
	  <!-- 2 Column -->
	  <div class="span2 page no-marg-left">2</div>
	  <div class="span2 page">2</div>
	  <div class="span2 page">2</div>
	  <div class="span2 page">2</div>
	  <div class="span2 page">2</div>
	  <div class="span2 page">2</div>
	  
	  <!-- 3 Column -->
	  <div class="span3 page no-marg-left">3</div>
	  <div class="span3 page">3</div>
	  <div class="span3 page">3</div>
	  <div class="span3 page">3</div>
	  
	  <!-- 4 Column -->
	  <div class="span4 page no-marg-left">4</div>
	  <div class="span4 page">4</div>
	  <div class="span4 page">4</div>
	  
	  <!-- 6 Column -->
	  <div class="span6 page no-marg-left">6</div>
	  <div class="span6 page">6</div>
	  
	  <!-- 12 Column -->
	  <div class="span12 page no-marg-left">12</div>
	  
	  <p>&nbsp;</p>
	  
	  <!-- 1-11 -->
	  <div class="span1 page no-marg-left">1</div>
	  <div class="span11 page">11</div>
	  
	  <!-- 2-10 -->
	  <div class="span2 page no-marg-left">2</div>
	  <div class="span10 page">10</div>
	  
	  <!-- 3-9 -->
	  <div class="span3 page no-marg-left">3</div>
	  <div class="span9 page">9</div>
	  
	  <!-- 4-8 -->
	  <div class="span4 page no-marg-left">4</div>
	  <div class="span8 page">8</div>
	  
	  <!-- 5-7 -->
	  <div class="span5 page no-marg-left">5</div>
	  <div class="span7 page">7</div>
	  
	  <!-- 6-6 -->
	  <div class="span6 page no-marg-left">6</div>
	  <div class="span6 page">6</div>
	  
	  <!-- 7-5 -->
	  <div class="span7 page no-marg-left">7</div>
	  <div class="span5 page">5</div>
	  
	  <!-- 8-4 -->
	  <div class="span8 page no-marg-left">8</div>
	  <div class="span4 page">4</div>
	  
	  <!-- 9-3 -->
	  <div class="span9 page no-marg-left">9</div>
	  <div class="span3 page">3</div>
	  
	  <!-- 10-2 -->
	  <div class="span10 page no-marg-left">10</div>
	  <div class="span2 page">2</div>
	  
	  <!-- 11-1 -->
	  <div class="span11 page no-marg-left">11</div>
	  <div class="span1 page">1</div>
	
        </div><!--/.row-fluid -->
      </div> <!--/.Container -->
    </section><!--#content -->
    <!-- End Section content-->
    
    <!-- Footer -->
    <footer>
      <div class="container">
        <div class="row-fluid">
          <div class="span3">
            <ul class="nav nav-list">
              <li class="nav-header">Contact Us</li>
              <li><span class="label label-inverse">Mobile</span></li>
              <li><span class="label label-inverse">Mobile</span></li>
              <li><span class="label label-inverse">Email</span></li>
             <li><span class="label label-inverse">Email</span></li>

              
            </ul>
          </div> <!--/.span3 -->

          <div class="span3">
           <ul class="nav nav-list">
              <li class="nav-header">WEBSITE NAVIGATION</li>
              <li><a href="#">Home Page</a></li>
              <li><a href="#">Doctor</a></li>
              <li><a href="registration.php">Registration</a></li>
              <li><a href="patient.php">Patient</a></li>
              <li><a href="about1.php">About us</a></li>
              <li><a href="contact-us.php">Contact Us</a></li>
            </ul>
          </div> <!--/.span3 -->
        
          
          <div class="span12 copyright">
           
          </div><!--/.span12 -->
        </div><!--/.row-fluid -->
      </div><!--/.container -->
    </footer>
    <!-- End Footer -->
    
    <!-- Javascript Placed at the end of the document so the pages load faster -->
    
    <!-- Twitter Bootstrap -->
    <script src="js/bootstrap/bootstrap.js"></script>

  </body>
</html>
