
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <!-- Basic meta tags -->

    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <!-- CSS styles -->
    <link href="css/style.css" rel="stylesheet">
      
    <!-- Google Web font 'PT Sans and Yanone Kaffeesatz' -->  
    <link href='http://fonts.googleapis.com/css?family=PT+Sans+Narrow|Yanone+Kaffeesatz:400,300,700' rel='stylesheet' type='text/css'>
     
    <!-- Jquery Library -->
    <script src="js/jquery-1.7.1.min.js"></script>
    
    <!-- for IE6-8 support of HTML5 elements & Seperate CSS for ie-8-7 -->
    <!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
      <link href="css/ie8-7.css" rel="stylesheet">
    <![endif]-->
    <script>
	$(function(){
	$("#date").datepicker();
	});
	</script>
    <script type="text/javascript">
    
       function validation()
{ 
   var id=document.app.id.value;
   var name=document.app.name.value;
   var age=document.app.age.value;
   var no=document.app.no.value;
 


   var msg='';
   var error='';
    
     if(id == '')
   {
	     error=alert("Please Enter id");
         msg+=error;
   }
    
     if(name == '')
   {
	     error=alert("Please Enter name");
         msg+=error;
   }
   
      if(age == '')
   {
	     error=alert("Please Enter age");
         msg+=error;
   }
         if(no == '')
   {
	     error=alert("Please Enter no ");
         msg+=error;
   }
   
 //       else if(!no.test(no))
  // {
	  //error=alert("please enter 10 digit no");
    //   msg+=error;  
  // }
   
   
    if(msg !='')
   {
		return false;
   }
}


   
   </script>
   
<?php
if(isset($_POST['submit']))
{
$conn=mysql_connect("localhost","root","");
mysql_select_db("ehealthcare",$conn);
$Name=$_POST['name'];
$Age=$_POST['age'];
$contactnumber=$_POST['no'];
$date=$_POST['date'];
$Description=$_POST['des'];
$tomeetourdoctor=$_POST['doctor'];
$insert="INSERT INTO newappoint(Name,Age,contactnumber,date,Description,tomeetourdoctor) VALUES ('$Name','$Age','$contactnumber','$date','$Description','$tomeetourdoctor')";
$query=mysql_query($insert,$conn);
if($query)
{
	header("Location:newappoint.php");
}
else
{
	echo "<script>sorry your Appoinment not booked.......</script>";
}

}
?>
    
    </head>
 
  <body>
    <!-- Header -->
    <header>
      <div class="container">
        <div class="row-fluid">
	  <!-- logo -->
          <div class="span6 logo">
            <a href="index.php"><img src="img/plo.jpg" /></a>
          </div>
	  <!-- End Logo -->
          
          <!-- Social menu -->
	  <div class="span6" id="social">
            <ul class="social">
              <li class="twitter">
		<a target="_blank" href="#">&nbsp;</a>
              </li>
	      <li class="facebook">
		<a target="_blank" href="#">&nbsp;</a>
	      </li>
            </ul>
          </div>
          <!-- End Social Menu -->
        </div> <!--/.row-fluid -->
      </div> <!--/.container -->
    </header>
    <!-- End Header -->
    
    <!-- Section Top -->
    <section id="top">
      
      </div> <!--/.container -->
    </section> <!--/#top --> 
    <!--  End Section Top -->
    
    <!-- Section Breadcrumbs-->
    <section id="breadcrumb">
      <div class="b-c">
	<div class="container">
	  <ul class="breadcrumb">
	    
	  </ul>
	</div> <!--/.container -->
      </div> <!--/.b-c -->
    </section> <!--#breadcrumb -->
    <!-- End Section Breadcrumb --><br /><br />
    
  <div class="span4">
	    <div class="page dark">
	      <h3 class="snow">Make an Appointment</h3>
	      <span class="box-icon">
		<img src="img/box-icons/appontment.png" alt="" />
	      </span>
          
          
          <form name="app" id="apo"  method="post" onsubmit="return validation()">
          <p><font face="Times New Roman, Times, serif" size="+1" color="#000000"><b><i>Make an Appointment of Doctor anytime ,just you can fillup Form given below</i></b></font></p>
		  
	      
		  <label><font face="Times New Roman, Times, serif" size="+1">Name</font></label>
		  <input type="text" id="name" name="name" placeholder="name" />
	
                   
		  <label><font face="Times New Roman, Times, serif" size="+1">Age</font></label>
		  <input type="text" id="age" name="age" placeholder="age" />
          
          <label><font face="Times New Roman, Times, serif" size="+1">Contact Number</font></label>
          <input type="text" id="no" name="no" placeholder="contact no" />
          <label><font face="Times New Roman, Times, serif" size="+1">date:</font></label>
          <input type="date" id="date" name="date" placeholder="date" />
          
                    <label><font face="Times New Roman, Times, serif" size="+1">Description</font></label>
          <textarea name="des" id="des" rows="5" cols="5"> </textarea>
          
                    <label><font face="Times New Roman, Times, serif" size="+1">to meet which doctor</font></label>
          <select name="doctor" id="doctor">
          <option>Eye-specialist</option>
          <option>Dentist</option>
          <option>Physiotheratist</option>
          <option>Cardiologist</option>
          </select><br />
         <input type="submit" name="submit" class="btn btn-green" value="Submit"/>
		</form>
        <?php
        
        if(isset($_GET['submit']))
			{
			 if($_GET['submit']=="success")
				{
				echo "<center>Your appointment is conform</center>";
						}
					}
        ?>
        
	    </div><!--/.page dark -->
	  </div><!--/.span4 -->
	</div><!--/.row-fluid -->
    


       


